package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ParoleJsonRepository
import com.example.model.ParoleQuestionType
import com.example.model.ScreenRoute
import com.example.viewmodel.ParoleViewModel
import com.example.viewmodel.RpgViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ParoleModeTest {

    private val context: Context = ApplicationProvider.getApplicationContext()

    @Test
    fun testAll60JsonFilesExistAndAreValid() {
        val difficulties = listOf("facile", "intermediaire", "expert")
        val scanned = ParoleJsonRepository.scanAvailableLevels(context)

        for (diff in difficulties) {
            val levels = scanned[diff]
            assertNotNull("Levels list should not be null for $diff", levels)
            assertEquals("Should have exactly 20 levels for $diff", 20, levels?.size)

            for (levelNum in 1..20) {
                val levelData = ParoleJsonRepository.loadLevel(context, diff, levelNum)
                assertNotNull("Level $levelNum ($diff) should load properly", levelData)
                assertEquals(diff, levelData?.difficulte)
                assertEquals(levelNum, levelData?.niveau)
                assertEquals(12, levelData?.questions?.size)

                // Check questions integrity
                val allIds = mutableSetOf<String>()
                levelData?.questions?.forEachIndexed { index, question ->
                    assertNotNull("Question $index in $diff/$levelNum must have an ID", question.id)
                    assertTrue("Question ID must not be blank", question.id.isNotBlank())
                    assertTrue(
                        "Question ID ${question.id} should be unique in level",
                        allIds.add(question.id)
                    )

                    // Check type is recognized
                    assertTrue(
                        "Question type should be one of the 3 valid types",
                        question.type in listOf(
                            ParoleQuestionType.VERSET_REFERENCE,
                            ParoleQuestionType.REFERENCE_VERSET,
                            ParoleQuestionType.COMPLETER_VERSET
                        )
                    )

                    // Check options (4 options)
                    assertEquals("Question should have 4 options", 4, question.options.size)
                    assertTrue("Bonne reponse must not be blank", question.bonneReponse.isNotBlank())
                    assertTrue(
                        "Options must contain the bonne reponse (${question.bonneReponse})",
                        question.options.any { it.trim().equals(question.bonneReponse.trim(), ignoreCase = true) }
                    )

                    // Check reference or verset
                    assertTrue("Reference must not be blank", question.reference.isNotBlank())
                }
            }
        }
    }

    @Test
    fun testParoleViewModelSessionLifecycle() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = ParoleViewModel(app)

        vm.loadAvailableLevels(context)
        val scanned = ParoleJsonRepository.scanAvailableLevels(context)
        assertTrue(scanned["facile"]?.contains(1) == true)

        // Start level 1 facile
        vm.startLevel(context, "facile", 1)
        var state = vm.paroleState.value
        assertTrue(state.isSessionActive)
        assertEquals("facile", state.selectedDifficulty)
        assertEquals(1, state.selectedLevelNumber)
        assertEquals(0, state.currentQuestionIndex)
        assertEquals(0, state.correctCount)
        assertEquals(0, state.score)
        assertFalse(state.isCompleted)

        val currentQ = state.currentLevelData!!.questions[0]
        val rightAnswer = currentQ.bonneReponse

        // Select correct option & validate
        vm.selectOption(rightAnswer)
        vm.validateAnswer()
        state = vm.paroleState.value
        assertTrue(state.isAnswerChecked)
        assertTrue(state.isCorrect)
        assertEquals(1, state.correctCount)
        assertEquals(100, state.score)

        // Advance to next question
        vm.nextQuestion()
        state = vm.paroleState.value
        assertEquals(1, state.currentQuestionIndex)
        assertFalse(state.isAnswerChecked)

        // Exit session
        vm.exitSession()
        state = vm.paroleState.value
        assertFalse(state.isSessionActive)
    }

    @Test
    fun testModesIndependence() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val rpgVm = RpgViewModel(app)
        val paroleVm = ParoleViewModel(app)

        // Verify initial routes
        assertEquals(ScreenRoute.MAIN_MENU, rpgVm.currentScreen.value)

        // Navigate to PAROLE
        rpgVm.navigateTo(ScreenRoute.PAROLE)
        assertEquals(ScreenRoute.PAROLE, rpgVm.currentScreen.value)

        // Start parole level
        paroleVm.startLevel(context, "intermediaire", 5)
        assertTrue(paroleVm.paroleState.value.isSessionActive)

        // Navigate back to Main Menu
        rpgVm.navigateTo(ScreenRoute.MAIN_MENU)
        assertEquals(ScreenRoute.MAIN_MENU, rpgVm.currentScreen.value)

        // Navigate to ADVENTURE
        rpgVm.navigateTo(ScreenRoute.ADVENTURE)
        assertEquals(ScreenRoute.ADVENTURE, rpgVm.currentScreen.value)

        // Player stats in RPG are untouched by Parole
        assertEquals(100, rpgVm.playerStats.value.maxHp)
    }
}
