package com.example.model

/**
 * Modèles de données pour la nouvelle architecture du Mode « Parole ».
 *
 * Structure des fichiers :
 * parole/
 * ├── facile/
 * │   ├── niveau_01.json
 * │   └── ...
 * ├── intermediaire/
 * │   ├── niveau_01.json
 * │   └── ...
 * └── expert/
 *     ├── niveau_01.json
 *     └── ...
 */

enum class ParoleQuestionType(val rawValue: String) {
    VERSET_REFERENCE("verset_reference"),   // Afficher un verset -> 4 références -> 1 bonne réponse
    REFERENCE_VERSET("reference_verset"),   // Afficher une référence -> 4 versets -> 1 bonne réponse
    COMPLETER_VERSET("completer_verset");   // Afficher un verset avec trou -> 4 mots/expressions -> 1 bonne réponse

    companion object {
        fun fromString(value: String): ParoleQuestionType {
            return entries.find { it.rawValue.equals(value.trim(), ignoreCase = true) }
                ?: VERSET_REFERENCE
        }
    }
}

/**
 * Une question du Mode Parole (12 questions par niveau)
 */
data class ParoleQuestion(
    val id: String,
    val type: ParoleQuestionType,
    val reference: String,
    val verset: String? = null,
    val options: List<String> = emptyList(), // Exactement 4 options mélangées pour la session
    val bonneReponse: String                // Valeur exacte de la bonne réponse
)

/**
 * Représente un fichier de niveau (ex: facile/niveau_01.json)
 */
data class ParoleLevelData(
    val difficulte: String,                 // "facile", "intermediaire", "expert"
    val niveau: Int,                        // 1, 2, 3...
    val questions: List<ParoleQuestion> = emptyList() // 12 questions
)

/**
 * Progression enregistrée pour le Mode Parole
 */
data class ParoleLevelResult(
    val levelNumber: Int,
    val difficulty: String,
    val score: Int,
    val correctCount: Int,
    val totalQuestions: Int = 12,
    val stars: Int = 0 // 1, 2, 3 étoiles
)

data class ParoleProgress(
    val facileUnlockedMaxLevel: Int = 1,
    val facileCompletedLevels: Set<Int> = emptySet(),
    val intermediaireUnlockedMaxLevel: Int = 1,
    val intermediaireCompletedLevels: Set<Int> = emptySet(),
    val expertUnlockedMaxLevel: Int = 1,
    val expertCompletedLevels: Set<Int> = emptySet(),
    val totalPoints: Int = 0,
    val bestScores: Map<String, Int> = emptyMap(), // ex: "facile_1" -> 1500
    val levelStars: Map<String, Int> = emptyMap()   // ex: "facile_1" -> 3
)

/**
 * État de jeu du Mode Parole
 */
data class PlayableParoleState(
    val isSessionActive: Boolean = false,
    val selectedDifficulty: String = "facile", // "facile", "intermediaire", "expert"
    val selectedLevelNumber: Int = 1,
    val availableLevelsByDiff: Map<String, List<Int>> = emptyMap(), // ex: "facile" -> [1, 2, 3]
    val currentLevelData: ParoleLevelData? = null,
    val currentQuestionIndex: Int = 0,
    val selectedOption: String? = null,
    val isAnswerChecked: Boolean = false,
    val isCorrect: Boolean = false,
    val feedbackMessage: String = "",
    val score: Int = 0,
    val totalAccumulatedPoints: Int = 0,
    val correctCount: Int = 0,
    val streak: Int = 0,
    val maxStreak: Int = 0,
    val pointsEarnedLastQuestion: Int = 0,
    val isCompleted: Boolean = false,
    val levelStars: Map<String, Int> = emptyMap(), // "facile_1" -> 3
    val completedLevels: Map<String, Set<Int>> = emptyMap() // "facile" -> setOf(1, 2)
)
