package com.example.model

/**
 * Shared state models for Biblical RPG UI Shell Architecture
 */

data class GameSettings(
    val isSfxEnabled: Boolean = true,
    val isMusicEnabled: Boolean = true,
    val isDarkMode: Boolean = true
)

data class PlayerStats(
    val level: Int = 1,
    val xp: Int = 120,
    val maxXp: Int = 300,
    val score: Int = 1450,
    val gold: Int = 250,
    val gems: Int = 15,
    val currentHp: Int = 85,
    val maxHp: Int = 100,
    val currentFaith: Int = 40,
    val maxFaith: Int = 50
)

enum class ScreenRoute {
    MAIN_MENU,
    ADVENTURE,
    BOSS,
    PAROLE,
    SHOP,
    CHARACTER,
    SETTINGS
}

/**
 * Data containers for Adventure Mode JSON Data
 */
data class AdventureReward(
    val id: String,
    val nom: String,
    val type: String,
    val rarite: String,
    val categorie: String,
    val description: String,
    val verset: String,
    val image: String = ""
)

data class AdventureQuestion(
    val id: String,
    val type: String, // "choix_multiple", "vrai_faux", "clavier"
    val chrono: Boolean = false,
    val timeLimit: Int = 15,
    val question: String,
    val options: List<String> = emptyList(),
    val answer: String,
    val aliases: List<String> = emptyList(),
    val reference: String
)

data class AdventureEtape(
    val etape: Int,
    val titre: String,
    val chapitres: String,
    val niveau: String,
    val recompense: AdventureReward?,
    val questions: List<AdventureQuestion>,
    val isBossStep: Boolean = false,
    val bossNom: String? = null,
    val bossDescription: String? = null
)

data class AdventureBookData(
    val livre: String,
    val ordre: Int,
    val totalEtapes: Int,
    val niveau: String, // "facile", "intermediaire", "expert"
    val collection: List<AdventureReward>,
    val etapes: List<AdventureEtape>
)

enum class AdventureViewMode {
    WORLD_MAP,
    STEPS_LIST,
    STEP_QUIZ
}

data class PlayableAdventureState(
    val selectedBookGroup: String = "Genèse", // "Genèse", "Lévitique"
    val selectedDifficulty: String = "facile", // "facile", "intermediaire", "expert"
    val activeViewMode: AdventureViewMode = AdventureViewMode.WORLD_MAP,
    val bookDataMap: Map<String, AdventureBookData> = emptyMap(),
    val currentBook: AdventureBookData? = null,
    val currentEtapeIndex: Int = 0, // 0..12
    val currentQuestionIndex: Int = 0,
    val isPlayingStep: Boolean = false, // false = showing Steps List/Map, true = playing quiz
    val unlockedEtapesMap: Map<String, Int> = emptyMap(), // Key: "${livre}_${niveau}", Value: max unlocked etape index
    val keyboardInput: String = "",
    val selectedOption: String? = null,
    val isAnswerChecked: Boolean = false,
    val isCorrect: Boolean = false,
    val feedbackMessage: String = "",
    val referenceText: String = "",
    val unlockedRewards: List<AdventureReward> = emptyList(),
    val isEtapeCompleted: Boolean = false,
    val isBookCompleted: Boolean = false,
    val showRelicGallery: Boolean = false
)

/**
 * Data container ready to receive Adventure JSON payload
 */
data class AdventureSceneState(
    val chapterTitle: String = "Chapitre I: La Traversée du Désert",
    val sceneId: String = "scene_001",
    val narrativeText: String = "Vous arrivez au pied du Mont Sinaï. Un vent puissant soulève la poussière du désert. Devant vous se dresse un passage étroit gardé par une obscurité mystérieuse.",
    val imagePlaceholderTag: String = "desert_mount_sinai",
    val choices: List<AdventureChoiceOption> = listOf(
        AdventureChoiceOption("c1", "Prier pour obtenir la guidance divine (+5 Foi)", "Prière"),
        AdventureChoiceOption("c2", "Avancer courageusement le bouclier levé", "Courage"),
        AdventureChoiceOption("c3", "Inspecter les anciennes écritures gravées dans la roche", "Sagesse"),
        AdventureChoiceOption("c4", "Consulter l'inventaire pour chercher une torche", "Objet")
    )
)

data class AdventureChoiceOption(
    val id: String,
    val label: String,
    val category: String
)

/**
 * Data container for Boss Json Configuration
 */
data class BossData(
    val id: String,
    val livre: String,
    val ordre: Int,
    val bossInfo: BossInfo,
    val niveau: String, // "facile", "intermediaire", "expert"
    val vies: Int,
    val chronoGlobal: Int,
    val chronoQuestion: Int,
    val questions: List<BossQuestion>
)

data class BossInfo(
    val nom: String,
    val titre: String,
    val emoji: String,
    val description: String,
    val verset: String,
    val image: String,
    val type: String,
    val mecanique: String
)

data class BossQuestion(
    val id: String,
    val phase: String, // "enigme", "qui_suis_je", "combat"
    val question: String,
    val options: List<String>,
    val answer: String,
    val reference: String
)

data class PlayableBossState(
    val inBattleScreen: Boolean = false,
    val selectedBossGroup: String = "boss_genese", // "boss_genese", "boss_exode", etc.
    val selectedDifficulty: String = "facile", // "facile", "intermediaire", "expert"
    val bossDataMap: Map<String, BossData> = emptyMap(),
    val currentBoss: BossData? = null,
    val currentQuestionIndex: Int = 0,
    val remainingBossLives: Int = 3,
    val globalTimeSeconds: Int = 60,
    val questionTimeSeconds: Int = 15,
    val selectedOption: String? = null,
    val isAnswerChecked: Boolean = false,
    val isCorrect: Boolean = false,
    val feedbackMessage: String = "",
    val referenceText: String = "",
    val isGameOver: Boolean = false,
    val isVictory: Boolean = false,
    val totalScoreEarned: Int = 0,
    val battleLogs: List<String> = listOf("Le Serpent ancien apparaît dans le jardin...")
)

/**
 * Data container ready to receive Boss Battle JSON payload
 */
data class BossBattleState(
    val bossId: String = "boss_goliath",
    val bossName: String = "Goliath de Gath",
    val bossSubtitle: String = "Champion des Philistins",
    val currentHp: Int = 320,
    val maxHp: Int = 500,
    val phase: Int = 1,
    val battleLogs: List<String> = listOf(
        "Goliath fait résonner son bouclier de bronze !",
        "C'est à votre tour d'agir."
    ),
    val isPlayerTurn: Boolean = true
)

enum class BossActionType {
    ATTACK,
    HOLY_ABILITY,
    DEFEND,
    ITEM
}

data class BossActionOption(
    val id: String,
    val title: String,
    val faithCost: Int = 0,
    val type: BossActionType
)

/**
 * Data container for Shop items
 */
data class ShopItem(
    val id: String,
    val name: String,
    val category: String, // Relique, Armure, Potion
    val description: String,
    val priceGold: Int,
    val priceGems: Int = 0,
    val statBonus: String,
    val isPurchased: Boolean = false
)
