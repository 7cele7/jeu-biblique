package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.ScreenRoute
import com.example.ui.components.HeaderCurrencyBar
import com.example.ui.screens.AdventureContainerScreen
import com.example.ui.screens.BossContainerScreen
import com.example.ui.screens.CharacterContainerScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.ParoleContainerScreen
import com.example.ui.screens.SettingsContainerScreen
import com.example.ui.screens.ShopContainerScreen
import com.example.ui.theme.BiblicalRpgTheme
import com.example.viewmodel.ParoleViewModel
import com.example.viewmodel.RpgViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: RpgViewModel by viewModels()
    private val paroleViewModel: ParoleViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val gameSettings by viewModel.gameSettings.collectAsStateWithLifecycle()
            BiblicalRpgTheme(darkTheme = gameSettings.isDarkMode) {
                RpgAppRouter(viewModel = viewModel, paroleViewModel = paroleViewModel)
            }
        }
    }
}

@Composable
fun RpgAppRouter(
    viewModel: RpgViewModel,
    paroleViewModel: ParoleViewModel
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val gameSettings by viewModel.gameSettings.collectAsStateWithLifecycle()
    val playerStats by viewModel.playerStats.collectAsStateWithLifecycle()
    val playableAdventureState by viewModel.playableAdventureState.collectAsStateWithLifecycle()
    val playableBossState by viewModel.playableBossState.collectAsStateWithLifecycle()
    val shopItems by viewModel.shopItems.collectAsStateWithLifecycle()

    // Handle system back button safely
    BackHandler(enabled = currentScreen != ScreenRoute.MAIN_MENU) {
        if (currentScreen == ScreenRoute.ADVENTURE) {
            when (playableAdventureState.activeViewMode) {
                com.example.model.AdventureViewMode.STEP_QUIZ -> viewModel.returnToAdventureStepsList()
                com.example.model.AdventureViewMode.STEPS_LIST -> viewModel.returnToAdventureWorldMap()
                com.example.model.AdventureViewMode.WORLD_MAP -> viewModel.navigateTo(ScreenRoute.MAIN_MENU)
            }
        } else {
            viewModel.navigateTo(ScreenRoute.MAIN_MENU)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            HeaderCurrencyBar(
                stats = playerStats,
                modifier = Modifier.padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 4.dp)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ScreenRoute.MAIN_MENU -> {
                    MainMenuScreen(
                        onNavigate = { route -> viewModel.navigateTo(route) }
                    )
                }
                ScreenRoute.ADVENTURE -> {
                    AdventureContainerScreen(
                        adventureState = playableAdventureState,
                        onSelectBook = { book -> viewModel.openAdventureStepsList(book) },
                        onSelectDifficulty = { diff -> viewModel.selectAdventureDifficulty(diff) },
                        onStartStep = { etapeIdx -> viewModel.startAdventureStep(etapeIdx) },
                        onReturnToStepsList = { viewModel.returnToAdventureStepsList() },
                        onReturnToWorldMap = { viewModel.openAdventureWorldMap() },
                        onSubmitAnswer = { answer -> viewModel.submitAdventureAnswer(answer) },
                        onNextQuestion = { viewModel.nextAdventureQuestion() },
                        onNextEtape = { viewModel.nextAdventureEtape() },
                        onRestartEtape = { viewModel.restartAdventureEtape() },
                        onUpdateKeyboardInput = { input -> viewModel.updateAdventureKeyboardInput(input) },
                        onToggleRelicGallery = { viewModel.toggleAdventureRelicGallery() },
                        onNavigateBack = { viewModel.navigateTo(ScreenRoute.MAIN_MENU) }
                    )
                }
                ScreenRoute.BOSS -> {
                    BossContainerScreen(
                        stats = playerStats,
                        bossState = playableBossState,
                        onSelectBossGroup = { group -> viewModel.selectBossGroup(group) },
                        onSelectDifficulty = { diff -> viewModel.selectBossDifficulty(diff) },
                        onStartBossBattle = { group, diff -> viewModel.startBossBattle(group, diff) },
                        onExitBossBattle = { viewModel.exitBossBattle() },
                        onSubmitAnswer = { opt -> viewModel.submitBossAnswer(opt) },
                        onNextQuestion = { viewModel.nextBossQuestion() },
                        onRestartBattle = { viewModel.restartBossBattle() },
                        onNavigateBack = { viewModel.navigateTo(ScreenRoute.MAIN_MENU) }
                    )
                }
                ScreenRoute.PAROLE -> {
                    ParoleContainerScreen(
                        stats = playerStats,
                        paroleViewModel = paroleViewModel,
                        onNavigateBack = { viewModel.navigateTo(ScreenRoute.MAIN_MENU) }
                    )
                }
                ScreenRoute.SHOP -> {
                    ShopContainerScreen(
                        stats = playerStats,
                        items = shopItems,
                        onBuyItem = { item -> viewModel.buyShopItem(item) },
                        onNavigateBack = { viewModel.navigateTo(ScreenRoute.MAIN_MENU) }
                    )
                }
                ScreenRoute.CHARACTER -> {
                    CharacterContainerScreen(
                        stats = playerStats,
                        onNavigateBack = { viewModel.navigateTo(ScreenRoute.MAIN_MENU) }
                    )
                }
                ScreenRoute.SETTINGS -> {
                    SettingsContainerScreen(
                        settings = gameSettings,
                        onToggleSfx = { enabled -> viewModel.toggleSfx(enabled) },
                        onToggleMusic = { enabled -> viewModel.toggleMusic(enabled) },
                        onSetDarkMode = { isDark -> viewModel.setDarkMode(isDark) },
                        onTestAttackSound = { viewModel.testPlayAttackSound() },
                        onTestFaithSound = { viewModel.testPlayFaithSound() },
                        onNavigateBack = { viewModel.navigateTo(ScreenRoute.MAIN_MENU) }
                    )
                }
            }
        }
    }
}
