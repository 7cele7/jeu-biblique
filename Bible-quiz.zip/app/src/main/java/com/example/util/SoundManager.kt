package com.example.util

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sin

/**
 * Manages procedural sound effects (SFX) and background music (BGM) for Biblical RPG.
 */
object SoundManager {

    var isSfxEnabled: Boolean = true
    var isMusicEnabled: Boolean = true
        set(value) {
            field = value
            if (value) {
                startBackgroundMusic()
            } else {
                stopBackgroundMusic()
            }
        }

    private var toneGen: ToneGenerator? = null
    private var musicJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    init {
        try {
            toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 100)
        } catch (e: Exception) {
            toneGen = null
        }
    }

    /**
     * Plays a crisp, punchy attack / correct answer sound effect.
     */
    fun playAttackSound() {
        if (!isSfxEnabled) return
        scope.launch {
            try {
                // Ascending retro sword chime (C5 -> E5 -> G5)
                playToneSequence(
                    listOf(
                        Pair(523, 70),
                        Pair(659, 70),
                        Pair(784, 120)
                    )
                )
            } catch (e: Exception) {
                toneGen?.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            }
        }
    }

    /**
     * Plays a low impact damage / wrong answer sound effect.
     */
    fun playDamageSound() {
        if (!isSfxEnabled) return
        scope.launch {
            try {
                // Low descending heavy thud (A3 -> E3 -> A2)
                playToneSequence(
                    listOf(
                        Pair(220, 90),
                        Pair(165, 90),
                        Pair(110, 140)
                    )
                )
            } catch (e: Exception) {
                toneGen?.startTone(ToneGenerator.TONE_CDMA_LOW_L, 180)
            }
        }
    }

    /**
     * Plays a sparkling sound effect for restoring faith / healing.
     */
    fun playFaithRestoreSound() {
        if (!isSfxEnabled) return
        scope.launch {
            try {
                // Ascending magical arpeggio (A4 -> C#5 -> E5 -> A5)
                playToneSequence(
                    listOf(
                        Pair(440, 60),
                        Pair(554, 60),
                        Pair(659, 60),
                        Pair(880, 140)
                    )
                )
            } catch (e: Exception) {
                toneGen?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
            }
        }
    }

    /**
     * Plays a grand victory fanfare.
     */
    fun playVictorySound() {
        if (!isSfxEnabled) return
        scope.launch {
            try {
                playToneSequence(
                    listOf(
                        Pair(523, 100),
                        Pair(659, 100),
                        Pair(784, 100),
                        Pair(1046, 280)
                    )
                )
            } catch (e: Exception) {
                toneGen?.startTone(ToneGenerator.TONE_PROP_PROMPT, 250)
            }
        }
    }

    /**
     * Starts background ambient atmospheric music loop.
     */
    fun startBackgroundMusic() {
        if (!isMusicEnabled) return
        if (musicJob?.isActive == true) return

        musicJob = scope.launch {
            val chords = listOf(
                listOf(261, 329, 392, 523), // C Major
                listOf(220, 261, 329, 440), // A Minor
                listOf(174, 220, 261, 349), // F Major
                listOf(196, 246, 293, 392)  // G Major
            )
            while (isActive && isMusicEnabled) {
                for (chord in chords) {
                    if (!isActive || !isMusicEnabled) break
                    for (freq in chord) {
                        if (!isActive || !isMusicEnabled) break
                        playToneSequence(listOf(Pair(freq, 180)), volume = 0.25f)
                        delay(220)
                    }
                    delay(250)
                }
            }
        }
    }

    /**
     * Stops background ambient atmospheric music loop.
     */
    fun stopBackgroundMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    private fun playToneSequence(tones: List<Pair<Int, Int>>, volume: Float = 0.85f) {
        val sampleRate = 22050
        var totalSamples = 0
        tones.forEach { totalSamples += (sampleRate * it.second) / 1000 }

        if (totalSamples <= 0) return

        val buffer = ShortArray(totalSamples)
        var currentSample = 0

        tones.forEach { (freq, durationMs) ->
            val numSamples = (sampleRate * durationMs) / 1000
            val angleStep = 2.0 * Math.PI * freq / sampleRate
            var angle = 0.0

            for (i in 0 until numSamples) {
                // Smooth envelope fade to avoid pops/clicks
                val fadeIn = if (i < 40) i / 40.0 else 1.0
                val fadeOut = if (i > numSamples - 80) (numSamples - i) / 80.0 else 1.0
                val env = fadeIn * fadeOut

                val wave = sin(angle) + 0.35 * sin(2.0 * angle)
                val sampleValue = (wave * 14000 * volume * env).toInt().coerceIn(-32768, 32767).toShort()

                if (currentSample < buffer.size) {
                    buffer[currentSample++] = sampleValue
                }
                angle += angleStep
            }
        }

        try {
            val minBufSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(buffer.size * 2)

            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(minBufSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack.play()
            audioTrack.write(buffer, 0, buffer.size)

            val totalTime = tones.sumOf { it.second }
            scope.launch {
                delay(totalTime.toLong() + 150L)
                try {
                    audioTrack.stop()
                    audioTrack.release()
                } catch (ignored: Exception) {}
            }
        } catch (e: Exception) {
            tones.firstOrNull()?.let { (_, duration) ->
                toneGen?.startTone(ToneGenerator.TONE_PROP_ACK, duration)
            }
        }
    }
}
