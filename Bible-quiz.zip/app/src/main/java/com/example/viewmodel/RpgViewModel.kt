package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AdventureRepository
import com.example.data.BossJsonRepository
import com.example.model.AdventureBookData
import com.example.model.AdventureChoiceOption
import com.example.model.AdventureEtape
import com.example.model.AdventureQuestion
import com.example.model.AdventureReward
import com.example.model.AdventureSceneState
import com.example.model.BossActionOption
import com.example.model.BossActionType
import com.example.model.BossBattleState
import com.example.model.GameSettings
import com.example.model.PlayableAdventureState
import com.example.model.PlayableBossState
import com.example.model.PlayerStats
import com.example.model.ScreenRoute
import com.example.model.ShopItem
import com.example.util.SoundManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class RpgViewModel(application: Application) : AndroidViewModel(application) {

    private val _currentScreen = MutableStateFlow(ScreenRoute.MAIN_MENU)
    val currentScreen: StateFlow<ScreenRoute> = _currentScreen.asStateFlow()

    private val _gameSettings = MutableStateFlow(GameSettings())
    val gameSettings: StateFlow<GameSettings> = _gameSettings.asStateFlow()

    fun toggleSfx(enabled: Boolean) {
        _gameSettings.update { it.copy(isSfxEnabled = enabled) }
        SoundManager.isSfxEnabled = enabled
    }

    fun toggleMusic(enabled: Boolean) {
        _gameSettings.update { it.copy(isMusicEnabled = enabled) }
        SoundManager.isMusicEnabled = enabled
    }

    fun setDarkMode(isDark: Boolean) {
        _gameSettings.update { it.copy(isDarkMode = isDark) }
    }

    fun testPlayAttackSound() {
        SoundManager.playAttackSound()
    }

    fun testPlayFaithSound() {
        SoundManager.playFaithRestoreSound()
    }

    private val _playerStats = MutableStateFlow(PlayerStats())
    val playerStats: StateFlow<PlayerStats> = _playerStats.asStateFlow()

    private val _adventureState = MutableStateFlow(AdventureSceneState())
    val adventureState: StateFlow<AdventureSceneState> = _adventureState.asStateFlow()

    private val _bossState = MutableStateFlow(BossBattleState())
    val bossState: StateFlow<BossBattleState> = _bossState.asStateFlow()

    private val _playableBossState = MutableStateFlow(PlayableBossState())
    val playableBossState: StateFlow<PlayableBossState> = _playableBossState.asStateFlow()

    private val _playableAdventureState = MutableStateFlow(PlayableAdventureState())
    val playableAdventureState: StateFlow<PlayableAdventureState> = _playableAdventureState.asStateFlow()

    private var timerJob: Job? = null

    private val _shopItems = MutableStateFlow(
        listOf(
            ShopItem(
                id = "rel_1",
                name = "Bâton de Moïse",
                category = "Relique",
                description = "Augmente la Foi de +15 et débloque le pouvoir d'ouverture des eaux.",
                priceGold = 150,
                priceGems = 5,
                statBonus = "+15 Foi"
            ),
            ShopItem(
                id = "arm_1",
                name = "Bouclier de la Foi",
                category = "Armure",
                description = "Réduit les dégâts de tous les adversaires de 25%.",
                priceGold = 200,
                priceGems = 0,
                statBonus = "+20 Défense"
            ),
            ShopItem(
                id = "pot_1",
                name = "Huile d'Onction Sainte",
                category = "Potion",
                description = "Restaure immédiatement 50 PV et 30 Points de Foi.",
                priceGold = 50,
                priceGems = 0,
                statBonus = "+50 PV / +30 Foi"
            ),
            ShopItem(
                id = "rel_2",
                name = "Harpe de David",
                category = "Relique",
                description = "Apaiise la colère des boss et augmente le score d'inspiration.",
                priceGold = 300,
                priceGems = 10,
                statBonus = "+100 Score"
            )
        )
    )
    val shopItems: StateFlow<List<ShopItem>> = _shopItems.asStateFlow()

    init {
        loadBossData()
        loadAdventureData()
    }

    private fun loadAdventureData() {
        val bookMap = AdventureRepository.loadAdventureBooksFromAssets(getApplication())
        val defaultBook = bookMap["Genèse_facile"] ?: bookMap.values.firstOrNull()
        _playableAdventureState.update {
            it.copy(
                bookDataMap = bookMap,
                currentBook = defaultBook,
                selectedBookGroup = defaultBook?.livre ?: "Genèse",
                selectedDifficulty = defaultBook?.niveau ?: "facile",
                currentEtapeIndex = 0,
                currentQuestionIndex = 0
            )
        }
    }

    fun openAdventureWorldMap() {
        _playableAdventureState.update { curr ->
            curr.copy(
                activeViewMode = com.example.model.AdventureViewMode.WORLD_MAP,
                isPlayingStep = false
            )
        }
    }

    fun returnToAdventureWorldMap() {
        openAdventureWorldMap()
    }

    fun openAdventureStepsList(bookName: String) {
        selectAdventureBook(bookName)
        _playableAdventureState.update { curr ->
            curr.copy(
                activeViewMode = com.example.model.AdventureViewMode.STEPS_LIST,
                isPlayingStep = false
            )
        }
    }

    fun selectAdventureBook(bookName: String) {
        val diff = _playableAdventureState.value.selectedDifficulty
        val key = "${bookName}_${diff}"
        val targetBook = _playableAdventureState.value.bookDataMap[key]
            ?: _playableAdventureState.value.bookDataMap["${bookName}_facile"]
            ?: _playableAdventureState.value.bookDataMap.values.find { it.livre.equals(bookName, ignoreCase = true) }

        _playableAdventureState.update {
            it.copy(
                selectedBookGroup = bookName,
                currentBook = targetBook,
                currentEtapeIndex = 0,
                currentQuestionIndex = 0,
                keyboardInput = "",
                selectedOption = null,
                isAnswerChecked = false,
                isCorrect = false,
                feedbackMessage = "",
                referenceText = "",
                isEtapeCompleted = false,
                isBookCompleted = false
            )
        }
    }

    fun selectAdventureDifficulty(difficulty: String) {
        val bookName = _playableAdventureState.value.selectedBookGroup
        val key = "${bookName}_${difficulty}"
        val targetBook = _playableAdventureState.value.bookDataMap[key]
            ?: _playableAdventureState.value.bookDataMap["${bookName}_facile"]

        _playableAdventureState.update {
            it.copy(
                selectedDifficulty = difficulty,
                currentBook = targetBook,
                currentEtapeIndex = 0,
                currentQuestionIndex = 0,
                keyboardInput = "",
                selectedOption = null,
                isAnswerChecked = false,
                isCorrect = false,
                feedbackMessage = "",
                referenceText = "",
                isEtapeCompleted = false,
                isBookCompleted = false
            )
        }
    }

    fun updateAdventureKeyboardInput(input: String) {
        _playableAdventureState.update {
            it.copy(keyboardInput = input)
        }
    }

    fun toggleAdventureRelicGallery() {
        _playableAdventureState.update {
            it.copy(showRelicGallery = !it.showRelicGallery)
        }
    }

    fun getCurrentAdventureEtape(): AdventureEtape? {
        val state = _playableAdventureState.value
        val book = state.currentBook ?: return null
        return book.etapes.getOrNull(state.currentEtapeIndex)
    }

    fun getCurrentAdventureQuestion(): AdventureQuestion? {
        val etape = getCurrentAdventureEtape() ?: return null
        return etape.questions.getOrNull(_playableAdventureState.value.currentQuestionIndex)
    }

    fun submitAdventureAnswer(userAnswer: String) {
        val state = _playableAdventureState.value
        if (state.isAnswerChecked) return

        val currentQ = getCurrentAdventureQuestion() ?: return
        val currentEtape = getCurrentAdventureEtape() ?: return

        val isCorrect = if (currentQ.type == "clavier") {
            isKeyboardAnswerCorrect(userAnswer, currentQ.answer, currentQ.aliases)
        } else {
            userAnswer.trim().equals(currentQ.answer.trim(), ignoreCase = true)
        }

        if (isCorrect) {
            _playerStats.update {
                it.copy(
                    score = it.score + 50,
                    xp = (it.xp + 20).coerceAtMost(it.maxXp),
                    currentFaith = (it.currentFaith + 5).coerceAtMost(it.maxFaith)
                )
            }

            val totalQuestionsInEtape = currentEtape.questions.size
            val isLastQ = state.currentQuestionIndex + 1 >= totalQuestionsInEtape

            if (isLastQ) {
                // Step completed!
                SoundManager.playFaithRestoreSound()
                val reward = currentEtape.recompense
                val updatedUnlocked = if (reward != null && !state.unlockedRewards.any { r -> r.id == reward.id }) {
                    state.unlockedRewards + reward
                } else {
                    state.unlockedRewards
                }

                val book = state.currentBook
                val isLastStepOfBook = book != null && (state.currentEtapeIndex + 1 >= book.totalEtapes)

                if (isLastStepOfBook) {
                    SoundManager.playVictorySound()
                }

                val bookKey = "${state.selectedBookGroup}_${state.selectedDifficulty}"
                val currentUnlocked = state.unlockedEtapesMap[bookKey] ?: 0
                val nextEtapeIndex = state.currentEtapeIndex + 1
                val updatedUnlockedMap = if (nextEtapeIndex > currentUnlocked) {
                    state.unlockedEtapesMap + (bookKey to nextEtapeIndex)
                } else {
                    state.unlockedEtapesMap
                }

                _playableAdventureState.update { curr ->
                    curr.copy(
                        selectedOption = userAnswer,
                        isAnswerChecked = true,
                        isCorrect = true,
                        feedbackMessage = if (reward != null)
                            "🎉 ÉTAPE RÉUSSIE ! Relique débloquée : ${reward.nom} (${reward.verset})"
                        else
                            "🎉 ÉTAPE RÉUSSIE ! Vous avez complété toutes les questions de cette étape.",
                        referenceText = currentQ.reference,
                        unlockedRewards = updatedUnlocked,
                        unlockedEtapesMap = updatedUnlockedMap,
                        isEtapeCompleted = true,
                        isBookCompleted = isLastStepOfBook
                    )
                }
            } else {
                SoundManager.playAttackSound()
                _playableAdventureState.update { curr ->
                    curr.copy(
                        selectedOption = userAnswer,
                        isAnswerChecked = true,
                        isCorrect = true,
                        feedbackMessage = "✨ Bonne réponse ! (+50 Score, +5 Foi)",
                        referenceText = currentQ.reference
                    )
                }
            }
        } else {
            // Wrong answer
            _playerStats.update {
                it.copy(currentFaith = (it.currentFaith - 5).coerceAtLeast(0))
            }
            SoundManager.playDamageSound()

            _playableAdventureState.update { curr ->
                curr.copy(
                    selectedOption = userAnswer,
                    isAnswerChecked = true,
                    isCorrect = false,
                    feedbackMessage = "❌ Mauvaise réponse. La réponse était : \"${currentQ.answer}\" (${currentQ.reference})",
                    referenceText = currentQ.reference
                )
            }
        }
    }

    fun nextAdventureQuestion() {
        val state = _playableAdventureState.value
        val etape = getCurrentAdventureEtape() ?: return
        val nextQIndex = state.currentQuestionIndex + 1

        if (nextQIndex < etape.questions.size) {
            _playableAdventureState.update { curr ->
                curr.copy(
                    currentQuestionIndex = nextQIndex,
                    keyboardInput = "",
                    selectedOption = null,
                    isAnswerChecked = false,
                    isCorrect = false,
                    feedbackMessage = "",
                    referenceText = ""
                )
            }
        }
    }

    fun startAdventureStep(etapeIndex: Int) {
        _playableAdventureState.update { curr ->
            curr.copy(
                currentEtapeIndex = etapeIndex,
                currentQuestionIndex = 0,
                activeViewMode = com.example.model.AdventureViewMode.STEP_QUIZ,
                isPlayingStep = true,
                keyboardInput = "",
                selectedOption = null,
                isAnswerChecked = false,
                isCorrect = false,
                feedbackMessage = "",
                referenceText = "",
                isEtapeCompleted = false
            )
        }
    }

    fun returnToAdventureStepsList() {
        _playableAdventureState.update { curr ->
            curr.copy(
                activeViewMode = com.example.model.AdventureViewMode.STEPS_LIST,
                isPlayingStep = false,
                currentQuestionIndex = 0,
                keyboardInput = "",
                selectedOption = null,
                isAnswerChecked = false,
                isCorrect = false,
                feedbackMessage = "",
                referenceText = "",
                isEtapeCompleted = false
            )
        }
    }

    fun nextAdventureEtape() {
        val state = _playableAdventureState.value
        val book = state.currentBook ?: return
        val nextEtapeIdx = state.currentEtapeIndex + 1

        if (nextEtapeIdx < book.etapes.size) {
            _playableAdventureState.update { curr ->
                curr.copy(
                    currentEtapeIndex = nextEtapeIdx,
                    currentQuestionIndex = 0,
                    keyboardInput = "",
                    selectedOption = null,
                    isAnswerChecked = false,
                    isCorrect = false,
                    feedbackMessage = "",
                    referenceText = "",
                    isEtapeCompleted = false
                )
            }
        }
    }

    fun restartAdventureEtape() {
        _playableAdventureState.update { curr ->
            curr.copy(
                currentQuestionIndex = 0,
                keyboardInput = "",
                selectedOption = null,
                isAnswerChecked = false,
                isCorrect = false,
                feedbackMessage = "",
                referenceText = "",
                isEtapeCompleted = false
            )
        }
    }

    private fun isKeyboardAnswerCorrect(userInput: String, answer: String, aliases: List<String>): Boolean {
        val normalize: (String) -> String = { s ->
            s.trim().lowercase()
                .replace("é", "e").replace("è", "e").replace("ê", "e").replace("ë", "e")
                .replace("à", "a").replace("â", "a").replace("ä", "a")
                .replace("î", "i").replace("ï", "i")
                .replace("ô", "o").replace("ö", "o")
                .replace("ù", "u").replace("û", "u").replace("ü", "u")
                .replace("ç", "c")
        }
        val cleanInput = normalize(userInput)
        if (cleanInput.isEmpty()) return false
        val cleanAnswer = normalize(answer)
        if (cleanAnswer.contains(cleanInput) || cleanInput.contains(cleanAnswer)) return true
        return aliases.any { normalize(it).contains(cleanInput) || cleanInput.contains(normalize(it)) }
    }

    private fun loadBossData() {
        val bossMap = BossJsonRepository.loadBossesFromAssets(getApplication())
        val defaultBoss = bossMap["boss_genese_facile"]
        val qCount = defaultBoss?.questions?.size ?: 7
        _playableBossState.update {
            it.copy(
                bossDataMap = bossMap,
                currentBoss = defaultBoss,
                remainingBossLives = qCount,
                globalTimeSeconds = defaultBoss?.chronoGlobal ?: 60,
                questionTimeSeconds = defaultBoss?.chronoQuestion ?: 15
            )
        }
    }

    fun selectBossGroup(bossGroup: String) {
        _playableBossState.update {
            it.copy(selectedBossGroup = bossGroup)
        }
    }

    fun selectBossDifficulty(difficulty: String) {
        _playableBossState.update {
            it.copy(selectedDifficulty = difficulty)
        }
    }

    fun startBossBattle(bossGroup: String, difficulty: String) {
        val key = "${bossGroup}_${difficulty}"
        val rawBoss = _playableBossState.value.bossDataMap[key]
            ?: _playableBossState.value.bossDataMap["${bossGroup}_facile"]
            ?: _playableBossState.value.bossDataMap["boss_genese_facile"]

        val boss = rawBoss?.let { b ->
            b.copy(
                questions = b.questions.map { q ->
                    q.copy(options = if (q.options.size > 1) q.options.shuffled() else q.options)
                }
            )
        }

        val qCount = boss?.questions?.size ?: 7

        timerJob?.cancel()

        _playableBossState.update {
            PlayableBossState(
                inBattleScreen = true,
                selectedBossGroup = bossGroup,
                selectedDifficulty = difficulty,
                bossDataMap = it.bossDataMap,
                currentBoss = boss,
                currentQuestionIndex = 0,
                remainingBossLives = qCount,
                globalTimeSeconds = boss?.chronoGlobal ?: 60,
                questionTimeSeconds = boss?.chronoQuestion ?: 15,
                battleLogs = listOf("${boss?.bossInfo?.nom ?: "Le Boss"} (${boss?.livre ?: ""}) - Niveau ${difficulty.uppercase()} activé ($qCount questions).")
            )
        }
        startBattleTimer()
    }

    fun exitBossBattle() {
        timerJob?.cancel()
        _playableBossState.update {
            it.copy(inBattleScreen = false)
        }
    }

    fun restartBossBattle() {
        val group = _playableBossState.value.selectedBossGroup
        val diff = _playableBossState.value.selectedDifficulty
        startBossBattle(group, diff)
    }

    fun startBattleTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                val state = _playableBossState.value

                if (state.isGameOver || state.isVictory || state.currentBoss == null) break

                if (state.isAnswerChecked) {
                    // Paused timer while reviewing answer feedback
                    continue
                }

                val newGlobal = state.globalTimeSeconds - 1
                val newQuestionTime = state.questionTimeSeconds - 1

                if (newGlobal <= 0) {
                    // Time out global
                    _playableBossState.update {
                        it.copy(
                            globalTimeSeconds = 0,
                            isGameOver = true,
                            feedbackMessage = "⏱️ Temps global écoulé ! Le Serpent Ancien a triomphé."
                        )
                    }
                    break
                }

                if (newQuestionTime <= 0) {
                    // Time out on question
                    handleQuestionTimeout()
                } else {
                    _playableBossState.update {
                        it.copy(
                            globalTimeSeconds = newGlobal,
                            questionTimeSeconds = newQuestionTime
                        )
                    }
                }
            }
        }
    }

    private fun handleQuestionTimeout() {
        _playerStats.update { current ->
            current.copy(currentFaith = (current.currentFaith - 10).coerceAtLeast(0))
        }

        val isFaithDepleted = _playerStats.value.currentFaith <= 0
        val currentQ = getCurrentQuestion()

        SoundManager.playDamageSound()

        _playableBossState.update { current ->
            current.copy(
                questionTimeSeconds = 0,
                isAnswerChecked = true,
                isCorrect = false,
                feedbackMessage = "⏱️ Temps écoulé ! -10 Points de Foi. Réponse: ${currentQ?.answer}",
                referenceText = currentQ?.reference ?: "",
                isGameOver = isFaithDepleted,
                battleLogs = listOf("Temps dépassé ! Attaque psychologique subie (-10 Foi).") + current.battleLogs.take(4)
            )
        }
    }

    fun submitBossAnswer(option: String) {
        val state = _playableBossState.value
        if (state.isAnswerChecked || state.isGameOver || state.isVictory) return

        val currentQ = getCurrentQuestion() ?: return
        val boss = state.currentBoss ?: return
        val totalQuestions = boss.questions.size
        val isLastQuestion = state.currentQuestionIndex + 1 >= totalQuestions
        val isCorrect = option.trim() == currentQ.answer.trim()

        if (isCorrect) {
            val newLives = (state.remainingBossLives - 1).coerceAtLeast(0)
            val isVictoryNow = isLastQuestion && (newLives <= 0)

            _playerStats.update {
                it.copy(
                    score = it.score + 150,
                    xp = (it.xp + 40).coerceAtMost(it.maxXp)
                )
            }

            if (isVictoryNow) {
                _playerStats.update {
                    it.copy(
                        gold = it.gold + 100,
                        gems = it.gems + 5
                    )
                }
                SoundManager.playAttackSound()
                SoundManager.playVictorySound()
            } else {
                SoundManager.playAttackSound()
            }

            _playableBossState.update { current ->
                current.copy(
                    selectedOption = option,
                    isAnswerChecked = true,
                    isCorrect = true,
                    remainingBossLives = newLives,
                    isVictory = isVictoryNow,
                    feedbackMessage = if (isVictoryNow)
                        "✨ VICTOIRE FINALE ! Boss vaincu à la $totalQuestions e question !"
                    else if (isLastQuestion)
                        "✨ Réponse exacte ! ($totalQuestions e question terminée)"
                    else
                        "✨ Coup réussi ! PV Boss: $newLives/$totalQuestions (${currentQ.reference})",
                    referenceText = currentQ.reference,
                    battleLogs = listOf("⚔️ Attaque réussie ! Le Boss perd 1 PV ($newLives/$totalQuestions restants).") + current.battleLogs.take(4)
                )
            }
        } else {
            // Wrong answer: Lose 10 faith as per boss mechanic "perte de Foi"
            _playerStats.update { current ->
                current.copy(currentFaith = (current.currentFaith - 10).coerceAtLeast(0))
            }
            val isFaithDepleted = _playerStats.value.currentFaith <= 0

            SoundManager.playDamageSound()

            _playableBossState.update { current ->
                current.copy(
                    selectedOption = option,
                    isAnswerChecked = true,
                    isCorrect = false,
                    feedbackMessage = "❌ Mauvaise réponse ! Réponse: ${currentQ.answer} (${currentQ.reference})",
                    referenceText = currentQ.reference,
                    isGameOver = isFaithDepleted,
                    battleLogs = listOf("⚠️ Doute semé dans votre esprit ! -10 Points de Foi.") + current.battleLogs.take(4)
                )
            }
        }
    }

    fun nextBossQuestion() {
        val state = _playableBossState.value
        val boss = state.currentBoss ?: return
        val totalQuestions = boss.questions.size
        val nextIdx = state.currentQuestionIndex + 1

        if (nextIdx >= totalQuestions) {
            // All questions have been answered
            if (state.remainingBossLives <= 0) {
                SoundManager.playVictorySound()
                // Victory: Boss defeated after completing all questions
                _playableBossState.update { current ->
                    current.copy(
                        isVictory = true,
                        feedbackMessage = "🏆 VICTOIRE ÉCLATANTE ! Les $totalQuestions questions sont épuisées et le Boss est terrassé !"
                    )
                }
            } else {
                SoundManager.playDamageSound()
                // Game Over: Questions exhausted but Boss still has HP remaining
                _playableBossState.update { current ->
                    current.copy(
                        isGameOver = true,
                        feedbackMessage = "💀 DÉFAITE : Les $totalQuestions questions sont épuisées mais le Boss a survécu avec ${current.remainingBossLives} PV !"
                    )
                }
            }
        } else {
            // Move to next question
            _playableBossState.update { current ->
                current.copy(
                    currentQuestionIndex = nextIdx,
                    questionTimeSeconds = boss.chronoQuestion,
                    selectedOption = null,
                    isAnswerChecked = false,
                    isCorrect = false,
                    feedbackMessage = "",
                    referenceText = ""
                )
            }
        }
    }

    fun getCurrentQuestion() = _playableBossState.value.currentBoss?.questions?.getOrNull(_playableBossState.value.currentQuestionIndex)

    fun navigateTo(route: ScreenRoute) {
        _currentScreen.value = route
        if (route == ScreenRoute.BOSS) {
            _playableBossState.update { it.copy(inBattleScreen = false) }
        } else {
            timerJob?.cancel()
        }
    }

    fun onAdventureChoiceSelected(choice: AdventureChoiceOption) {
        _playerStats.update { current ->
            current.copy(
                score = current.score + 50,
                xp = (current.xp + 20).coerceAtMost(current.maxXp),
                currentFaith = (current.currentFaith + 5).coerceAtMost(current.maxFaith)
            )
        }
        SoundManager.playFaithRestoreSound()
        _adventureState.update { current ->
            current.copy(
                narrativeText = "Choix retenu: [${choice.label}].\n\n(L'interface est prête à charger le prochain noeud du fichier JSON)"
            )
        }
    }

    fun onBossActionSelected(action: BossActionOption) {
        when (action.type) {
            BossActionType.ATTACK -> {
                SoundManager.playAttackSound()
                _bossState.update { current ->
                    val newHp = (current.currentHp - 45).coerceAtLeast(0)
                    val log = "Vous frappez avec conviction ! Goliath subit 45 dégâts."
                    current.copy(
                        currentHp = newHp,
                        battleLogs = listOf(log) + current.battleLogs.take(3)
                    )
                }
            }
            BossActionType.HOLY_ABILITY -> {
                if (_playerStats.value.currentFaith >= action.faithCost) {
                    SoundManager.playAttackSound()
                    _playerStats.update { it.copy(currentFaith = it.currentFaith - action.faithCost) }
                    _bossState.update { current ->
                        val newHp = (current.currentHp - 80).coerceAtLeast(0)
                        val log = "Rayon de Lumière Sainte ! Goliath subit 80 dégâts."
                        current.copy(
                            currentHp = newHp,
                            battleLogs = listOf(log) + current.battleLogs.take(3)
                        )
                    }
                } else {
                    SoundManager.playDamageSound()
                }
            }
            BossActionType.DEFEND -> {
                SoundManager.playFaithRestoreSound()
                _bossState.update { current ->
                    val log = "Posture défensive adoptée. Prochaine attaque atténuée."
                    current.copy(
                        battleLogs = listOf(log) + current.battleLogs.take(3)
                    )
                }
            }
            BossActionType.ITEM -> {
                SoundManager.playFaithRestoreSound()
                _playerStats.update { it.copy(currentHp = (it.currentHp + 30).coerceAtMost(it.maxHp)) }
                _bossState.update { current ->
                    val log = "Potion de soin utilisée. Vous récupérez 30 PV."
                    current.copy(
                        battleLogs = listOf(log) + current.battleLogs.take(3)
                    )
                }
            }
        }
    }

    fun buyShopItem(item: ShopItem) {
        val currentGold = _playerStats.value.gold
        if (currentGold >= item.priceGold && !item.isPurchased) {
            _playerStats.update { it.copy(gold = it.gold - item.priceGold) }
            _shopItems.update { list ->
                list.map { if (it.id == item.id) it.copy(isPurchased = true) else it }
            }
        }
    }
}

