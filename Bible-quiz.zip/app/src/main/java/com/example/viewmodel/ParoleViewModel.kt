package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ParoleJsonRepository
import com.example.model.PlayableParoleState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ParoleViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("parole_mode_prefs", Context.MODE_PRIVATE)

    private val _paroleState = MutableStateFlow(PlayableParoleState())
    val paroleState: StateFlow<PlayableParoleState> = _paroleState.asStateFlow()

    init {
        loadPersistedProgress()
    }

    private fun loadPersistedProgress() {
        val totalPoints = sharedPrefs.getInt("total_points", 0)
        
        // Charger étoiles et niveaux terminés
        val allKeys = sharedPrefs.all
        val starsMap = mutableMapOf<String, Int>()
        val completedFacile = mutableSetOf<Int>()
        val completedInter = mutableSetOf<Int>()
        val completedExpert = mutableSetOf<Int>()

        for ((key, value) in allKeys) {
            if (key.startsWith("stars_") && value is Int) {
                val cleanKey = key.removePrefix("stars_")
                starsMap[cleanKey] = value
                
                val parts = cleanKey.split("_")
                if (parts.size == 2) {
                    val diff = parts[0]
                    val lvl = parts[1].toIntOrNull() ?: continue
                    when (diff) {
                        "facile" -> completedFacile.add(lvl)
                        "intermediaire" -> completedInter.add(lvl)
                        "expert" -> completedExpert.add(lvl)
                    }
                }
            }
        }

        _paroleState.update { current ->
            current.copy(
                totalAccumulatedPoints = totalPoints,
                levelStars = starsMap,
                completedLevels = mapOf(
                    "facile" to completedFacile,
                    "intermediaire" to completedInter,
                    "expert" to completedExpert
                )
            )
        }
    }

    private fun saveProgress(difficulty: String, levelNumber: Int, earnedScore: Int, stars: Int) {
        val currentTotal = sharedPrefs.getInt("total_points", 0) + earnedScore
        val key = "${difficulty}_$levelNumber"
        val existingStars = sharedPrefs.getInt("stars_$key", 0)

        with(sharedPrefs.edit()) {
            putInt("total_points", currentTotal)
            if (stars > existingStars) {
                putInt("stars_$key", stars)
            }
            apply()
        }

        loadPersistedProgress()
    }

    fun loadAvailableLevels(context: Context) {
        viewModelScope.launch {
            val levelsMap = ParoleJsonRepository.scanAvailableLevels(context)
            _paroleState.update { current ->
                current.copy(availableLevelsByDiff = levelsMap)
            }
        }
    }

    fun selectDifficulty(difficulty: String) {
        _paroleState.update { current ->
            current.copy(selectedDifficulty = difficulty)
        }
    }

    fun startLevel(context: Context, difficulty: String, levelNumber: Int) {
        viewModelScope.launch {
            val levelData = ParoleJsonRepository.loadLevel(context, difficulty, levelNumber)
            if (levelData != null && levelData.questions.isNotEmpty()) {
                _paroleState.update { current ->
                    current.copy(
                        isSessionActive = true,
                        selectedDifficulty = difficulty,
                        selectedLevelNumber = levelNumber,
                        currentLevelData = levelData,
                        currentQuestionIndex = 0,
                        selectedOption = null,
                        isAnswerChecked = false,
                        isCorrect = false,
                        feedbackMessage = "",
                        score = 0,
                        correctCount = 0,
                        streak = 0,
                        maxStreak = 0,
                        pointsEarnedLastQuestion = 0,
                        isCompleted = false
                    )
                }
            }
        }
    }

    fun selectOption(option: String) {
        val state = _paroleState.value
        if (state.isAnswerChecked) return

        _paroleState.update { current ->
            current.copy(selectedOption = option)
        }
    }

    fun validateAnswer() {
        val state = _paroleState.value
        val questions = state.currentLevelData?.questions ?: return
        if (state.currentQuestionIndex !in questions.indices) return
        val currentQ = questions[state.currentQuestionIndex]
        val selected = state.selectedOption ?: return

        val isCorrect = selected.trim().equals(currentQ.bonneReponse.trim(), ignoreCase = true)
        
        // Multiplicateur selon la difficulté
        val difficultyMultiplier = when (state.selectedDifficulty) {
            "expert" -> 1.5f
            "intermediaire" -> 1.25f
            else -> 1.0f
        }

        val basePoints = 100
        val newStreak = if (isCorrect) state.streak + 1 else 0
        val streakBonus = if (isCorrect && newStreak > 1) (newStreak - 1) * 20 else 0
        
        val earnedScore = if (isCorrect) {
            ((basePoints + streakBonus) * difficultyMultiplier).toInt()
        } else {
            0
        }

        val feedback = if (isCorrect) {
            if (newStreak >= 3) {
                "🔥 Série x$newStreak ! +$earnedScore pts (Bonus Combo +$streakBonus)"
            } else {
                "✨ Bravo ! Bonne réponse ! +$earnedScore pts"
            }
        } else {
            "❌ Incorrect. La bonne réponse est : ${currentQ.bonneReponse}"
        }

        _paroleState.update { current ->
            val updatedScore = current.score + earnedScore
            current.copy(
                isAnswerChecked = true,
                isCorrect = isCorrect,
                feedbackMessage = feedback,
                score = updatedScore,
                correctCount = if (isCorrect) current.correctCount + 1 else current.correctCount,
                streak = newStreak,
                maxStreak = maxOf(current.maxStreak, newStreak),
                pointsEarnedLastQuestion = earnedScore
            )
        }
    }

    fun nextQuestion() {
        val state = _paroleState.value
        val questions = state.currentLevelData?.questions ?: return
        val nextIndex = state.currentQuestionIndex + 1

        if (nextIndex < questions.size) {
            _paroleState.update { current ->
                current.copy(
                    currentQuestionIndex = nextIndex,
                    selectedOption = null,
                    isAnswerChecked = false,
                    isCorrect = false,
                    feedbackMessage = "",
                    pointsEarnedLastQuestion = 0
                )
            }
        } else {
            // Fin du niveau
            val totalQuestions = questions.size
            val correct = state.correctCount
            val successRate = (correct.toFloat() / totalQuestions.toFloat() * 100).toInt()
            val stars = when {
                successRate >= 90 -> 3
                successRate >= 65 -> 2
                successRate >= 40 -> 1
                else -> 0
            }

            // Sauvegarder la progression
            saveProgress(state.selectedDifficulty, state.selectedLevelNumber, state.score, stars)

            _paroleState.update { current ->
                current.copy(
                    isCompleted = true,
                    isAnswerChecked = false,
                    selectedOption = null
                )
            }
        }
    }

    fun exitSession() {
        _paroleState.update { current ->
            current.copy(
                isSessionActive = false,
                currentLevelData = null,
                currentQuestionIndex = 0,
                selectedOption = null,
                isAnswerChecked = false,
                isCompleted = false,
                score = 0,
                correctCount = 0,
                streak = 0
            )
        }
    }
}
