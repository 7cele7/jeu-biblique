package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BossData
import com.example.model.PlayableBossState
import com.example.model.PlayerStats
import com.example.ui.components.HeaderCurrencyBar
import com.example.ui.components.RpgActionButton
import com.example.ui.components.RpgFrameCard
import com.example.ui.components.RpgProgressBar
import com.example.ui.theme.CrimsonAccent
import com.example.ui.theme.DarkObsidianBg
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.HealthGreen
import com.example.ui.theme.ManaBlue
import com.example.ui.theme.TextGoldOnDark

@Composable
fun BossContainerScreen(
    stats: PlayerStats,
    bossState: PlayableBossState,
    onSelectBossGroup: (String) -> Unit,
    onSelectDifficulty: (String) -> Unit,
    onStartBossBattle: (group: String, diff: String) -> Unit,
    onExitBossBattle: () -> Unit,
    onSubmitAnswer: (String) -> Unit,
    onNextQuestion: () -> Unit,
    onRestartBattle: () -> Unit,
    onNavigateBack: () -> Unit
) {
    if (bossState.inBattleScreen && bossState.currentBoss != null) {
        // Fullscreen Boss Battle View
        BossBattleView(
            stats = stats,
            bossState = bossState,
            onSubmitAnswer = onSubmitAnswer,
            onNextQuestion = onNextQuestion,
            onRestartBattle = onRestartBattle,
            onExitBossBattle = onExitBossBattle
        )
    } else {
        // Boss Hub & Selection Screen View
        BossSelectionScreen(
            stats = stats,
            bossState = bossState,
            onSelectBossGroup = onSelectBossGroup,
            onSelectDifficulty = onSelectDifficulty,
            onStartBossBattle = onStartBossBattle,
            onNavigateBack = onNavigateBack
        )
    }
}

/**
 * Screen 1: Dedicated Boss Selection Lobby listing all biblical bosses
 */
@Composable
private fun BossSelectionScreen(
    stats: PlayerStats,
    bossState: PlayableBossState,
    onSelectBossGroup: (String) -> Unit,
    onSelectDifficulty: (String) -> Unit,
    onStartBossBattle: (group: String, diff: String) -> Unit,
    onNavigateBack: () -> Unit
) {
    // Group all loaded bosses by prefix (e.g. "boss_genese", "boss_exode") and sort chronologically
    val distinctBossGroups = remember(bossState.bossDataMap) {
        val map = LinkedHashMap<String, BossData>()
        bossState.bossDataMap.forEach { (key, data) ->
            val prefix = key.substringBeforeLast("_")
            if (!map.containsKey(prefix) || data.niveau == "facile") {
                map[prefix] = data
            }
        }
        val sortedMap = LinkedHashMap<String, BossData>()
        map.entries.sortedBy { it.value.ordre }.forEach { (k, v) ->
            sortedMap[k] = v
        }
        sortedMap
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidianBg)
            .padding(12.dp)
    ) {
        // Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurfaceElevated,
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, GoldPrimary.copy(0.6f), RoundedCornerShape(12.dp))
                    .padding(vertical = 8.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("btn_boss_selection_back")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "ARÈNE DES BOSS BIBLIQUES",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = CrimsonAccent,
                            fontSize = 16.sp,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "Sélectionnez un Boss et défiez l'histoire",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = GoldSecondary,
                            fontSize = 11.sp
                        )
                    )
                }

                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Currency Bar
        HeaderCurrencyBar(stats = stats)

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "CHOISISSEZ VOTRE ADVERSAIRE :",
            style = MaterialTheme.typography.labelMedium.copy(
                color = GoldPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.sp
            ),
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
        )

        // List of Boss Cards
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(distinctBossGroups.entries.toList()) { entry ->
                val groupKey = entry.key
                val sampleBoss = entry.value

                var currentSelectedDifficulty by remember { mutableStateOf("facile") }

                BossSelectionCard(
                    bossGroupKey = groupKey,
                    bossData = sampleBoss,
                    selectedDifficulty = currentSelectedDifficulty,
                    onDifficultyChange = { diff -> currentSelectedDifficulty = diff },
                    onStartBattle = { onStartBossBattle(groupKey, currentSelectedDifficulty) }
                )
            }
        }
    }
}

private fun getBossDrawableResId(groupKey: String, livre: String, bossName: String): Int? {
    return when {
        groupKey.contains("genese", ignoreCase = true) || livre.contains("Genèse", ignoreCase = true) || bossName.contains("Serpent", ignoreCase = true) -> R.drawable.img_boss_serpent
        groupKey.contains("exode", ignoreCase = true) || livre.contains("Exode", ignoreCase = true) || bossName.contains("Pharaon", ignoreCase = true) -> R.drawable.img_boss_pharaon
        groupKey.contains("levitique", ignoreCase = true) || livre.contains("Lévitique", ignoreCase = true) || bossName.contains("Azazel", ignoreCase = true) -> R.drawable.img_boss_azazel
        groupKey.contains("nombres", ignoreCase = true) || livre.contains("Nombres", ignoreCase = true) || bossName.contains("Balaam", ignoreCase = true) -> R.drawable.img_boss_balaam
        groupKey.contains("deuteronome", ignoreCase = true) || livre.contains("Deutéronome", ignoreCase = true) || bossName.contains("dieux", ignoreCase = true) -> R.drawable.img_boss_dieux_nations
        groupKey.contains("josue", ignoreCase = true) || livre.contains("Josué", ignoreCase = true) || bossName.contains("Jéricho", ignoreCase = true) -> R.drawable.img_boss_jericho_1786574400188
        groupKey.contains("juges", ignoreCase = true) || livre.contains("Juges", ignoreCase = true) || bossName.contains("Sisera", ignoreCase = true) -> R.drawable.img_boss_sisera_1786574408587
        groupKey.contains("1samuel", ignoreCase = true) || livre.contains("1 Samuel", ignoreCase = true) || bossName.contains("Goliath", ignoreCase = true) -> R.drawable.img_boss_goliath_1786574419009
        groupKey.contains("2samuel", ignoreCase = true) || livre.contains("2 Samuel", ignoreCase = true) || bossName.contains("Absalom", ignoreCase = true) -> R.drawable.img_boss_absalom_1786574429703
        groupKey.contains("1rois", ignoreCase = true) || livre.contains("1 Rois", ignoreCase = true) || bossName.contains("Jézabel", ignoreCase = true) -> R.drawable.img_boss_jezabel_1786574439733
        groupKey.contains("2rois", ignoreCase = true) || livre.contains("2 Rois", ignoreCase = true) || bossName.contains("Athalie", ignoreCase = true) -> R.drawable.img_boss_athalie_1786574450186
        groupKey.contains("1chroniques", ignoreCase = true) || livre.contains("1 Chroniques", ignoreCase = true) || bossName.contains("Philistins", ignoreCase = true) -> R.drawable.img_boss_philistins_1786574459929
        groupKey.contains("2chroniques", ignoreCase = true) || livre.contains("2 Chroniques", ignoreCase = true) || bossName.contains("Manassé", ignoreCase = true) -> R.drawable.img_boss_manasse_1786574468997
        else -> null
    }
}

@Composable
private fun BossCharacterCardIllustration(
    bossGroupKey: String,
    bossData: BossData,
    modifier: Modifier = Modifier
) {
    val resId = remember(bossGroupKey, bossData) {
        getBossDrawableResId(bossGroupKey, bossData.livre, bossData.bossInfo.nom)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF231422),
                        Color(0xFF0C050D)
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(GoldPrimary, CrimsonAccent)
                ),
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        if (resId != null) {
            Image(
                painter = painterResource(id = resId),
                contentDescription = bossData.bossInfo.nom,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Vignette & gradient overlay for high contrast
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.4f),
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            )
        } else {
            // Fallback for future bosses without custom generated drawables
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = bossData.bossInfo.emoji.ifEmpty { "⚔️" },
                    fontSize = 52.sp
                )
            }
        }

        // Bottom Carved Golden Banner Ribbon (Inspired directly by the reference image)
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp)
                .padding(horizontal = 12.dp),
            color = Color(0xFF2B1D0C),
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.5.dp, GoldPrimary)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = bossData.bossInfo.nom,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = GoldLight,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 0.5.sp
                    ),
                    maxLines = 1
                )
                Text(
                    text = "— ${bossData.livre} —",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}

/**
 * Card representing a biblical boss entry in the selection list
 */
@Composable
private fun BossSelectionCard(
    bossGroupKey: String,
    bossData: BossData,
    selectedDifficulty: String,
    onDifficultyChange: (String) -> Unit,
    onStartBattle: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_boss_selection_$bossGroupKey"),
        color = DarkSurfaceElevated,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.5.dp, GoldPrimary.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // 2D Character Card Artwork Presentation
            BossCharacterCardIllustration(
                bossGroupKey = bossGroupKey,
                bossData = bossData,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Subtitle & Reference
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = bossData.bossInfo.titre,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = CrimsonAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                )

                Text(
                    text = "Ref: ${bossData.bossInfo.verset}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldSecondary,
                        fontSize = 11.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(
                text = bossData.bossInfo.description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                ),
                maxLines = 3
            )

            if (bossData.bossInfo.mecanique.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color.Black.copy(0.4f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlashOn,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = bossData.bossInfo.mecanique,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GoldLight,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Difficulty Selector Pills
            Text(
                text = "DIFFICULTÉ DU COMBAT :",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GoldSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 1.sp
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                DifficultyCard(
                    levelKey = "facile",
                    title = "Facile",
                    details = "60s | 15s/Q",
                    selectedKey = selectedDifficulty,
                    accentColor = HealthGreen,
                    modifier = Modifier.weight(1f),
                    onSelect = onDifficultyChange
                )

                DifficultyCard(
                    levelKey = "intermediaire",
                    title = "Moyen",
                    details = "50s | 12s/Q",
                    selectedKey = selectedDifficulty,
                    accentColor = GoldPrimary,
                    modifier = Modifier.weight(1f),
                    onSelect = onDifficultyChange
                )

                DifficultyCard(
                    levelKey = "expert",
                    title = "Expert",
                    details = "40s | 10s/Q",
                    selectedKey = selectedDifficulty,
                    accentColor = CrimsonAccent,
                    modifier = Modifier.weight(1f),
                    onSelect = onDifficultyChange
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // CTA Button to Launch Battle
            Button(
                onClick = onStartBattle,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("btn_start_battle_$bossGroupKey"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CrimsonAccent
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "COMBATTRE ${bossData.bossInfo.nom.uppercase()} (${selectedDifficulty.uppercase()})",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp
                        )
                    )
                }
            }
        }
    }
}

/**
 * Screen 2: Dedicated Boss Battle Screen with Scrollable Question Area and Fixed Next Button
 */
@Composable
private fun BossBattleView(
    stats: PlayerStats,
    bossState: PlayableBossState,
    onSubmitAnswer: (String) -> Unit,
    onNextQuestion: () -> Unit,
    onRestartBattle: () -> Unit,
    onExitBossBattle: () -> Unit
) {
    val currentBoss = bossState.currentBoss
    val currentQ = currentBoss?.questions?.getOrNull(bossState.currentQuestionIndex)
    val totalQuestions = currentBoss?.questions?.size ?: 7

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidianBg)
            .padding(6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 1. Battle Top Header (Back button, Boss Title, Timers)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = DarkSurfaceElevated,
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CrimsonAccent.copy(0.7f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onExitBossBattle,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("btn_boss_battle_exit")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Quitter le combat",
                            tint = GoldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${currentBoss?.bossInfo?.nom ?: "Boss"} • ${currentBoss?.livre ?: ""}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = CrimsonAccent,
                                fontSize = 13.sp
                            )
                        )
                        Text(
                            text = "Niveau: ${bossState.selectedDifficulty.uppercase()} ($totalQuestions Qs)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = GoldLight,
                                fontSize = 10.sp
                            )
                        )
                    }

                    // Global & Question Timers
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TimerBadge(
                            icon = Icons.Default.Timer,
                            time = "${bossState.globalTimeSeconds}s",
                            color = if (bossState.globalTimeSeconds <= 15) CrimsonAccent else GoldPrimary,
                            testTag = "timer_global"
                        )
                        TimerBadge(
                            icon = Icons.Default.Psychology,
                            time = "${bossState.questionTimeSeconds}s",
                            color = if (bossState.questionTimeSeconds <= 5) CrimsonAccent else ManaBlue,
                            testTag = "timer_question"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            // 2. Combined Combat Status Dashboard (Boss HP & Player Stats: PV & Points de Foi)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = DarkSurfaceElevated,
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GoldPrimary.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val currentBossResId = remember(currentBoss) {
                        if (currentBoss != null) {
                            getBossDrawableResId("", currentBoss.livre, currentBoss.bossInfo.nom)
                        } else null
                    }

                    // Boss Avatar & HP
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(0.6f))
                                .border(1.dp, CrimsonAccent, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (currentBossResId != null) {
                                Image(
                                    painter = painterResource(id = currentBossResId),
                                    contentDescription = currentBoss?.bossInfo?.nom,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text(
                                    text = currentBoss?.bossInfo?.emoji ?: "⚔️",
                                    fontSize = 15.sp
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = currentBoss?.bossInfo?.nom ?: "Boss",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = TextGoldOnDark,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    ),
                                    maxLines = 1
                                )
                                Text(
                                    text = "${bossState.remainingBossLives}/$totalQuestions",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = HealthGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(1.dp))

                            BossHealthBar(
                                remainingLives = bossState.remainingBossLives,
                                maxLives = totalQuestions,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    // Vertical Divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(26.dp)
                            .background(GoldPrimary.copy(alpha = 0.3f))
                    )

                    // Player Stats (PV & Points de Foi)
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        RpgProgressBar(
                            label = "PV",
                            currentValue = stats.currentHp,
                            maxValue = stats.maxHp,
                            fillColor = HealthGreen,
                            barHeight = 7.dp,
                            fontSize = 9.sp,
                            testTag = "bar_player_hp"
                        )

                        RpgProgressBar(
                            label = "FOI",
                            currentValue = stats.currentFaith,
                            maxValue = stats.maxFaith,
                            fillColor = ManaBlue,
                            barHeight = 7.dp,
                            fontSize = 9.sp,
                            testTag = "bar_player_faith"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            // 2b. Battle Log Overlay Card (Journal de combat)
            BattleLogOverlayCard(
                logs = bossState.battleLogs,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(3.dp))

            // 3. Question & Answers Section (Scrollable container so Next button is never blocked)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                if (currentQ != null) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        // Question Header Phase
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = Color(0xFF2A1C08),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, GoldPrimary)
                            ) {
                                Text(
                                    text = "PHASE: ${currentQ.phase.replace("_", " ").uppercase()}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = GoldLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = "Question ${bossState.currentQuestionIndex + 1} / $totalQuestions",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = GoldSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Question Frame Card
                        RpgFrameCard(
                            title = "DÉFI SPIRITUEL",
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("card_boss_question")
                        ) {
                            Text(
                                text = currentQ.question,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = TextGoldOnDark,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    lineHeight = 17.sp
                                ),
                                textAlign = TextAlign.Start,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Option Buttons
                        currentQ.options.forEachIndexed { index, option ->
                            val isSelected = bossState.selectedOption == option
                            val isCorrectOption = option.trim() == currentQ.answer.trim()

                            val btnBg = when {
                                bossState.isAnswerChecked && isCorrectOption -> HealthGreen.copy(alpha = 0.25f)
                                bossState.isAnswerChecked && isSelected && !bossState.isCorrect -> CrimsonAccent.copy(alpha = 0.25f)
                                isSelected -> GoldPrimary.copy(alpha = 0.2f)
                                else -> DarkSurfaceElevated
                            }

                            val btnBorderColor = when {
                                bossState.isAnswerChecked && isCorrectOption -> HealthGreen
                                bossState.isAnswerChecked && isSelected && !bossState.isCorrect -> CrimsonAccent
                                isSelected -> GoldPrimary
                                else -> Color.Gray.copy(alpha = 0.3f)
                            }

                            Surface(
                                onClick = {
                                    if (!bossState.isAnswerChecked) {
                                        onSubmitAnswer(option)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 1.dp)
                                    .testTag("opt_boss_$index"),
                                color = btnBg,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, btnBorderColor)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${('A' + index)}.  $option",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = if (isSelected) GoldLight else Color.White,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 12.sp
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )

                                    if (bossState.isAnswerChecked) {
                                        if (isCorrectOption) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = "Correct",
                                                tint = HealthGreen,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        } else if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Default.Cancel,
                                                contentDescription = "Incorrect",
                                                tint = CrimsonAccent,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Answer Checked Box & Next Button
                    if (bossState.isAnswerChecked) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            PointsGainBanner(
                                isCorrect = bossState.isCorrect,
                                isVictory = bossState.isVictory
                            )

                            // Feedback Message
                            Surface(
                                color = if (bossState.isCorrect) Color(0xFF142E14) else Color(0xFF381414),
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, if (bossState.isCorrect) HealthGreen else CrimsonAccent)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding( horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = bossState.feedbackMessage,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (bossState.isCorrect) HealthGreen else CrimsonAccent,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (bossState.referenceText.isNotEmpty()) {
                                        Text(
                                            text = "📖 ${bossState.referenceText}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = GoldLight,
                                                fontSize = 10.sp
                                            )
                                        )
                                    }
                                }
                            }

                            // Prominent Next Question Button
                            Button(
                                onClick = onNextQuestion,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(42.dp)
                                    .testTag("btn_boss_next_q"),
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "QUESTION SUIVANTE",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            color = Color.Black,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 13.sp
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        tint = Color.Black,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // Victory Overlay
        if (bossState.isVictory) {
            BossResultOverlay(
                title = "VICTOIRE SACRÉE !",
                subtitle = "Vous avez triomphé du ${currentBoss?.bossInfo?.nom ?: "Boss"} et épuisé les $totalQuestions questions !",
                accentColor = HealthGreen,
                icon = Icons.Default.EmojiEvents,
                onRestart = onRestartBattle,
                onExit = onExitBossBattle
            )
        }

        // Game Over Overlay
        if (bossState.isGameOver && !bossState.isVictory) {
            BossResultOverlay(
                title = "DÉFAITE...",
                subtitle = bossState.feedbackMessage.ifEmpty { "Le temps est écoulé ou l'épreuve n'a pas été surmontée." },
                accentColor = CrimsonAccent,
                icon = Icons.Default.Cancel,
                onRestart = onRestartBattle,
                onExit = onExitBossBattle
            )
        }
    }
}

@Composable
private fun TimerBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    time: String,
    color: Color,
    testTag: String
) {
    Surface(
        modifier = Modifier.testTag(testTag),
        color = Color.Black.copy(alpha = 0.5f),
        shape = RoundedCornerShape(5.dp),
        border = BorderStroke(0.8.dp, color)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(11.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = time,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            )
        }
    }
}

@Composable
private fun BossHealthBar(
    remainingLives: Int,
    maxLives: Int,
    modifier: Modifier = Modifier
) {
    val progress = (remainingLives.toFloat() / maxLives.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 600),
        label = "BossHP"
    )

    Column(modifier = modifier) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(7.dp),
            shape = RoundedCornerShape(4.dp),
            color = Color.Black.copy(alpha = 0.6f),
            border = BorderStroke(0.8.dp, HealthGreen.copy(alpha = 0.6f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(1.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(animatedProgress)
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(HealthGreen, Color(0xFF66BB6A))
                            ),
                            shape = RoundedCornerShape(3.dp)
                        )
                )
            }
        }
    }
}

@Composable
private fun DifficultyCard(
    levelKey: String,
    title: String,
    details: String,
    selectedKey: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onSelect: (String) -> Unit
) {
    val isSelected = selectedKey == levelKey

    Surface(
        onClick = { onSelect(levelKey) },
        modifier = modifier.testTag("btn_diff_$levelKey"),
        color = if (isSelected) accentColor.copy(alpha = 0.25f) else Color.Black.copy(alpha = 0.35f),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(if (isSelected) 1.5.dp else 0.5.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) GoldLight else Color.LightGray,
                    fontSize = 11.sp
                )
            )
            Text(
                text = details,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = accentColor,
                    fontSize = 9.sp
                )
            )
        }
    }
}

@Composable
private fun PointsGainBanner(
    isCorrect: Boolean,
    isVictory: Boolean
) {
    if (!isCorrect) return

    val scale by animateFloatAsState(
        targetValue = 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "PointsBannerScale"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .testTag("points_gain_banner"),
        color = Color(0xFF1B381B),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, HealthGreen)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = Color(0xFFFFB300),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "+150 SCORE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = GoldLight,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                )
            }

            Text(
                text = "•",
                style = MaterialTheme.typography.bodyMedium.copy(color = HealthGreen, fontWeight = FontWeight.Bold)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "+40 XP",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = GoldLight,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                )
            }

            if (isVictory) {
                Text(
                    text = "•",
                    style = MaterialTheme.typography.bodyMedium.copy(color = HealthGreen, fontWeight = FontWeight.Bold)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "+100 OR",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun BossResultOverlay(
    title: String,
    subtitle: String,
    accentColor: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onRestart: () -> Unit,
    onExit: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurfaceElevated,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(2.dp, accentColor)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(60.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = accentColor,
                        fontWeight = FontWeight.Black
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.LightGray,
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onRestart,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_boss_restart"),
                        colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                    ) {
                        Text(
                            text = "REJOUER",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Button(
                        onClick = onExit,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_boss_exit_modal"),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkObsidianBg),
                        border = BorderStroke(1.dp, GoldPrimary)
                    ) {
                        Text(
                            text = "SECTEURS",
                            style = MaterialTheme.typography.labelLarge.copy(
                                color = GoldLight,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Scrollable Battle Log Overlay display during Boss encounter
 */
@Composable
private fun BattleLogOverlayCard(
    logs: List<String>,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.testTag("card_battle_logs"),
        color = Color(0xFF140D18),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CrimsonAccent.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "JOURNAL DE COMBAT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            letterSpacing = 0.5.sp
                        )
                    )
                }

                Text(
                    text = "${logs.size} évts",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color.Gray,
                        fontSize = 9.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Scrollable log messages container
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 24.dp, max = 36.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                logs.forEachIndexed { index, log ->
                    val textColor = when {
                        log.contains("Réussi", ignoreCase = true) || log.contains("VICTOIRE", ignoreCase = true) || log.contains("150", ignoreCase = true) -> HealthGreen
                        log.contains("Mauvaise", ignoreCase = true) || log.contains("subie", ignoreCase = true) || log.contains("Doute", ignoreCase = true) || log.contains("-10", ignoreCase = true) -> CrimsonAccent
                        index == 0 -> GoldLight
                        else -> Color.LightGray
                    }

                    Text(
                        text = log,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = textColor,
                            fontSize = 10.sp,
                            fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Normal,
                            lineHeight = 13.sp
                        )
                    )
                }
            }
        }
    }
}
