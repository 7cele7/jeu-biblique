package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.TextGoldOnDark

@Composable
fun RpgFrameCard(
    modifier: Modifier = Modifier,
    title: String? = null,
    testTag: String = "rpg_card",
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier
            .testTag(testTag)
            .fillMaxWidth(),
        color = DarkSurfaceCard,
        shape = RoundedCornerShape(12.dp),
        tonalElevation = 4.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(GoldPrimary, GoldSecondary.copy(alpha = 0.4f), GoldPrimary)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (!title.isNullOrEmpty()) {
                    Text(
                        text = title.uppercase(),
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldLight,
                            fontSize = 13.sp,
                            letterSpacing = 1.sp
                        ),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                content()
            }
        }
    }
}

@Composable
fun RpgActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    isPrimary: Boolean = true,
    testTag: String = "rpg_action_button"
) {
    val bgBrush = if (isPrimary) {
        Brush.horizontalGradient(listOf(GoldPrimary, GoldSecondary))
    } else {
        Brush.horizontalGradient(listOf(DarkSurfaceElevated, Color(0xFF1E2132)))
    }

    val textColor = if (isPrimary) Color(0xFF141208) else TextGoldOnDark
    val borderColor = if (isPrimary) GoldLight else GoldSecondary.copy(alpha = 0.6f)

    Surface(
        modifier = modifier
            .testTag(testTag)
            .fillMaxWidth()
            .defaultMinSize(minHeight = 38.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(8.dp),
        shadowElevation = if (isPrimary) 3.dp else 1.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(bgBrush)
                .border(1.dp, borderColor, RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = textColor,
                        modifier = Modifier
                            .size(18.dp)
                            .padding(end = 4.dp)
                    )
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = textColor
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun RpgProgressBar(
    label: String,
    currentValue: Int,
    maxValue: Int,
    fillColor: Color,
    modifier: Modifier = Modifier,
    barHeight: androidx.compose.ui.unit.Dp = 12.dp,
    fontSize: androidx.compose.ui.unit.TextUnit = 13.sp,
    testTag: String = "rpg_progress_bar"
) {
    val progress = (currentValue.toFloat() / maxValue.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "progressAnimation")

    Column(modifier = modifier.testTag(testTag)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = fontSize
                )
            )
            Text(
                text = "$currentValue / $maxValue",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextGoldOnDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = fontSize
                )
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(barHeight)
                .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                .border(0.5.dp, GoldSecondary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedProgress)
                    .background(
                        Brush.horizontalGradient(
                            listOf(fillColor, fillColor.copy(alpha = 0.7f))
                        ),
                        RoundedCornerShape(6.dp)
                    )
            )
        }
    }
}
