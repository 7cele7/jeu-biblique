package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlayerStats
import com.example.model.ScreenRoute
import com.example.ui.components.HeaderCurrencyBar
import com.example.ui.components.RpgActionButton
import com.example.ui.theme.DarkObsidianBg
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.TextGoldOnDark

@Composable
fun MainMenuScreen(
    onNavigate: (ScreenRoute) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidianBg)
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Banner Header Title
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.3f)
                .testTag("menu_title_banner"),
            color = DarkSurfaceElevated,
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(
                        width = 1.5.dp,
                        brush = Brush.verticalGradient(listOf(GoldPrimary, GoldSecondary.copy(0.3f))),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "RPG BIBLIQUE",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = GoldLight,
                            letterSpacing = 2.sp,
                            fontSize = 24.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "CHRONIQUES DE LA FOI",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldSecondary,
                            letterSpacing = 1.5.sp,
                            fontSize = 12.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3. Scalable Game Mode Navigation Menu
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.72f),
            verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            RpgActionButton(
                text = "MODE AVENTURE",
                icon = Icons.Default.Book,
                isPrimary = true,
                onClick = { onNavigate(ScreenRoute.ADVENTURE) },
                testTag = "btn_mode_adventure"
            )

            RpgActionButton(
                text = "COMBAT DE BOSS",
                icon = Icons.Default.Shield,
                isPrimary = true,
                onClick = { onNavigate(ScreenRoute.BOSS) },
                testTag = "btn_mode_boss"
            )

            RpgActionButton(
                text = "MODE PAROLE",
                icon = Icons.Default.Book,
                isPrimary = true,
                onClick = { onNavigate(ScreenRoute.PAROLE) },
                testTag = "btn_mode_parole"
            )

            RpgActionButton(
                text = "LA BOUTIQUE (SHOP)",
                icon = Icons.Default.ShoppingBag,
                isPrimary = false,
                onClick = { onNavigate(ScreenRoute.SHOP) },
                testTag = "btn_mode_shop"
            )

            RpgActionButton(
                text = "HEROS & INVENTAIRE",
                icon = Icons.Default.Person,
                isPrimary = false,
                onClick = { onNavigate(ScreenRoute.CHARACTER) },
                testTag = "btn_mode_character"
            )

            RpgActionButton(
                text = "PARAMÈTRES & JSON",
                icon = Icons.Default.Settings,
                isPrimary = false,
                onClick = { onNavigate(ScreenRoute.SETTINGS) },
                testTag = "btn_mode_settings"
            )
        }
    }
}
