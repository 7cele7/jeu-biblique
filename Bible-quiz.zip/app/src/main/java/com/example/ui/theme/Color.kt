package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Biblical RPG Theme Palette
val GoldPrimary = Color(0xFFE5C158)
val GoldSecondary = Color(0xFFC59A2B)
val GoldLight = Color(0xFFFFF0BC)

val CrimsonAccent = Color(0xFFD32F2F)
val BronzeDark = Color(0xFF4A3410)

val DarkObsidianBg = Color(0xFF0F111A)
val DarkSurfaceCard = Color(0xFF1B1E2E)
val DarkSurfaceElevated = Color(0xFF282C42)

val ParchmentLightBg = Color(0xFFF9F5EA)
val ParchmentCard = Color(0xFFEFE9D5)

val TextGoldOnDark = Color(0xFFFDF1D0)
val TextDark = Color(0xFF1C1917)
val HealthGreen = Color(0xFF4CAF50)
val ManaBlue = Color(0xFF2196F3)
val XPPurple = Color(0xFF9C27B0)

