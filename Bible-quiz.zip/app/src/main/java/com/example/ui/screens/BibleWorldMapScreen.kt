package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.BibleBookInfo
import com.example.data.BibleBooksCatalog
import com.example.data.Testament
import com.example.model.PlayableAdventureState
import com.example.ui.theme.DarkObsidianBg
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.TextGoldOnDark

@Composable
fun BibleWorldMapScreen(
    adventureState: PlayableAdventureState,
    onSelectBook: (String) -> Unit,
    onToggleRelicGallery: () -> Unit,
    onNavigateBack: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterTab by remember { mutableStateOf("ALL") } // ALL, OT, NT
    var selectedInfoBook by remember { mutableStateOf<BibleBookInfo?>(null) }

    val listState = rememberLazyListState()

    // Filter books
    val booksToDisplay = remember(searchQuery, selectedFilterTab, adventureState.bookDataMap) {
        BibleBooksCatalog.ALL_66_BOOKS.filter { book ->
            val matchesTab = when (selectedFilterTab) {
                "OT" -> book.testament == Testament.ANCIEN_TESTAMENT
                "NT" -> book.testament == Testament.NOUVEAU_TESTAMENT
                else -> true
            }
            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                book.name.contains(searchQuery, ignoreCase = true) ||
                        book.displayName.contains(searchQuery, ignoreCase = true) ||
                        book.category.contains(searchQuery, ignoreCase = true) ||
                        book.order.toString() == searchQuery.trim()
            }
            matchesTab && matchesSearch
        }
    }

    // Determine current playing book progression info
    val currentBookName = adventureState.selectedBookGroup
    val bookKey = "${currentBookName}_${adventureState.selectedDifficulty}"
    val unlockedCount = (adventureState.unlockedEtapesMap[bookKey] ?: 0) + 1
    val progressPercent = ((unlockedCount.toFloat() / 13f) * 100).toInt().coerceAtMost(100)

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Biblical Territories Map Background Image
        Image(
            painter = painterResource(id = R.drawable.img_bible_world_map_1786530059586),
            contentDescription = "Les Territoires Bibliques",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Subtle Dark Parchment Vignette Tint Overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xCC0D0B14),
                            Color(0x770D0B14),
                            Color(0xDD0D0B14)
                        )
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 70.dp) // Leave space for floating progression panel
        ) {
            // ============================================================
            // 1. TOP TITLE HEADER BAR
            // ============================================================
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                color = DarkSurfaceElevated,
                shape = RoundedCornerShape(12.dp),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GoldSecondary.copy(0.4f), RoundedCornerShape(12.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.testTag("btn_map_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Retour",
                                tint = GoldPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Explore,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "CARTE DU MONDE BIBLIQUE",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = GoldLight,
                                        fontSize = 15.sp,
                                        letterSpacing = 1.sp
                                    )
                                )
                            }
                            Text(
                                text = "QUÊTE DE LA PAROLE ÉTERNELLE • 66 LIVRES",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.Gray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        IconButton(
                            onClick = onToggleRelicGallery,
                            modifier = Modifier.testTag("btn_map_relics")
                        ) {
                            Icon(
                                imageVector = Icons.Default.EmojiEvents,
                                contentDescription = "Reliques",
                                tint = GoldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    // Search Input Field
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("input_search_books"),
                        placeholder = {
                            Text("Rechercher un livre (ex: Genèse, Psaumes, 66)...", color = Color.Gray, fontSize = 12.sp)
                        },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = GoldSecondary, modifier = Modifier.size(18.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Effacer", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = GoldSecondary.copy(0.4f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Black.copy(0.4f),
                            unfocusedContainerColor = Color.Black.copy(0.4f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Testament Filter Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MapFilterChip(
                            label = "Tous (66)",
                            isSelected = selectedFilterTab == "ALL",
                            onClick = { selectedFilterTab = "ALL" }
                        )
                        MapFilterChip(
                            label = "Ancien Testament (39)",
                            isSelected = selectedFilterTab == "OT",
                            onClick = { selectedFilterTab = "OT" }
                        )
                        MapFilterChip(
                            label = "Nouveau Testament (27)",
                            isSelected = selectedFilterTab == "NT",
                            onClick = { selectedFilterTab = "NT" }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // ============================================================
            // 2. WORLD MAP SCROLLABLE PATH (66 NODES CONNECTED ALONG PATH)
            // ============================================================
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                itemsIndexed(booksToDisplay) { index, book ->
                    val isJsonAvailable = adventureState.bookDataMap.keys.any { key ->
                        key.startsWith("${book.name}_", ignoreCase = true) ||
                                key.startsWith("${book.displayName}_", ignoreCase = true)
                    } || book.hasJsonData

                    val isCurrentPlayingBook = book.name.equals(currentBookName, ignoreCase = true) ||
                            book.displayName.equals(currentBookName, ignoreCase = true)

                    // Alternating node alignment for winding path effect (Left / Center / Right)
                    val alignment = when (index % 3) {
                        0 -> Alignment.CenterStart
                        1 -> Alignment.Center
                        else -> Alignment.CenterEnd
                    }

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = alignment
                        ) {
                            BookMapNodeCard(
                                book = book,
                                isAvailable = isJsonAvailable,
                                isCurrentBook = isCurrentPlayingBook,
                                onClick = {
                                    if (isJsonAvailable) {
                                        onSelectBook(book.name)
                                    } else {
                                        selectedInfoBook = book
                                    }
                                }
                            )
                        }

                        // Path connector to next node
                        if (index < booksToDisplay.size - 1) {
                            MapPathConnector(
                                isAvailable = isJsonAvailable
                            )
                        }
                    }
                }
            }
        }

        // ============================================================
        // 3. BOTTOM OVERLAY PANELS (Matching Screenshot)
        // ============================================================
        // Bottom Left: "PROGRESSION" panel
        Surface(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
                .testTag("panel_map_progression"),
            color = DarkSurfaceElevated.copy(0.95f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(0.6f)),
            shadowElevation = 10.dp
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "PROGRESSION",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = GoldSecondary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 1.sp
                    )
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Livre en cours : ",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                    Text(
                        text = currentBookName.uppercase(),
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { progressPercent / 100f },
                        modifier = Modifier
                            .width(80.dp)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = GoldPrimary,
                        trackColor = Color.DarkGray
                    )
                    Text(
                        text = "$progressPercent%",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "🌿 Relique obtenue : ",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "${adventureState.unlockedRewards.size} / 39",
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Bottom Right: "RÉCOMPENSES" chest badge button
        Surface(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp)
                .clickable { onToggleRelicGallery() }
                .testTag("btn_map_rewards"),
            color = DarkSurfaceElevated.copy(0.95f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldLight),
            shadowElevation = 10.dp
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Récompenses",
                        tint = GoldPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    if (adventureState.unlockedRewards.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(14.dp)
                                .background(Color.Red, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${adventureState.unlockedRewards.size}",
                                color = Color.White,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Text(
                    text = "RÉCOMPENSES",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = GoldLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp
                    )
                )
            }
        }

        // ============================================================
        // 4. UNLOADED BOOK DIALOG (When clicking a book node without JSON)
        // ============================================================
        selectedInfoBook?.let { book ->
            Dialog(onDismissRequest = { selectedInfoBook = null }) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .padding(12.dp),
                    color = DarkSurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Badge Order Header
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(GoldSecondary.copy(0.2f), RoundedCornerShape(12.dp))
                                .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${book.order}",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    color = GoldLight,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }

                        Text(
                            text = book.name,
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = GoldLight,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        )

                        Text(
                            text = "${book.testament.displayName} • ${book.category} • ${book.totalEtapes} Étapes",
                            color = GoldSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Surface(
                            color = Color.Black.copy(0.4f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = book.description.ifEmpty { "Livre canonique de la Sainte Bible." },
                                color = TextGoldOnDark,
                                fontSize = 12.sp,
                                fontStyle = FontStyle.Italic,
                                modifier = Modifier.padding(10.dp),
                                textAlign = TextAlign.Center
                            )
                        }

                        // Info message
                        Surface(
                            color = Color(0xFF2C2416),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "📜 Ce livre est déjà enregistré sur la carte du monde ! Son fichier JSON de questions/réponses sera chargé très prochainement.",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Play available books shortcut button
                        Button(
                            onClick = {
                                selectedInfoBook = null
                                onSelectBook("GENÈSE")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("🎮 Jouer les livres disponibles (Genèse / Exode)", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MapFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(
                if (isSelected) GoldPrimary.copy(0.3f) else Color.Transparent,
                RoundedCornerShape(16.dp)
            )
            .border(
                1.dp,
                if (isSelected) GoldLight else GoldSecondary.copy(0.3f),
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) GoldLight else Color.Gray,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

@Composable
private fun BookMapNodeCard(
    book: BibleBookInfo,
    isAvailable: Boolean,
    isCurrentBook: Boolean,
    onClick: () -> Unit
) {
    val borderColor = when {
        isCurrentBook -> GoldLight
        isAvailable -> GoldPrimary
        else -> Color.DarkGray.copy(0.5f)
    }

    val cardBg = when {
        isCurrentBook -> Color(0xFF332610)
        isAvailable -> DarkSurfaceElevated
        else -> Color(0xFF16161A)
    }

    Card(
        modifier = Modifier
            .width(260.dp)
            .clickable { onClick() }
            .testTag("book_node_${book.order}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        border = androidx.compose.foundation.BorderStroke(
            if (isCurrentBook) 2.dp else 1.dp,
            borderColor
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isAvailable) 6.dp else 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Number Badge Shield
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(
                        if (isAvailable) GoldPrimary else Color(0xFF2C2C2C),
                        RoundedCornerShape(10.dp)
                    )
                    .border(
                        1.dp,
                        if (isAvailable) GoldLight else Color.Gray,
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${book.order}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = if (isAvailable) Color.Black else Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                )
            }

            // Book Details
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = book.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isAvailable) GoldLight else Color.Gray,
                            fontSize = 14.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    if (!isAvailable) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Verrouillé",
                            tint = Color.Gray,
                            modifier = Modifier.size(14.dp)
                        )
                    } else if (isCurrentBook) {
                        Surface(
                            color = GoldPrimary,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "EN COURS",
                                color = Color.Black,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }

                Text(
                    text = "${book.totalEtapes} étapes • ${book.category}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (isAvailable) TextGoldOnDark else Color.DarkGray,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun MapPathConnector(
    isAvailable: Boolean
) {
    Canvas(
        modifier = Modifier
            .width(4.dp)
            .height(20.dp)
    ) {
        val pathEffect = if (!isAvailable) PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f) else null
        drawLine(
            color = if (isAvailable) GoldPrimary.copy(0.7f) else Color.Gray.copy(0.3f),
            start = Offset(size.width / 2, 0f),
            end = Offset(size.width / 2, size.height),
            strokeWidth = 3.dp.toPx(),
            pathEffect = pathEffect
        )
    }
}
