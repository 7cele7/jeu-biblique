package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlayerStats
import com.example.ui.components.HeaderCurrencyBar
import com.example.ui.components.RpgFrameCard
import com.example.ui.theme.DarkObsidianBg
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.TextGoldOnDark

@Composable
fun CharacterContainerScreen(
    stats: PlayerStats,
    onNavigateBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidianBg)
            .padding(10.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Navigation Top Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            color = DarkSurfaceElevated,
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldSecondary.copy(0.5f), RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("btn_char_back")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = GoldPrimary
                    )
                }

                Text(
                    text = "PROFIL DU HÉROS & INVENTAIRE",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = GoldLight,
                        fontSize = 12.sp
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )

                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = GoldSecondary,
                    modifier = Modifier.padding(end = 8.dp)
                )
            }
        }

        // 3. Hero Avatar & Primary Attributes
        RpgFrameCard(
            title = "Serviteur de la Lumière",
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.45f),
            testTag = "char_profile_card"
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(Color.Black.copy(0.4f), CircleShape)
                        .border(2.dp, GoldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Hero Avatar",
                        tint = GoldPrimary,
                        modifier = Modifier.size(42.dp)
                    )
                }

                Spacer(modifier = Modifier.size(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StatRow("Niveau:", "${stats.level} (Paladin Sacré)")
                    StatRow("Points de Foi:", "${stats.currentFaith} / ${stats.maxFaith}")
                    StatRow("Points de Vie:", "${stats.currentHp} / ${stats.maxHp}")
                    StatRow("Puissance Spirituelle:", "78 PTS")
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 4. Equipped Inventory Slots Preview
        RpgFrameCard(
            title = "Équipement Actif",
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.55f),
            testTag = "char_inventory_card"
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
            ) {
                EquippedSlotRow("Main Droite:", "Bâton de Moïse (+15 Foi)", Icons.Default.AutoAwesome)
                EquippedSlotRow("Main Gauche:", "Bouclier de la Foi (+20 Déf)", Icons.Default.Shield)
                EquippedSlotRow("Armure:", "Cotte de Mailles d'Argent", Icons.Default.Shield)
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = GoldSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextGoldOnDark,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

@Composable
private fun EquippedSlotRow(slotLabel: String, itemName: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.Black.copy(0.3f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .border(0.5.dp, GoldSecondary.copy(0.3f), RoundedCornerShape(8.dp))
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = GoldPrimary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.size(8.dp))
            Text(
                text = "$slotLabel ",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = GoldSecondary,
                    fontSize = 11.sp
                )
            )
            Text(
                text = itemName,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextGoldOnDark,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            )
        }
    }
}
