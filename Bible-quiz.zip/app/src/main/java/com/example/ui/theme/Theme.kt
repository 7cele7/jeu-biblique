package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = GoldPrimary,
  onPrimary = DarkObsidianBg,
  primaryContainer = BronzeDark,
  onPrimaryContainer = GoldLight,
  secondary = GoldSecondary,
  onSecondary = Color.White,
  tertiary = CrimsonAccent,
  onTertiary = Color.White,
  background = DarkObsidianBg,
  onBackground = TextGoldOnDark,
  surface = DarkSurfaceCard,
  onSurface = TextGoldOnDark,
  surfaceVariant = DarkSurfaceElevated,
  onSurfaceVariant = GoldLight,
  outline = GoldSecondary
)

private val LightColorScheme = lightColorScheme(
  primary = GoldSecondary,
  onPrimary = Color.White,
  primaryContainer = GoldLight,
  onPrimaryContainer = BronzeDark,
  secondary = CrimsonAccent,
  onSecondary = Color.White,
  tertiary = BronzeDark,
  onTertiary = Color.White,
  background = ParchmentLightBg,
  onBackground = TextDark,
  surface = ParchmentCard,
  onSurface = TextDark,
  surfaceVariant = Color.White,
  onSurfaceVariant = TextDark,
  outline = GoldSecondary
)

@Composable
fun BiblicalRpgTheme(
  darkTheme: Boolean = true, // Default to rich dark RPG canvas
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit
) {
  BiblicalRpgTheme(darkTheme = true, content = content)
}

