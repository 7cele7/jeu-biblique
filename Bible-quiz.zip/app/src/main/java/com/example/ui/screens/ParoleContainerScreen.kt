package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ParoleQuestionType
import com.example.model.PlayableParoleState
import com.example.model.PlayerStats
import com.example.ui.components.RpgActionButton
import com.example.ui.theme.*
import com.example.viewmodel.ParoleViewModel

@Composable
fun ParoleContainerScreen(
    stats: PlayerStats,
    paroleViewModel: ParoleViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val state by paroleViewModel.paroleState.collectAsState()

    LaunchedEffect(Unit) {
        paroleViewModel.loadAvailableLevels(context)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        DarkObsidianBg,
                        DarkSurfaceCard,
                        Color(0xFF0D1424)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = {
                        if (state.isSessionActive) {
                            paroleViewModel.exitSession()
                        } else {
                            onNavigateBack()
                        }
                    },
                    modifier = Modifier.testTag("btn_parole_back")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Retour",
                        tint = GoldPrimary
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "MODE PAROLE",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = GoldLight,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = if (state.isSessionActive) {
                            "${state.selectedDifficulty.uppercase()} — NIVEAU ${state.selectedLevelNumber}"
                        } else {
                            "Mémorisation & Étude des Versets"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = GoldSecondary,
                            fontSize = 11.sp
                        )
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GoldPrimary.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (state.isSessionActive) "${state.score} pts" else "${state.totalAccumulatedPoints} pts total",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = GoldLight
                            )
                        )
                    }
                }
            }

            if (!state.isSessionActive) {
                // Écran de sélection de difficulté et de niveau (Niveau 1, Niveau 2, etc.)
                ParoleLevelSelectionView(
                    state = state,
                    onSelectDifficulty = { diff -> paroleViewModel.selectDifficulty(diff) },
                    onStartLevel = { diff, levelNum ->
                        paroleViewModel.startLevel(context, diff, levelNum)
                    }
                )
            } else if (state.isCompleted) {
                // Écran de résultat du niveau (Bilan 12 questions)
                ParoleCompletedView(
                    state = state,
                    onRestart = {
                        paroleViewModel.startLevel(context, state.selectedDifficulty, state.selectedLevelNumber)
                    },
                    onNextLevel = {
                        paroleViewModel.startLevel(context, state.selectedDifficulty, state.selectedLevelNumber + 1)
                    },
                    onExit = { paroleViewModel.exitSession() }
                )
            } else {
                // Question active (1 parmi les 12)
                ParoleQuestionView(
                    state = state,
                    onSelect = { option -> paroleViewModel.selectOption(option) },
                    onValidate = { paroleViewModel.validateAnswer() },
                    onNext = { paroleViewModel.nextQuestion() }
                )
            }
        }
    }
}

@Composable
private fun ParoleLevelSelectionView(
    state: PlayableParoleState,
    onSelectDifficulty: (String) -> Unit,
    onStartLevel: (difficulty: String, levelNum: Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Sélecteur d'onglets de difficulté (Facile, Intermédiaire, Expert)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "facile" to "Facile",
                "intermediaire" to "Intermédiaire",
                "expert" to "Expert"
            ).forEach { (key, label) ->
                val isSelected = state.selectedDifficulty == key
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) GoldPrimary else DarkSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) GoldLight else GoldSecondary.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelectDifficulty(key) }
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) DarkObsidianBg else Color(0xFFCBD5E1)
                            )
                        )
                    }
                }
            }
        }

        // Grille des niveaux pour la difficulté choisie
        val availableLevels = state.availableLevelsByDiff[state.selectedDifficulty] ?: emptyList()

        if (availableLevels.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkSurfaceElevated)
                    .border(1.dp, GoldSecondary.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Book,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "En attente des fichiers JSON",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldLight
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Placez vos fichiers dans assets/parole/${state.selectedDifficulty}/ (ex: niveau_01.json) avec 12 questions par niveau.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFF94A3B8),
                            lineHeight = 16.sp
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(availableLevels) { levelNum ->
                    val key = "${state.selectedDifficulty}_$levelNum"
                    val stars = state.levelStars[key] ?: 0
                    val isCompleted = stars > 0

                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = DarkSurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isCompleted) GoldLight.copy(alpha = 0.8f) else GoldPrimary.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onStartLevel(state.selectedDifficulty, levelNum) }
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = if (isCompleted) GoldPrimary.copy(alpha = 0.35f) else GoldPrimary.copy(alpha = 0.15f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "$levelNum",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = GoldLight
                                        )
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Niveau $levelNum",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )

                            // Étoiles obtenues
                            Row(
                                modifier = Modifier.padding(top = 4.dp),
                                horizontalArrangement = Arrangement.Center
                            ) {
                                (1..3).forEach { starIndex ->
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = if (starIndex <= stars) GoldLight else Color(0xFF334155),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ParoleQuestionView(
    state: PlayableParoleState,
    onSelect: (String) -> Unit,
    onValidate: () -> Unit,
    onNext: () -> Unit
) {
    val questions = state.currentLevelData?.questions ?: emptyList()
    if (state.currentQuestionIndex !in questions.indices) return

    val currentQ = questions[state.currentQuestionIndex]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Barre de progression (1 à 12 questions)
        LinearProgressIndicator(
            progress = { (state.currentQuestionIndex + 1).toFloat() / questions.size.toFloat() },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = GoldPrimary,
            trackColor = Color(0xFF1E293B)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Badge du type de question & Compteur
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = when (currentQ.type) {
                    ParoleQuestionType.VERSET_REFERENCE -> Color(0xFF1D4ED8).copy(alpha = 0.25f)
                    ParoleQuestionType.REFERENCE_VERSET -> Color(0xFF047857).copy(alpha = 0.25f)
                    ParoleQuestionType.COMPLETER_VERSET -> Color(0xFFB45309).copy(alpha = 0.25f)
                },
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    when (currentQ.type) {
                        ParoleQuestionType.VERSET_REFERENCE -> Color(0xFF60A5FA).copy(alpha = 0.5f)
                        ParoleQuestionType.REFERENCE_VERSET -> Color(0xFF34D399).copy(alpha = 0.5f)
                        ParoleQuestionType.COMPLETER_VERSET -> GoldPrimary.copy(alpha = 0.5f)
                    }
                )
            ) {
                Text(
                    text = when (currentQ.type) {
                        ParoleQuestionType.VERSET_REFERENCE -> "Verset ➔ Trouver la référence"
                        ParoleQuestionType.REFERENCE_VERSET -> "Référence ➔ Trouver le verset"
                        ParoleQuestionType.COMPLETER_VERSET -> "Compléter le verset"
                    },
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = GoldLight,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Text(
                text = "Question ${state.currentQuestionIndex + 1} / ${questions.size}",
                style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFF94A3B8))
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Carte principale de la question
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (currentQ.type == ParoleQuestionType.REFERENCE_VERSET) {
                    Text(
                        text = currentQ.reference,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = GoldLight,
                            letterSpacing = 1.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Quel est le texte exact correspondant à cette référence ?",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF94A3B8)),
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        text = "« ${currentQ.verset ?: ""} »",
                        style = MaterialTheme.typography.bodyLarge.copy(
                            color = Color.White,
                            lineHeight = 22.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Liste des 4 propositions (mélangées)
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(currentQ.options) { option ->
                val isSelected = state.selectedOption == option
                val isCorrectAnswer = option.trim().equals(currentQ.bonneReponse.trim(), ignoreCase = true)

                val backgroundColor = when {
                    state.isAnswerChecked && isCorrectAnswer -> Color(0xFF065F46) // Vert
                    state.isAnswerChecked && isSelected && !state.isCorrect -> Color(0xFF991B1B) // Rouge
                    isSelected -> GoldPrimary.copy(alpha = 0.25f)
                    else -> DarkSurfaceCard
                }

                val borderColor = when {
                    state.isAnswerChecked && isCorrectAnswer -> Color(0xFF34D399)
                    state.isAnswerChecked && isSelected && !state.isCorrect -> Color(0xFFEF4444)
                    isSelected -> GoldPrimary
                    else -> Color(0xFF334155)
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = backgroundColor,
                    border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = !state.isAnswerChecked) { onSelect(option) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = if (isSelected) GoldPrimary else Color(0xFF1E293B),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (state.isAnswerChecked && isCorrectAnswer) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = DarkObsidianBg,
                                        modifier = Modifier.size(16.dp)
                                    )
                                } else if (state.isAnswerChecked && isSelected && !state.isCorrect) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = option,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (isSelected || (state.isAnswerChecked && isCorrectAnswer)) Color.White else Color(0xFFCBD5E1),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Message de retour après validation
        AnimatedVisibility(
            visible = state.isAnswerChecked,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (state.isCorrect) Color(0xFF065F46).copy(alpha = 0.3f) else Color(0xFF991B1B).copy(alpha = 0.3f),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (state.isCorrect) Color(0xFF34D399) else Color(0xFFEF4444)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
            ) {
                Text(
                    text = state.feedbackMessage,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        if (!state.isAnswerChecked) {
            RpgActionButton(
                text = "VALIDER LA RÉPONSE",
                icon = Icons.Default.CheckCircle,
                isPrimary = state.selectedOption != null,
                onClick = onValidate,
                testTag = "btn_parole_validate"
            )
        } else {
            RpgActionButton(
                text = if (state.currentQuestionIndex + 1 < questions.size) "QUESTION SUIVANTE" else "TERMINER LE NIVEAU",
                icon = Icons.Default.ArrowForward,
                isPrimary = true,
                onClick = onNext,
                testTag = "btn_parole_next"
            )
        }
    }
}

@Composable
private fun ParoleCompletedView(
    state: PlayableParoleState,
    onRestart: () -> Unit,
    onNextLevel: () -> Unit,
    onExit: () -> Unit
) {
    val totalQuestions = state.currentLevelData?.questions?.size ?: 12
    val successRate = (state.correctCount.toFloat() / totalQuestions.toFloat() * 100).toInt()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = GoldPrimary.copy(alpha = 0.2f),
            border = androidx.compose.foundation.BorderStroke(2.dp, GoldPrimary),
            modifier = Modifier.size(80.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(44.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "Niveau ${state.selectedLevelNumber} Terminé !",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.Black,
                color = GoldLight
            )
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Difficulté : ${state.selectedDifficulty.uppercase()}",
            style = MaterialTheme.typography.bodyLarge.copy(color = GoldSecondary)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Étoiles obtenues
                val stars = when {
                    successRate >= 90 -> 3
                    successRate >= 65 -> 2
                    successRate >= 40 -> 1
                    else -> 0
                }

                Row(
                    modifier = Modifier.padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    (1..3).forEach { starIndex ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (starIndex <= stars) GoldLight else Color(0xFF334155),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                Text(
                    text = "SCORE DU NIVEAU",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF94A3B8),
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "+${state.score} pts",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = GoldLight
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${state.correctCount} / $totalQuestions justes ($successRate%) • Meilleur combo: x${state.maxStreak}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (successRate >= 70) Color(0xFF34D399) else GoldSecondary
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = GoldPrimary.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "Total Cumulé : ${state.totalAccumulatedPoints} points",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = GoldLight,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        val availableLevels = state.availableLevelsByDiff[state.selectedDifficulty] ?: emptyList()
        val hasNextLevel = (state.selectedLevelNumber + 1) in availableLevels

        if (hasNextLevel) {
            RpgActionButton(
                text = "NIVEAU SUIVANT",
                icon = Icons.Default.ArrowForward,
                isPrimary = true,
                onClick = onNextLevel,
                testTag = "btn_parole_next_level"
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        RpgActionButton(
            text = "REJOUER CE NIVEAU",
            icon = Icons.Default.Refresh,
            isPrimary = !hasNextLevel,
            onClick = onRestart,
            testTag = "btn_parole_restart"
        )

        Spacer(modifier = Modifier.height(10.dp))

        RpgActionButton(
            text = "LISTE DES NIVEAUX",
            icon = Icons.Default.GridView,
            isPrimary = false,
            onClick = onExit,
            testTag = "btn_parole_exit_list"
        )
    }
}
