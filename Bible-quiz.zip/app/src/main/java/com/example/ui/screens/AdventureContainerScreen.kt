package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AdventureEtape
import com.example.model.AdventureQuestion
import com.example.model.AdventureReward
import com.example.model.PlayableAdventureState
import com.example.ui.components.RpgActionButton
import com.example.ui.components.RpgFrameCard
import com.example.ui.theme.DarkObsidianBg
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.TextGoldOnDark

@Composable
fun AdventureContainerScreen(
    adventureState: PlayableAdventureState,
    onSelectBook: (String) -> Unit,
    onSelectDifficulty: (String) -> Unit,
    onStartStep: (Int) -> Unit,
    onReturnToStepsList: () -> Unit,
    onReturnToWorldMap: () -> Unit,
    onSubmitAnswer: (String) -> Unit,
    onNextQuestion: () -> Unit,
    onNextEtape: () -> Unit,
    onRestartEtape: () -> Unit,
    onUpdateKeyboardInput: (String) -> Unit,
    onToggleRelicGallery: () -> Unit,
    onNavigateBack: () -> Unit
) {
    if (adventureState.activeViewMode == com.example.model.AdventureViewMode.WORLD_MAP) {
        BibleWorldMapScreen(
            adventureState = adventureState,
            onSelectBook = onSelectBook,
            onToggleRelicGallery = onToggleRelicGallery,
            onNavigateBack = onNavigateBack
        )
        return
    }

    val book = adventureState.currentBook
    val currentEtape: AdventureEtape? = book?.etapes?.getOrNull(adventureState.currentEtapeIndex)
    val currentQ: AdventureQuestion? = currentEtape?.questions?.getOrNull(adventureState.currentQuestionIndex)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkObsidianBg)
            .padding(6.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Bar Navigation & Header
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                color = DarkSurfaceElevated,
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, GoldSecondary.copy(0.4f), RoundedCornerShape(10.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = {
                                if (adventureState.isPlayingStep) {
                                    onReturnToStepsList()
                                } else {
                                    onReturnToWorldMap()
                                }
                            },
                            modifier = Modifier.testTag("btn_adventure_back")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Retour",
                                tint = GoldPrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "📖 ",
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = (book?.livre ?: adventureState.selectedBookGroup).uppercase(),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = GoldLight,
                                        fontSize = 16.sp
                                    )
                                )
                            }
                            Text(
                                text = "${book?.totalEtapes ?: 13} Étapes • Niveau ${adventureState.selectedDifficulty.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!adventureState.isPlayingStep) {
                                Button(
                                    onClick = onReturnToWorldMap,
                                    modifier = Modifier.testTag("btn_goto_map"),
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldSecondary.copy(0.3f)),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("🗺️ Carte", color = GoldLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                            }

                            IconButton(
                                onClick = onToggleRelicGallery,
                                modifier = Modifier.testTag("btn_relic_gallery")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = "Galerie Reliques",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = "${adventureState.unlockedRewards.size}",
                                        color = GoldLight,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Dynamic Book & Difficulty Selectors (Always visible on Steps list)
                    if (!adventureState.isPlayingStep) {
                        val availableBooks = adventureState.bookDataMap.values.map { it.livre }.distinct().ifEmpty { listOf("Genèse") }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Difficulties Selectors
                            listOf("facile", "intermediaire", "expert").forEach { diff ->
                                val isSelected = adventureState.selectedDifficulty.equals(diff, ignoreCase = true)
                                val label = when(diff) {
                                    "facile" -> "🟢 Facile"
                                    "intermediaire" -> "🟡 Intermédiaire"
                                    else -> "🔴 Expert"
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isSelected) GoldPrimary.copy(0.25f) else Color.Transparent,
                                            RoundedCornerShape(16.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (isSelected) GoldLight else GoldSecondary.copy(0.2f),
                                            RoundedCornerShape(16.dp)
                                        )
                                        .clickable { onSelectDifficulty(diff) }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) GoldLight else Color.Gray,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }

                            // Dynamic Books Selectors
                            availableBooks.forEach { bookGroup ->
                                val isSelected = adventureState.selectedBookGroup.equals(bookGroup, ignoreCase = true)
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isSelected) GoldSecondary.copy(0.3f) else Color.Transparent,
                                            RoundedCornerShape(16.dp)
                                        )
                                        .border(
                                            1.dp,
                                            if (isSelected) GoldPrimary else GoldSecondary.copy(0.3f),
                                            RoundedCornerShape(16.dp)
                                        )
                                        .clickable { onSelectBook(bookGroup) }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = bookGroup,
                                        color = if (isSelected) GoldLight else Color.Gray,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // MAIN CONTENT VIEW SWITCHER
            if (!adventureState.isPlayingStep) {
                // ==========================================
                // VIEW 1: STEPS SELECTION SCREEN (ÉCRAN DES ÉTAPES)
                // ==========================================
                val etapesList = book?.etapes ?: emptyList()
                val bookKey = "${adventureState.selectedBookGroup}_${adventureState.selectedDifficulty}"
                val maxUnlockedIndex = adventureState.unlockedEtapesMap[bookKey] ?: 0

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(etapesList) { index, etape ->
                        val isUnlocked = index <= maxUnlockedIndex

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("step_card_$index"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) DarkSurfaceElevated else Color(0xFF1B1B1E)
                            ),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(
                                    if (isUnlocked) GoldPrimary.copy(0.6f) else Color.DarkGray.copy(0.4f)
                                )
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Surface(
                                            color = if (isUnlocked) GoldPrimary else Color.DarkGray,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(
                                                text = "Étape ${etape.etape}",
                                                color = if (isUnlocked) Color.Black else Color.LightGray,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }

                                        Text(
                                            text = etape.titre,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (isUnlocked) GoldLight else Color.Gray,
                                                fontSize = 15.sp
                                            )
                                        )
                                    }

                                    Text(
                                        text = "📖 Chapitres : ${etape.chapitres}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = if (isUnlocked) TextGoldOnDark else Color.DarkGray,
                                            fontSize = 12.sp
                                        )
                                    )

                                    if (isUnlocked) {
                                        Text(
                                            text = "🏆 Récompense : ${etape.recompense?.nom ?: "Récompense spéciale"}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = GoldSecondary,
                                                fontSize = 11.sp
                                            )
                                        )
                                    } else {
                                        Text(
                                            text = "🔒 Terminez l'étape $index pour débloquer...",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Color.Gray,
                                                fontSize = 11.sp,
                                                fontStyle = FontStyle.Italic
                                            )
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(8.dp))

                                // Play or Locked Action Button
                                if (isUnlocked) {
                                    Button(
                                        onClick = { onStartStep(index) },
                                        modifier = Modifier.testTag("btn_play_step_$index"),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = GoldPrimary,
                                            contentColor = Color.Black
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Jouer",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Jouer", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                } else {
                                    Button(
                                        onClick = { },
                                        enabled = false,
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            disabledContainerColor = Color(0xFF2C2C2C),
                                            disabledContentColor = Color.Gray
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Verrouillé",
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Blocked", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // ==========================================
                // VIEW 2: STEP QUIZ PLAYING SCREEN (JOUER L'ÉTAPE)
                // ==========================================
                if (currentEtape != null && currentQ != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(GoldSecondary.copy(0.3f)))
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Étape ${currentEtape.etape}/${book?.totalEtapes ?: 13} : ${currentEtape.titre}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = GoldLight,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                )
                                Text(
                                    text = "Chap. ${currentEtape.chapitres}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = GoldSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }

                            val progress = (adventureState.currentQuestionIndex + 1).toFloat() / currentEtape.questions.size.coerceAtLeast(1)
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp),
                                color = GoldPrimary,
                                trackColor = Color.DarkGray
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Question ${adventureState.currentQuestionIndex + 1} / ${currentEtape.questions.size}",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                                if (currentEtape.recompense != null) {
                                    Text(
                                        text = "🏆 Récompense : ${currentEtape.recompense.nom}",
                                        color = GoldSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Question Card
                    RpgFrameCard(
                        title = if (currentEtape.isBossStep) "🔥 ÉTAPE 13 - COMBAT DE BOSS" else "Question Biblique",
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.35f),
                        testTag = "adventure_question_card"
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(0.3f), RoundedCornerShape(8.dp))
                                .border(0.5.dp, GoldSecondary.copy(0.3f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.TopStart
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = currentQ.question,
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                )

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Chrono",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Temps : ${if (currentQ.chrono) "${currentQ.timeLimit}s" else "Illimité"}",
                                        color = GoldLight,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Answers / Options Card
                    RpgFrameCard(
                        title = "VOS RÉPONSES (QCM)",
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(0.65f),
                        testTag = "adventure_answers_card"
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (currentQ.type == "clavier") {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "Saisissez votre réponse ci-dessous :",
                                        color = TextGoldOnDark,
                                        fontSize = 12.sp
                                    )

                                    OutlinedTextField(
                                        value = adventureState.keyboardInput,
                                        onValueChange = onUpdateKeyboardInput,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_keyboard_answer"),
                                        placeholder = { Text("Tapez la réponse ici...", color = Color.Gray) },
                                        singleLine = true,
                                        enabled = !adventureState.isAnswerChecked,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = GoldPrimary,
                                            unfocusedBorderColor = GoldSecondary,
                                            focusedTextColor = Color.White,
                                            unfocusedTextColor = Color.White
                                        )
                                    )

                                    if (!adventureState.isAnswerChecked) {
                                        Button(
                                            onClick = { onSubmitAnswer(adventureState.keyboardInput) },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("btn_submit_keyboard"),
                                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(imageVector = Icons.Default.Send, contentDescription = null, tint = Color.Black)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Valider la réponse", color = Color.Black, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            } else {
                                // Options List
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .verticalScroll(rememberScrollState()),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    currentQ.options.forEach { option ->
                                        val isSelected = adventureState.selectedOption == option
                                        val isChecked = adventureState.isAnswerChecked
                                        val isCorrectOption = option.trim().equals(currentQ.answer.trim(), ignoreCase = true)

                                        RpgActionButton(
                                            text = option,
                                            icon = when {
                                                isChecked && isCorrectOption -> Icons.Default.Check
                                                isChecked && isSelected && !adventureState.isCorrect -> Icons.Default.Close
                                                else -> Icons.Default.AutoAwesome
                                            },
                                            isPrimary = isSelected || (isChecked && isCorrectOption),
                                            onClick = {
                                                if (!isChecked) {
                                                    onSubmitAnswer(option)
                                                }
                                            },
                                            testTag = "choice_option_${option.hashCode()}"
                                        )
                                    }
                                }
                            }

                            // Feedback & Progress Controls
                            if (adventureState.isAnswerChecked) {
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 6.dp),
                                    color = if (adventureState.isCorrect) Color(0xFF1B5E20) else Color(0xFF8C1D1D),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(10.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = adventureState.feedbackMessage,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        )

                                        if (adventureState.isEtapeCompleted) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Button(
                                                    onClick = onReturnToStepsList,
                                                    colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                                                ) {
                                                    Text("📋 Liste des Étapes", color = Color.White, fontSize = 12.sp)
                                                }

                                                Button(
                                                    onClick = onNextEtape,
                                                    modifier = Modifier.testTag("btn_next_etape"),
                                                    colors = ButtonDefaults.buttonColors(containerColor = GoldLight)
                                                ) {
                                                    Text("Étape Suivante ➡️", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                        } else {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                if (!adventureState.isCorrect) {
                                                    Button(
                                                        onClick = onRestartEtape,
                                                        modifier = Modifier.testTag("btn_retry_etape"),
                                                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                                                    ) {
                                                        Text("Recommencer", color = Color.White, fontSize = 12.sp)
                                                    }
                                                } else {
                                                    Spacer(modifier = Modifier.width(1.dp))
                                                }

                                                Button(
                                                    onClick = onNextQuestion,
                                                    modifier = Modifier.testTag("btn_next_question"),
                                                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary)
                                                ) {
                                                    Text("Question Suivante ➡️", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Relic Gallery Dialog Overlay
        if (adventureState.showRelicGallery) {
            Dialog(onDismissRequest = onToggleRelicGallery) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth(0.95f)
                        .fillMaxHeight(0.8f),
                    color = DarkSurfaceElevated,
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = null, tint = GoldPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Galerie des Reliques",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = GoldLight,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            IconButton(
                                onClick = onToggleRelicGallery,
                                modifier = Modifier.testTag("btn_close_relic_gallery")
                            ) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val allRelics = book?.collection ?: emptyList()
                        if (allRelics.isEmpty()) {
                            Text(
                                text = "Aucune relique répertoriée.",
                                color = Color.Gray,
                                modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(allRelics) { relic ->
                                    val isUnlocked = adventureState.unlockedRewards.any { r -> r.id == relic.id }
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isUnlocked) Color(0xFF2A2318) else Color(0xFF1E1E1E)
                                        ),
                                        border = CardDefaults.outlinedCardBorder().copy(
                                            brush = androidx.compose.ui.graphics.SolidColor(
                                                if (isUnlocked) GoldPrimary else Color.DarkGray
                                            )
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = if (isUnlocked) "🏆 ${relic.nom}" else "🔒 ${relic.nom} (Verrouillé)",
                                                    color = if (isUnlocked) GoldLight else Color.Gray,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                                Text(
                                                    text = relic.rarite,
                                                    color = GoldSecondary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                            Text(
                                                text = relic.description,
                                                color = if (isUnlocked) TextGoldOnDark else Color.DarkGray,
                                                fontSize = 12.sp,
                                                fontStyle = FontStyle.Italic
                                            )
                                            if (isUnlocked && relic.verset.isNotEmpty()) {
                                                Text(
                                                    text = "📖 ${relic.verset}",
                                                    color = GoldPrimary,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
