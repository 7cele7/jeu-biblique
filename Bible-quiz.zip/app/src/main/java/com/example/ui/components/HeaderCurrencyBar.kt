package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PlayerStats
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.HealthGreen
import com.example.ui.theme.TextGoldOnDark
import kotlinx.coroutines.delay

@Composable
fun HeaderCurrencyBar(
    stats: PlayerStats,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(58.dp)
            .testTag("header_currency_bar"),
        color = DarkSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        shadowElevation = 4.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, GoldSecondary.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Level & XP
                AnimatedCurrencyBadge(
                    icon = { Icon(Icons.Default.Shield, contentDescription = "Niveau", tint = GoldPrimary, modifier = Modifier.size(18.dp)) },
                    targetValue = stats.level,
                    prefix = "Niv.",
                    testTag = "badge_level"
                )

                // Score
                AnimatedCurrencyBadge(
                    icon = { Icon(Icons.Default.Star, contentDescription = "Score", tint = Color(0xFFFFB300), modifier = Modifier.size(18.dp)) },
                    targetValue = stats.score,
                    testTag = "badge_score"
                )

                // Gold / Pièces
                AnimatedCurrencyBadge(
                    icon = { Icon(Icons.Default.MonetizationOn, contentDescription = "Pièces", tint = GoldPrimary, modifier = Modifier.size(18.dp)) },
                    targetValue = stats.gold,
                    testTag = "badge_gold"
                )

                // Gems / Gemmes de Foi
                AnimatedCurrencyBadge(
                    icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Gemmes", tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp)) },
                    targetValue = stats.gems,
                    testTag = "badge_gems"
                )
            }
        }
    }
}

@Composable
private fun AnimatedCurrencyBadge(
    icon: @Composable () -> Unit,
    targetValue: Int,
    prefix: String = "",
    testTag: String
) {
    val animatedValue by animateIntAsState(
        targetValue = targetValue,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "BadgeCounterAnimation"
    )

    var lastValue by remember { mutableStateOf(targetValue) }
    var isGrowing by remember { mutableStateOf(false) }

    LaunchedEffect(targetValue) {
        if (targetValue > lastValue) {
            isGrowing = true
            delay(1000)
            isGrowing = false
        }
        lastValue = targetValue
    }

    val badgeScale by animateFloatAsState(
        targetValue = if (isGrowing) 1.22f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "BadgeScale"
    )

    val borderColor = if (isGrowing) HealthGreen else GoldPrimary.copy(alpha = 0.3f)
    val bgColor = if (isGrowing) HealthGreen.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.35f)

    Row(
        modifier = Modifier
            .testTag(testTag)
            .scale(badgeScale)
            .background(bgColor, RoundedCornerShape(8.dp))
            .border(if (isGrowing) 1.5.dp else 0.5.dp, borderColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        icon()
        Text(
            text = "$prefix$animatedValue",
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = if (isGrowing) GoldLight else TextGoldOnDark
            )
        )
    }
}

