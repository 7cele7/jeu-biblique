package com.example.data

enum class Testament(val displayName: String) {
    ANCIEN_TESTAMENT("Ancien Testament"),
    NOUVEAU_TESTAMENT("Nouveau Testament")
}

data class BibleBookInfo(
    val order: Int,             // 1 to 66
    val name: String,           // e.g. "GENÈSE"
    val displayName: String,    // e.g. "Genèse"
    val testament: Testament,   // ANCIEN_TESTAMENT or NOUVEAU_TESTAMENT
    val category: String,       // e.g. "Pentateuque", "Historique", etc.
    val totalEtapes: Int = 13,
    val hasJsonData: Boolean = false,
    val description: String = ""
)

object BibleBooksCatalog {

    val ALL_66_BOOKS: List<BibleBookInfo> = listOf(
        // === ANCIEN TESTAMENT (39 Livres) ===
        // Pentateuque (1-5)
        BibleBookInfo(1, "GENÈSE", "Genèse", Testament.ANCIEN_TESTAMENT, "Pentateuque", 13, true, "Au commencement, la création, la chute, le déluge, Abraham, Isaac, Jacob et Joseph en Égypte."),
        BibleBookInfo(2, "EXODE", "Exode", Testament.ANCIEN_TESTAMENT, "Pentateuque", 13, true, "La sortie d'Égypte, les 10 plaies, la mer Rouge, le mont Sinaï, la Loi et le Tabernacle."),
        BibleBookInfo(3, "LÉVITIQUE", "Lévitique", Testament.ANCIEN_TESTAMENT, "Pentateuque", 13, true, "Les lois de la sainteté, les sacrifices, le sacerdoce et les fêtes de l'Éternel."),
        BibleBookInfo(4, "NOMBRES", "Nombres", Testament.ANCIEN_TESTAMENT, "Pentateuque", 13, false, "La marche au désert, le recensement du peuple et le voyage vers la Terre Promise."),
        BibleBookInfo(5, "DEUTÉRONOME", "Deutéronome", Testament.ANCIEN_TESTAMENT, "Pentateuque", 13, false, "Le second rappel de la Loi par Moïse avant la traversée du Jourdain."),

        // Livres Historiques (6-17)
        BibleBookInfo(6, "JOSUÉ", "Josué", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "La conquête de Canaan, la chute des murailles de Jéricho et le partage du pays."),
        BibleBookInfo(7, "JUGES", "Juges", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Période des héros et juges d'Israël : Gédéon, Samson, Débora, Jephthé."),
        BibleBookInfo(8, "RUTH", "Ruth", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "L'histoire de fidélité et d'amour de Ruth la Moabite et de Boaz."),
        BibleBookInfo(9, "1 SAMUEL", "1 Samuel", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Du prophète Samuel au premier roi Saül, et l'onction du jeune David."),
        BibleBookInfo(10, "2 SAMUEL", "2 Samuel", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Le règne du roi David, ses victoires, ses épreuves et l'alliance avec Dieu."),
        BibleBookInfo(11, "1 ROIS", "1 Rois", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Le roi Salomon, la construction du Temple, et la division du royaume d'Israël."),
        BibleBookInfo(12, "2 ROIS", "2 Rois", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Les prophètes Élie et Élisée, le déclin des royaumes et l'exil à Babylone."),
        BibleBookInfo(13, "1 CHRONIQUES", "1 Chroniques", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Généalogies saintes et détails du règne et culte instauré par David."),
        BibleBookInfo(14, "2 CHRONIQUES", "2 Chroniques", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Règne de Salomon, l'histoire des rois de Juda et le décret de Cyrus."),
        BibleBookInfo(15, "ESDRAS", "Esdras", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "Le retour de l'exil babylonien et la reconstruction du Second Temple."),
        BibleBookInfo(16, "NÉHÉMIE", "Néhémie", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "La reconstruction héroïque des murailles de Jérusalem sous la prière."),
        BibleBookInfo(17, "ESTHER", "Esther", Testament.ANCIEN_TESTAMENT, "Historique", 13, false, "La reine Esther et Mardochée sauvant le peuple juif du complot d'Haman."),

        // Poésie & Sagesse (18-22)
        BibleBookInfo(18, "JOB", "Job", Testament.ANCIEN_TESTAMENT, "Poétique", 13, false, "L'épreuve de la foi, la souffrance du juste et la révélation de la souveraineté divine."),
        BibleBookInfo(19, "PSAUMES", "Psaumes", Testament.ANCIEN_TESTAMENT, "Poétique", 13, false, "150 cantiques, louanges, prières, complaintes et prophéties messianiques."),
        BibleBookInfo(20, "PROVERBES", "Proverbes", Testament.ANCIEN_TESTAMENT, "Poétique", 13, false, "Maximes et conseils de sagesse pratique dictés par la crainte de Dieu."),
        BibleBookInfo(21, "ECCLÉSIASTE", "Ecclésiaste", Testament.ANCIEN_TESTAMENT, "Poétique", 13, false, "Méditation sur la vanité des choses terrestres et la crainte de Dieu."),
        BibleBookInfo(22, "CANTIQUE DES CANTIQUES", "Cantique des Cantiques", Testament.ANCIEN_TESTAMENT, "Poétique", 13, false, "Poème chantant l'amour pur entre l'époux et l'épouse, image de Dieu et son peuple."),

        // Grands Prophètes (23-27)
        BibleBookInfo(23, "ÉSAÏE", "Ésaïe", Testament.ANCIEN_TESTAMENT, "Grands Prophètes", 13, false, "Le prophète évangélique annonçant le Messie Souffrant et la Gloire future."),
        BibleBookInfo(24, "JÉRÉMIE", "Jérémie", Testament.ANCIEN_TESTAMENT, "Grands Prophètes", 13, false, "Le prophète pleurant la ruine de Jérusalem et annonçant la Nouvelle Alliance."),
        BibleBookInfo(25, "LAMENTATIONS", "Lamentations", Testament.ANCIEN_TESTAMENT, "Grands Prophètes", 13, false, "Chants de deuil profonds après la destruction du Temple de Jérusalem."),
        BibleBookInfo(26, "ÉZÉCHIEL", "Ézéchiel", Testament.ANCIEN_TESTAMENT, "Grands Prophètes", 13, false, "Visions célestes, la vallée des ossements desséchés et la restauration d'Israël."),
        BibleBookInfo(27, "DANIEL", "Daniel", Testament.ANCIEN_TESTAMENT, "Grands Prophètes", 13, false, "La fosse aux lions, la fournaise ardente et les prophéties des empires finaux."),

        // Petits Prophètes (28-39)
        BibleBookInfo(28, "OSÉE", "Osée", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "L'amour fidèle et inconditionnel de Dieu malgré l'infidélité du peuple."),
        BibleBookInfo(29, "JOËL", "Joël", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "L'annonce de l'effusion du Saint-Esprit sur toute chair et le Jour de l'Éternel."),
        BibleBookInfo(30, "AMOS", "Amos", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Appel vibrant à la justice sociale et au droit dans le culte véritable."),
        BibleBookInfo(31, "ABDIAS", "Abdias", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Prophétie contre l'orgueil d'Édom et la délivrance sur la montagne de Sion."),
        BibleBookInfo(32, "JONAS", "Jonas", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Le prophète englouti par le grand poisson et la repentance de Ninive."),
        BibleBookInfo(33, "MICHÉE", "Michée", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Annonce de la naissance du Messie à Bethléem et exigences de bonté."),
        BibleBookInfo(34, "NAHUM", "Nahum", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Annonce du jugement divin sur la fière cité guerrière de Ninive."),
        BibleBookInfo(35, "HABACUC", "Habacuc", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "« Le juste vivra par sa foi » : questionnement du prophète et hymne de confiance."),
        BibleBookInfo(36, "SOPHONIE", "Sophonie", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Le grand Jour du Seigneur et la promesse d'un reste humble purifié."),
        BibleBookInfo(37, "AGGÉE", "Aggée", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Encouragement urgent à rebâtir la Maison de l'Éternel à Jérusalem."),
        BibleBookInfo(38, "ZACHARIE", "Zacharie", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Visions nocturnes du Roi humble venant sur un ânon et le Rameau messianique."),
        BibleBookInfo(39, "MALACHIE", "Malachie", Testament.ANCIEN_TESTAMENT, "Petits Prophètes", 13, false, "Dernier message de l'Ancien Testament promettant la venue d'Élie avant le Seigneur."),

        // === NOUVEAU TESTAMENT (27 Livres) ===
        // Évangiles (40-43)
        BibleBookInfo(40, "MATTHIEU", "Matthieu", Testament.NOUVEAU_TESTAMENT, "Évangile", 13, false, "Jésus, le Roi promis, accomplissement des prophéties de l'Ancien Testament."),
        BibleBookInfo(41, "MARC", "Marc", Testament.NOUVEAU_TESTAMENT, "Évangile", 13, false, "Jésus, le Serviteur obéissant, agissant avec puissance et compassion."),
        BibleBookInfo(42, "LUC", "Luc", Testament.NOUVEAU_TESTAMENT, "Évangile", 13, false, "Jésus, le Fils de l'Homme venu chercher et sauver ce qui était perdu."),
        BibleBookInfo(43, "JEAN", "Jean", Testament.NOUVEAU_TESTAMENT, "Évangile", 13, false, "Jésus, le Verbe fait chair, la Lumière et la Vie Éternelle."),

        // Histoire (44)
        BibleBookInfo(44, "ACTES", "Actes des Apôtres", Testament.NOUVEAU_TESTAMENT, "Histoire", 13, false, "La descente du Saint-Esprit à la Pentecôte et l'expansion héroïque de l'Église."),

        // Épîtres de Paul (45-57)
        BibleBookInfo(45, "ROMAINS", "Romains", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "La justification par la foi, la grâce surabondante et la vie par l'Esprit."),
        BibleBookInfo(46, "1 CORINTHIENS", "1 Corinthiens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "L'unité de l'Église, la Sainte Cène, le cantique de l'amour et la résurrection."),
        BibleBookInfo(47, "2 CORINTHIENS", "2 Corinthiens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "La consolation dans les épreuves et le ministère de la réconciliation."),
        BibleBookInfo(48, "GALATES", "Galates", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "La liberté chrétienne en Christ opposée au joug de la loi."),
        BibleBookInfo(49, "ÉPHÉSIENS", "Éphésiens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "Les richesses de la grâce, l'unité du corps du Christ et l'armure de Dieu."),
        BibleBookInfo(50, "PHILIPPIENS", "Philippiens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "L'épître de la joie céleste, de l'humilité et de la paix en Christ."),
        BibleBookInfo(51, "COLOSSIENS", "Colossiens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "La suprématie absolue du Christ, image du Dieu invisible."),
        BibleBookInfo(52, "1 THESSALONICIENS", "1 Thessaloniciens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "L'espérance radieuse du retour glorieux du Seigneur Jésus."),
        BibleBookInfo(53, "2 THESSALONICIENS", "2 Thessaloniciens", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "Patience et persévérance face à l'adversité dans l'attente du Jour."),
        BibleBookInfo(54, "1 TIMOTHÉE", "1 Timothée", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "Conseils pastoraux pour le bon gouvernement et la piété dans l'Église."),
        BibleBookInfo(55, "2 TIMOTHÉE", "2 Timothée", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "Le testament de Paul : « J'ai combattu le bon combat, j'ai achevé la course »."),
        BibleBookInfo(56, "TITE", "Tite", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "Organisation des assemblées en Crète et enseignement de la saine doctrine."),
        BibleBookInfo(57, "PHILÉMON", "Philémon", Testament.NOUVEAU_TESTAMENT, "Épîtres de Paul", 13, false, "Appel touchant au pardon et à l'accueil du serviteur Onésime comme un frère."),

        // Épîtres Générales (58-65)
        BibleBookInfo(58, "HÉBREUX", "Hébreux", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "Jésus, le Grand Prêtre supérieur, médiateur d'une Nouvelle Alliance éternelle."),
        BibleBookInfo(59, "JACQUES", "Jacques", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "La foi vivante démontrée par les œuvres et la maîtrise de la langue."),
        BibleBookInfo(60, "1 PIERRE", "1 Pierre", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "Encouragement aux chrétiens persécutés : espérance vivante et pureté."),
        BibleBookInfo(61, "2 PIERRE", "2 Pierre", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "Mise en garde contre les faux docteurs et certitude des promesses de Dieu."),
        BibleBookInfo(62, "1 JEAN", "1 Jean", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "« Dieu est lumière » et « Dieu est amour » : la certitude du salut."),
        BibleBookInfo(63, "2 JEAN", "2 Jean", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "Marcher dans la vérité et l'amour en se gardant des séducteurs."),
        BibleBookInfo(64, "3 JEAN", "3 Jean", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "Éloge de l'hospitalité de Gaïus envers les ouvriers de l'Évangile."),
        BibleBookInfo(65, "JUDE", "Jude", Testament.NOUVEAU_TESTAMENT, "Épîtres Générales", 13, false, "Combattre pour la foi transmise aux saints une fois pour toutes."),

        // Prophétie (66)
        BibleBookInfo(66, "APOCALYPSE", "Apocalypse", Testament.NOUVEAU_TESTAMENT, "Prophétie", 13, false, "La révélation de Jésus-Christ, la victoire finale sur le mal et la Nouvelle Jérusalem.")
    )

    fun getBookByName(name: String): BibleBookInfo? {
        return ALL_66_BOOKS.find {
            it.name.equals(name, ignoreCase = true) || it.displayName.equals(name, ignoreCase = true)
        }
    }
}
