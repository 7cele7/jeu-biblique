package com.example.data

import android.content.Context
import com.example.model.AdventureBookData
import com.example.model.AdventureEtape
import com.example.model.AdventureQuestion
import com.example.model.AdventureReward
import org.json.JSONObject

object AdventureRepository {

    fun loadAdventureBooksFromAssets(context: Context): Map<String, AdventureBookData> {
        val bookMap = mutableMapOf<String, AdventureBookData>()
        val jsonStrings = mutableListOf<String>()

        // 1. Load from res/raw resources
        try {
            val rawFields = com.example.R.raw::class.java.fields.filter { it.name.startsWith("adventure_") }
            for (field in rawFields) {
                try {
                    val resId = field.getInt(null)
                    val jsonString = context.resources.openRawResource(resId).bufferedReader().use { it.readText() }
                    jsonStrings.add(jsonString)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Load from assets folder if present
        try {
            val assetFiles = context.assets.list("")?.filter { it.startsWith("adventure_") && it.endsWith(".json") } ?: emptyList()
            for (fileName in assetFiles) {
                try {
                    val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }
                    jsonStrings.add(jsonString)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        for (jsonString in jsonStrings) {
            try {
                val root = JSONObject(jsonString)

                val livre = root.optString("livre", "Genèse")
                val ordre = root.optInt("ordre", 1)
                val totalEtapes = root.optInt("total_etapes", 13)
                val niveau = root.optString("niveau", "facile")

                val key = "${livre}_${niveau}"

                    // Collection parse
                    val collectionArray = root.optJSONArray("collection")
                    val collectionList = mutableListOf<AdventureReward>()
                    if (collectionArray != null) {
                        for (i in 0 until collectionArray.length()) {
                            val cObj = collectionArray.getJSONObject(i)
                            collectionList.add(
                                AdventureReward(
                                    id = cObj.optString("id", "rel_$i"),
                                    nom = cObj.optString("nom", "Relique"),
                                    type = cObj.optString("type", "Objet"),
                                    rarite = cObj.optString("rarite", "Commun"),
                                    categorie = cObj.optString("categorie", "Inconnu"),
                                    description = cObj.optString("description", ""),
                                    verset = cObj.optString("verset", ""),
                                    image = cObj.optString("image", "")
                                )
                            )
                        }
                    }

                    // Etapes parse
                    val etapesArray = root.optJSONArray("etapes")
                    val etapesList = mutableListOf<AdventureEtape>()
                    if (etapesArray != null) {
                        for (i in 0 until etapesArray.length()) {
                            val eObj = etapesArray.getJSONObject(i)
                            val etapeNum = eObj.optInt("etape", i + 1)
                            val titre = eObj.optString("titre", "Étape $etapeNum")
                            val chapitres = eObj.optString("chapitres", "")
                            val etapeNiveau = eObj.optString("niveau", niveau)
                            val isBoss = eObj.optString("type", "") == "BOSS"

                            var recompense: AdventureReward? = null
                            if (eObj.has("recompense") && !eObj.isNull("recompense")) {
                                val rObj = eObj.getJSONObject("recompense")
                                recompense = AdventureReward(
                                    id = rObj.optString("id", "rec_$etapeNum"),
                                    nom = rObj.optString("nom", "Récompense"),
                                    type = rObj.optString("type", "Objet"),
                                    rarite = rObj.optString("rarite", "Commun"),
                                    categorie = rObj.optString("categorie", "Inconnu"),
                                    description = rObj.optString("description", ""),
                                    verset = rObj.optString("verset", ""),
                                    image = rObj.optString("image", "")
                                )
                            }

                            val questionsArray = eObj.optJSONArray("questions")
                            val questionsList = mutableListOf<AdventureQuestion>()
                            if (questionsArray != null) {
                                for (j in 0 until questionsArray.length()) {
                                    val qObj = questionsArray.getJSONObject(j)
                                    val qId = qObj.optString("id", "q_${i}_$j")
                                    val qType = qObj.optString("type", "choix_multiple")
                                    val chrono = qObj.optBoolean("chrono", false)
                                    val timeLimit = qObj.optInt("time_limit", 15)
                                    val questionText = qObj.optString("question", "")
                                    val answerText = qObj.optString("answer", "")
                                    val referenceText = qObj.optString("reference", "")

                                    val optsArray = qObj.optJSONArray("options")
                                    val optionsList = mutableListOf<String>()
                                    if (optsArray != null) {
                                        for (k in 0 until optsArray.length()) {
                                            optionsList.add(optsArray.getString(k))
                                        }
                                    }
                                    val shuffledOptions = if (optionsList.size > 1) optionsList.shuffled() else optionsList

                                    val aliasesArray = qObj.optJSONArray("aliases")
                                    val aliasesList = mutableListOf<String>()
                                    if (aliasesArray != null) {
                                        for (k in 0 until aliasesArray.length()) {
                                            aliasesList.add(aliasesArray.getString(k))
                                        }
                                    }

                                    questionsList.add(
                                        AdventureQuestion(
                                            id = qId,
                                            type = qType,
                                            chrono = chrono,
                                            timeLimit = timeLimit,
                                            question = questionText,
                                            options = shuffledOptions,
                                            answer = answerText,
                                            aliases = aliasesList,
                                            reference = referenceText
                                        )
                                    )
                                }
                            }

                            var bossNom: String? = null
                            var bossDesc: String? = null
                            if (eObj.has("boss") && !eObj.isNull("boss")) {
                                val bObj = eObj.getJSONObject("boss")
                                bossNom = bObj.optString("nom", "Boss Final")
                                bossDesc = bObj.optString("description", "")
                            }

                            etapesList.add(
                                AdventureEtape(
                                    etape = etapeNum,
                                    titre = titre,
                                    chapitres = chapitres,
                                    niveau = etapeNiveau,
                                    recompense = recompense,
                                    questions = questionsList,
                                    isBossStep = isBoss,
                                    bossNom = bossNom,
                                    bossDescription = bossDesc
                                )
                            )
                        }
                    }

                    bookMap[key] = AdventureBookData(
                        livre = livre,
                        ordre = ordre,
                        totalEtapes = totalEtapes,
                        niveau = niveau,
                        collection = collectionList,
                        etapes = etapesList
                    )

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        return bookMap
    }
}
