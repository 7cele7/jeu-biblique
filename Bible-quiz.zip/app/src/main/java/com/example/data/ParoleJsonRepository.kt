package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.ParoleLevelData
import com.example.model.ParoleQuestion
import com.example.model.ParoleQuestionType
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object ParoleJsonRepository {

    private const val TAG = "ParoleJsonRepo"
    private const val PAROLE_FOLDER = "parole"

    /**
     * Scanne les assets pour découvrir les niveaux disponibles par difficulté :
     * parole/facile/niveau_01.json, etc.
     * Retourne une map : "facile" -> [1, 2, ...], "intermediaire" -> [1, ...], "expert" -> [...]
     */
    fun scanAvailableLevels(context: Context): Map<String, List<Int>> {
        val resultMap = mutableMapOf<String, MutableList<Int>>()
        val difficulties = listOf("facile", "intermediaire", "expert")

        difficulties.forEach { diff ->
            resultMap[diff] = mutableListOf()
            try {
                val files = context.assets.list("$PAROLE_FOLDER/$diff") ?: emptyArray()
                for (file in files) {
                    if (file.endsWith(".json", ignoreCase = true)) {
                        // Extrait le numéro (ex: niveau_01.json -> 1, niveau_12.json -> 12)
                        val levelNumber = extractLevelNumber(file)
                        if (levelNumber != null) {
                            resultMap[diff]?.add(levelNumber)
                        }
                    }
                }
                resultMap[diff]?.sort()
            } catch (e: Exception) {
                Log.w(TAG, "Dossier $PAROLE_FOLDER/$diff non trouvé ou vide: ${e.message}")
            }
        }

        return resultMap
    }

    /**
     * Charge un niveau spécifique : parole/[difficulte]/niveau_[xx].json
     */
    fun loadLevel(context: Context, difficulte: String, niveau: Int): ParoleLevelData? {
        val formattedNumber = String.format("%02d", niveau)
        val candidatePaths = listOf(
            "$PAROLE_FOLDER/$difficulte/niveau_$formattedNumber.json",
            "$PAROLE_FOLDER/$difficulte/niveau_$niveau.json",
            "$PAROLE_FOLDER/$difficulte/level_$formattedNumber.json",
            "$PAROLE_FOLDER/$difficulte/level_$niveau.json"
        )

        for (path in candidatePaths) {
            try {
                val jsonString = context.assets.open(path).use { stream ->
                    BufferedReader(InputStreamReader(stream)).use { reader ->
                        reader.readText()
                    }
                }
                val parsed = parseLevelJson(jsonString, difficulte, niveau)
                if (parsed != null && parsed.questions.isNotEmpty()) {
                    return parsed
                }
            } catch (_: Exception) {
                // Essayer le chemin suivant
            }
        }

        Log.e(TAG, "Impossible de charger le niveau $niveau pour la difficulté $difficulte")
        return null
    }

    /**
     * Parse le contenu JSON d'un niveau (12 questions)
     */
    fun parseLevelJson(jsonString: String, defaultDifficulty: String, defaultLevel: Int): ParoleLevelData? {
        return try {
            val root = JSONObject(jsonString)
            val diff = root.optString("difficulte", root.optString("difficulty", defaultDifficulty))
            val levelNum = root.optInt("niveau", root.optInt("level", defaultLevel))

            val questionsArray = root.optJSONArray("questions") ?: return null
            val questionList = mutableListOf<ParoleQuestion>()

            for (i in 0 until questionsArray.length()) {
                val qObj = questionsArray.getJSONObject(i)
                val id = qObj.optString("id", "PAR_${diff.take(3).uppercase()}_N${levelNum}_Q${String.format("%03d", i + 1)}")
                val rawType = qObj.optString("type", "verset_reference")
                val type = ParoleQuestionType.fromString(rawType)

                val reference = qObj.optString("reference", "")
                val verset = when {
                    qObj.has("verset") -> qObj.optString("verset")
                    qObj.has("verset_a_completer") -> qObj.optString("verset_a_completer")
                    qObj.has("texte") -> qObj.optString("texte")
                    else -> null
                }

                // 4 options du JSON
                val rawOptionsArray = qObj.optJSONArray("options") ?: qObj.optJSONArray("propositions")
                val originalOptions = mutableListOf<String>()
                if (rawOptionsArray != null) {
                    for (j in 0 until rawOptionsArray.length()) {
                        originalOptions.add(rawOptionsArray.getString(j))
                    }
                }

                // Détermination de la bonne réponse
                // Selon la spécification : la bonne réponse est à l'index 0 (ou spécifiée via bonne_reponse / answer)
                val bonneReponse = when {
                    qObj.has("bonne_reponse") -> {
                        val br = qObj.get("bonne_reponse")
                        if (br is Int && br in originalOptions.indices) {
                            originalOptions[br]
                        } else {
                            br.toString()
                        }
                    }
                    qObj.has("answer") -> {
                        val ans = qObj.get("answer")
                        if (ans is Int && ans in originalOptions.indices) {
                            originalOptions[ans]
                        } else {
                            ans.toString()
                        }
                    }
                    originalOptions.isNotEmpty() -> originalOptions[0]
                    else -> ""
                }

                // Mélange dynamique des options pour que la bonne réponse ne soit pas prévisible à l'écran
                val shuffledOptions = if (originalOptions.size > 1) {
                    originalOptions.shuffled()
                } else {
                    originalOptions
                }

                questionList.add(
                    ParoleQuestion(
                        id = id,
                        type = type,
                        reference = reference,
                        verset = verset,
                        options = shuffledOptions,
                        bonneReponse = bonneReponse
                    )
                )
            }

            ParoleLevelData(
                difficulte = diff,
                niveau = levelNum,
                questions = questionList
            )
        } catch (e: Exception) {
            Log.e(TAG, "Erreur de parsing JSON niveau: ${e.message}", e)
            null
        }
    }

    private fun extractLevelNumber(fileName: String): Int? {
        val cleanName = fileName.substringBeforeLast(".")
        val digits = cleanName.filter { it.isDigit() }
        return digits.toIntOrNull()
    }
}
