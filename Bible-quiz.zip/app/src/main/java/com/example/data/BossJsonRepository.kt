package com.example.data

import android.content.Context
import com.example.model.BossData
import com.example.model.BossInfo
import com.example.model.BossQuestion
import org.json.JSONObject

object BossJsonRepository {

    fun loadBossesFromAssets(context: Context): Map<String, BossData> {
        val bossMap = mutableMapOf<String, BossData>()
        try {
            val assetFiles = context.assets.list("")?.filter { it.startsWith("boss_") && it.endsWith(".json") }
                ?: listOf(
                    "boss_genese.json",
                    "boss_exode.json",
                    "boss_levitique.json",
                    "boss_nombres.json",
                    "boss_deuteronome.json",
                    "boss_josue.json",
                    "boss_juges.json",
                    "boss_1samuel.json",
                    "boss_2samuel.json",
                    "boss_1rois.json",
                    "boss_2rois.json",
                    "boss_1chroniques.json",
                    "boss_2chroniques.json",
                    "boss_esdras_nehemie.json",
                    "boss_esther.json",
                    "boss_job.json"
                )

            for (fileName in assetFiles) {
                try {
                    val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }
                    val root = JSONObject(jsonString)

                    val keys = root.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        val obj = root.getJSONObject(key)

                        if (obj.has("boss")) {
                            // Flat format (e.g. "boss_genese_facile": { id: ..., boss: {...}, questions: [...] })
                            val bossData = parseSingleBossJson(obj, key)
                            val mapKey = if (bossData.id.isNotEmpty()) bossData.id else key
                            bossMap[mapKey] = bossData
                        } else {
                            // Nested format (e.g. "boss_jezabel": { "facile": { id: ..., boss: {...} }, ... })
                            val diffKeys = obj.keys()
                            while (diffKeys.hasNext()) {
                                val diffKey = diffKeys.next()
                                val diffObj = obj.optJSONObject(diffKey)
                                if (diffObj != null && diffObj.has("boss")) {
                                    val bossData = parseSingleBossJson(diffObj, "${key}_${diffKey}")
                                    val mapKey = if (bossData.id.isNotEmpty()) bossData.id else "${key}_${diffKey}"
                                    bossMap[mapKey] = bossData
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bossMap
    }

    private fun parseSingleBossJson(obj: JSONObject, defaultKey: String): BossData {
        val id = obj.optString("id", defaultKey)
        val livre = obj.optString("livre", "Genèse")
        val ordre = obj.optInt("ordre", 1)
        val niveau = obj.optString("niveau", "facile")
        val vies = obj.optInt("vies", 3)
        val chronoGlobal = obj.optInt("chrono_global", 60)
        val chronoQuestion = obj.optInt("chrono_question", 15)

        val bossObj = obj.optJSONObject("boss")
        val bossInfo = BossInfo(
            nom = bossObj?.optString("nom", "Boss") ?: "Boss",
            titre = bossObj?.optString("titre", "") ?: "",
            emoji = bossObj?.optString("emoji", "🐍") ?: "🐍",
            description = bossObj?.optString("description", "") ?: "",
            verset = bossObj?.optString("verset", "") ?: "",
            image = bossObj?.optString("image", "") ?: "",
            type = bossObj?.optString("type", "") ?: "",
            mecanique = bossObj?.optString("mecanique", "") ?: ""
        )

        val questionsArray = obj.optJSONArray("questions")
        val questionsList = mutableListOf<BossQuestion>()
        if (questionsArray != null) {
            for (i in 0 until questionsArray.length()) {
                val qObj = questionsArray.getJSONObject(i)
                val qId = qObj.optString("id", "")
                val phase = qObj.optString("phase", "")
                val questionText = qObj.optString("question", "")
                val answer = qObj.optString("answer", "")
                val reference = qObj.optString("reference", "")

                val optsArray = qObj.optJSONArray("options")
                val optionsList = mutableListOf<String>()
                if (optsArray != null) {
                    for (j in 0 until optsArray.length()) {
                        optionsList.add(optsArray.getString(j))
                    }
                }
                val shuffledOptions = if (optionsList.size > 1) optionsList.shuffled() else optionsList

                questionsList.add(
                    BossQuestion(
                        id = qId,
                        phase = phase,
                        question = questionText,
                        options = shuffledOptions,
                        answer = answer,
                        reference = reference
                    )
                )
            }
        }

        return BossData(
            id = id,
            livre = livre,
            ordre = ordre,
            bossInfo = bossInfo,
            niveau = niveau,
            vies = vies,
            chronoGlobal = chronoGlobal,
            chronoQuestion = chronoQuestion,
            questions = questionsList
        )
    }
}

