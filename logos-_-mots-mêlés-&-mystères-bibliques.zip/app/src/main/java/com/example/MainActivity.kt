package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.ActiveScreen
import com.example.ui.modals.GameModalsHost
import com.example.ui.screens.GameScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LevelSelectScreen
import com.example.ui.theme.BlackCanvas
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BlackCanvas
                ) {
                    LogosApp()
                }
            }
        }
    }
}

@Composable
fun LogosApp(
    viewModel: GameViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BlackCanvas)
    ) {
        when (uiState.activeScreen) {
            ActiveScreen.HOME -> {
                HomeScreen(uiState = uiState, viewModel = viewModel)
            }
            ActiveScreen.LEVEL_SELECT -> {
                LevelSelectScreen(uiState = uiState, viewModel = viewModel)
            }
            ActiveScreen.GAME -> {
                GameScreen(uiState = uiState, viewModel = viewModel)
            }
        }

        // Host for all rich modals (Profile, Shop, Stats, Trophies, Settings, Rewarded Video Ad, Mystery Reveal)
        GameModalsHost(uiState = uiState, viewModel = viewModel)
    }
}
