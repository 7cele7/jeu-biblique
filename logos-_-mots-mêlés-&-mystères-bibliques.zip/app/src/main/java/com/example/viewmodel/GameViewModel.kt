package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BiblePuzzlesRepository
import com.example.data.LevelRepository
import com.example.model.ActiveModal
import com.example.model.ActiveScreen
import com.example.model.BibleWordSearchPuzzle
import com.example.model.CellCoordinate
import com.example.model.DifficultyLevel
import com.example.model.JokerType
import com.example.model.PlayerProfile
import com.example.model.Trophy
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max

data class GameUiState(
    val activeScreen: ActiveScreen = ActiveScreen.HOME,
    val activeModal: ActiveModal = ActiveModal.NONE,
    val selectedDifficulty: DifficultyLevel = DifficultyLevel.FACILE,
    val availableLevels: List<BibleWordSearchPuzzle> = emptyList(),
    val completedLevelIds: Set<String> = setOf("puzzle_facile_1"),
    val unlockedLevelIds: Set<String> = setOf("puzzle_facile_1", "puzzle_intermediaire_1", "puzzle_expert_1"),
    val pendingUnlockPuzzle: BibleWordSearchPuzzle? = null,
    val profile: PlayerProfile = PlayerProfile(),
    val currentPuzzle: BibleWordSearchPuzzle = BiblePuzzlesRepository.samplePuzzles.first(),
    val foundWordIds: Set<String> = emptySet(),
    val currentSelection: List<CellCoordinate> = emptyList(),
    val highlightedHintCells: Set<CellCoordinate> = emptySet(),
    val eliminatedDistractorCells: Set<CellCoordinate> = emptySet(),
    val mysteryPhaseUnlocked: Boolean = false,
    val mysterySelectedBankIndices: List<Int> = emptyList(),
    val mysteryGuessedLetters: String = "",
    val mysterySolved: Boolean = false,
    val isGraceWordRevealed: Boolean = false,
    val dailyVerseIndex: Int = 0,
    val trophies: List<Trophy> = BiblePuzzlesRepository.defaultTrophies,
    val rewardedVideoSecondsLeft: Int = 5,
    val isRewardedVideoPlaying: Boolean = false,
    val pendingRewardType: JokerType? = null,
    val toastMessage: String? = null,
    val elapsedSeconds: Int = 0
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    val levelRepository = LevelRepository(application.applicationContext)

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var dragStartCell: CellCoordinate? = null
    private var timerJob: kotlinx.coroutines.Job? = null

    init {
        // Load initial state with dynamic levels from assets
        val initialLevels = levelRepository.loadLevelsForDifficulty(DifficultyLevel.FACILE)
        val initialPuzzle = initialLevels.firstOrNull() ?: BiblePuzzlesRepository.samplePuzzles.first()
        _uiState.update {
            it.copy(
                currentPuzzle = initialPuzzle,
                availableLevels = initialLevels,
                selectedDifficulty = DifficultyLevel.FACILE
            )
        }
        startTimer()
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_uiState.value.activeScreen == ActiveScreen.GAME && !_uiState.value.mysterySolved) {
                    _uiState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
                }
            }
        }
    }

    fun openScreen(screen: ActiveScreen) {
        _uiState.update { it.copy(activeScreen = screen) }
    }

    fun openModal(modal: ActiveModal) {
        _uiState.update { it.copy(activeModal = modal) }
    }

    fun closeModal() {
        _uiState.update { it.copy(activeModal = ActiveModal.NONE) }
    }

    fun selectDifficulty(difficulty: DifficultyLevel) {
        val levels = levelRepository.loadLevelsForDifficulty(difficulty)
        _uiState.update {
            it.copy(
                activeScreen = ActiveScreen.LEVEL_SELECT,
                selectedDifficulty = difficulty,
                availableLevels = levels
            )
        }
    }

    fun selectLevel(puzzle: BibleWordSearchPuzzle) {
        startPuzzle(puzzle)
    }

    fun resumeLastGame() {
        _uiState.update { it.copy(activeScreen = ActiveScreen.GAME) }
    }

    fun startPuzzle(puzzle: BibleWordSearchPuzzle) {
        _uiState.update {
            it.copy(
                activeScreen = ActiveScreen.GAME,
                currentPuzzle = puzzle,
                foundWordIds = emptySet(),
                currentSelection = emptyList(),
                highlightedHintCells = emptySet(),
                eliminatedDistractorCells = emptySet(),
                mysteryPhaseUnlocked = false,
                mysterySelectedBankIndices = emptyList(),
                mysteryGuessedLetters = "",
                mysterySolved = false,
                isGraceWordRevealed = false
            )
        }
    }

    fun nextDailyVerse() {
        _uiState.update {
            val next = (it.dailyVerseIndex + 1) % BiblePuzzlesRepository.dailyVerses.size
            it.copy(dailyVerseIndex = next)
        }
    }

    // Grid Drag & Word Discovery Engine
    fun onCellDragStart(row: Int, col: Int) {
        val puzzle = _uiState.value.currentPuzzle
        if (row in 0 until puzzle.gridSize && col in 0 until puzzle.gridSize) {
            dragStartCell = CellCoordinate(row, col)
            _uiState.update { it.copy(currentSelection = listOf(CellCoordinate(row, col))) }
        }
    }

    fun onCellDragMove(row: Int, col: Int) {
        val start = dragStartCell ?: return
        val puzzle = _uiState.value.currentPuzzle
        if (row !in 0 until puzzle.gridSize || col !in 0 until puzzle.gridSize) return

        val cells = computeStraightLine(start.row, start.col, row, col)
        if (cells.isNotEmpty()) {
            _uiState.update { it.copy(currentSelection = cells) }
        }
    }

    fun onCellDragEnd() {
        val selection = _uiState.value.currentSelection
        val puzzle = _uiState.value.currentPuzzle
        dragStartCell = null

        if (selection.size < 2) {
            _uiState.update { it.copy(currentSelection = emptyList()) }
            return
        }

        // Form string from coordinates
        val selectedStringForward = selection.map { puzzle.grid[it.row][it.col] }.joinToString("")
        val selectedStringBackward = selectedStringForward.reversed()

        // Check if matches any unfound word
        val matchedWord = puzzle.words.find { wordPlacement ->
            !_uiState.value.foundWordIds.contains(wordPlacement.id) &&
                (wordPlacement.word.equals(selectedStringForward, ignoreCase = true) ||
                 wordPlacement.word.equals(selectedStringBackward, ignoreCase = true))
        }

        if (matchedWord != null) {
            // Word Found!
            val updatedFound = _uiState.value.foundWordIds + matchedWord.id
            val allWordsFound = updatedFound.size >= puzzle.words.size

            _uiState.update { current ->
                val newProfile = current.profile.copy(
                    xp = current.profile.xp + 30,
                    coins = current.profile.coins + 10,
                    wordsFound = current.profile.wordsFound + 1
                )
                current.copy(
                    foundWordIds = updatedFound,
                    currentSelection = emptyList(),
                    profile = newProfile,
                    mysteryPhaseUnlocked = allWordsFound,
                    toastMessage = "Trouvé : ${matchedWord.displayWord} !"
                )
            }

            if (allWordsFound) {
                // Trigger Mystery Decryption Modal
                _uiState.update { it.copy(activeModal = ActiveModal.MYSTERY_REVEAL) }
            }
        } else {
            _uiState.update { it.copy(currentSelection = emptyList()) }
        }
    }

    private fun computeStraightLine(r1: Int, c1: Int, r2: Int, c2: Int): List<CellCoordinate> {
        val dr = r2 - r1
        val dc = c2 - c1
        val stepR = if (dr == 0) 0 else dr / abs(dr)
        val stepC = if (dc == 0) 0 else dc / abs(dc)

        // Strict Horizontal, Vertical or Diagonal (45 degrees) check
        val isHorizontal = dr == 0 && dc != 0
        val isVertical = dc == 0 && dr != 0
        val isDiagonal = abs(dr) == abs(dc) && dr != 0

        if (!isHorizontal && !isVertical && !isDiagonal) {
            return listOf(CellCoordinate(r1, c1))
        }

        val count = max(abs(dr), abs(dc))
        val result = mutableListOf<CellCoordinate>()
        for (i in 0..count) {
            result.add(CellCoordinate(r1 + i * stepR, c1 + i * stepC))
        }
        return result
    }

    // Jokers Implementation
    fun useJokerRevealFirstLetter() {
        val difficulty = _uiState.value.currentPuzzle.difficulty
        when (difficulty) {
            DifficultyLevel.FACILE -> {
                useFreeHint()
            }
            DifficultyLevel.INTERMEDIAIRE -> {
                useJokerFirstLetter()
            }
            DifficultyLevel.EXPERT -> {
                requestExpertJoker(JokerType.FIRST_LETTER)
            }
        }
    }

    fun useJokerEliminateFalseLetters() {
        val difficulty = _uiState.value.currentPuzzle.difficulty
        val puzzle = _uiState.value.currentPuzzle

        // Compute cells that belong to unfound words
        val activeWordCells = mutableSetOf<CellCoordinate>()
        puzzle.words.filter { !_uiState.value.foundWordIds.contains(it.id) }.forEach { wordPlacement ->
            val line = computeStraightLine(
                wordPlacement.startRow, wordPlacement.startCol,
                wordPlacement.endRow, wordPlacement.endCol
            )
            activeWordCells.addAll(line)
        }

        // Identify distractor cells (cells not belonging to any remaining word)
        val allDistractors = mutableListOf<CellCoordinate>()
        for (r in 0 until puzzle.gridSize) {
            for (c in 0 until puzzle.gridSize) {
                val coord = CellCoordinate(r, c)
                if (!activeWordCells.contains(coord) && !_uiState.value.eliminatedDistractorCells.contains(coord)) {
                    allDistractors.add(coord)
                }
            }
        }

        val distractorsToRemove = allDistractors.shuffled().take(6).toSet()

        when (difficulty) {
            DifficultyLevel.FACILE -> {
                _uiState.update {
                    it.copy(
                        eliminatedDistractorCells = it.eliminatedDistractorCells + distractorsToRemove,
                        toastMessage = "Lettres parasites éliminées (Indice Gratuit) !"
                    )
                }
            }
            DifficultyLevel.INTERMEDIAIRE -> {
                val cost = 25
                if (_uiState.value.profile.coins < cost) {
                    _uiState.update {
                        it.copy(
                            toastMessage = "Pièces insuffisantes ($cost requises). Regardez une vidéo !",
                            activeModal = ActiveModal.REWARDED_VIDEO,
                            pendingRewardType = JokerType.FIFTY_FIFTY
                        )
                    }
                    return
                }
                _uiState.update {
                    it.copy(
                        profile = it.profile.copy(
                            coins = it.profile.coins - cost,
                            jokersUsed = it.profile.jokersUsed + 1
                        ),
                        eliminatedDistractorCells = it.eliminatedDistractorCells + distractorsToRemove,
                        toastMessage = "Joker -25 $ : 6 fausses lettres éliminées !"
                    )
                }
            }
            DifficultyLevel.EXPERT -> {
                val cost = 50
                if (_uiState.value.profile.coins >= cost) {
                    _uiState.update {
                        it.copy(
                            profile = it.profile.copy(
                                coins = it.profile.coins - cost,
                                jokersUsed = it.profile.jokersUsed + 1
                            ),
                            eliminatedDistractorCells = it.eliminatedDistractorCells + distractorsToRemove,
                            toastMessage = "Joker Expert appliqué : Fausses lettres éliminées !"
                        )
                    }
                } else {
                    startRewardedVideo(JokerType.FIFTY_FIFTY)
                }
            }
        }
    }

    fun useFreeHint() {
        val puzzle = _uiState.value.currentPuzzle
        val unfound = puzzle.words.filter { !_uiState.value.foundWordIds.contains(it.id) }
        if (unfound.isEmpty()) return

        val target = unfound.first()
        val firstCell = CellCoordinate(target.startRow, target.startCol)
        _uiState.update {
            it.copy(
                highlightedHintCells = it.highlightedHintCells + firstCell,
                toastMessage = "Indice Gratuit : 1ère lettre de '${target.displayWord}' révélée !"
            )
        }
    }

    fun useJokerFirstLetter() {
        val cost = 25
        if (_uiState.value.profile.coins < cost) {
            _uiState.update {
                it.copy(
                    toastMessage = "Pièces insuffisantes ($cost requises). Regardez une vidéo !",
                    activeModal = ActiveModal.REWARDED_VIDEO,
                    pendingRewardType = JokerType.FIRST_LETTER
                )
            }
            return
        }

        val puzzle = _uiState.value.currentPuzzle
        val unfound = puzzle.words.filter { !_uiState.value.foundWordIds.contains(it.id) }
        if (unfound.isEmpty()) return

        val target = unfound.first()
        val firstCell = CellCoordinate(target.startRow, target.startCol)

        _uiState.update {
            it.copy(
                profile = it.profile.copy(
                    coins = it.profile.coins - cost,
                    jokersUsed = it.profile.jokersUsed + 1
                ),
                highlightedHintCells = it.highlightedHintCells + firstCell,
                toastMessage = "Joker 1ère Lettre activé (-$cost $) : '${target.displayWord[0]}'"
            )
        }
    }

    fun useJokerFiftyFifty() {
        val cost = 25
        if (_uiState.value.profile.coins < cost) {
            _uiState.update {
                it.copy(
                    toastMessage = "Pièces insuffisantes ($cost requises). Regardez une vidéo !",
                    activeModal = ActiveModal.REWARDED_VIDEO,
                    pendingRewardType = JokerType.FIFTY_FIFTY
                )
            }
            return
        }

        val puzzle = _uiState.value.currentPuzzle
        val unfound = puzzle.words.filter { !_uiState.value.foundWordIds.contains(it.id) }
        if (unfound.isEmpty()) return

        val target = unfound.first()
        val startCell = CellCoordinate(target.startRow, target.startCol)
        val endCell = CellCoordinate(target.endRow, target.endCol)

        _uiState.update {
            it.copy(
                profile = it.profile.copy(
                    coins = it.profile.coins - cost,
                    jokersUsed = it.profile.jokersUsed + 1
                ),
                highlightedHintCells = it.highlightedHintCells + startCell + endCell,
                toastMessage = "Joker 50/50 : Zone ciblée pour '${target.displayWord}' (-$cost $)"
            )
        }
    }

    fun requestExpertJoker(jokerType: JokerType) {
        val cost = 50
        if (_uiState.value.profile.coins >= cost) {
            applyJoker(jokerType, coinDeduction = cost)
        } else {
            startRewardedVideo(jokerType)
        }
    }

    private fun applyJoker(jokerType: JokerType, coinDeduction: Int) {
        val puzzle = _uiState.value.currentPuzzle
        val unfound = puzzle.words.filter { !_uiState.value.foundWordIds.contains(it.id) }
        if (unfound.isEmpty()) return
        val target = unfound.first()

        val newHighlighted = when (jokerType) {
            JokerType.FIRST_LETTER -> setOf(CellCoordinate(target.startRow, target.startCol))
            JokerType.FIFTY_FIFTY -> setOf(
                CellCoordinate(target.startRow, target.startCol),
                CellCoordinate(target.endRow, target.endCol)
            )
            else -> setOf(CellCoordinate(target.startRow, target.startCol))
        }

        _uiState.update {
            it.copy(
                profile = it.profile.copy(
                    coins = max(0, it.profile.coins - coinDeduction),
                    jokersUsed = it.profile.jokersUsed + 1
                ),
                highlightedHintCells = it.highlightedHintCells + newHighlighted,
                toastMessage = "Joker Théologien appliqué avec succès !"
            )
        }
    }

    // AdMob Rewarded Video Simulation
    fun unlockLevelWithRewardedAd(puzzle: BibleWordSearchPuzzle) {
        _uiState.update {
            it.copy(
                pendingUnlockPuzzle = puzzle,
                pendingRewardType = null,
                activeModal = ActiveModal.REWARDED_VIDEO,
                isRewardedVideoPlaying = true,
                rewardedVideoSecondsLeft = 5
            )
        }

        viewModelScope.launch {
            for (i in 5 downTo 1) {
                _uiState.update { it.copy(rewardedVideoSecondsLeft = i) }
                delay(1000)
            }
            onRewardedVideoCompleted()
        }
    }

    fun startRewardedVideo(rewardType: JokerType? = null) {
        _uiState.update {
            it.copy(
                activeModal = ActiveModal.REWARDED_VIDEO,
                isRewardedVideoPlaying = true,
                rewardedVideoSecondsLeft = 5,
                pendingRewardType = rewardType,
                pendingUnlockPuzzle = null
            )
        }

        viewModelScope.launch {
            for (i in 5 downTo 1) {
                _uiState.update { it.copy(rewardedVideoSecondsLeft = i) }
                delay(1000)
            }
            onRewardedVideoCompleted()
        }
    }

    private fun onRewardedVideoCompleted() {
        val reward = _uiState.value.pendingRewardType
        val targetPuzzle = _uiState.value.pendingUnlockPuzzle

        _uiState.update { current ->
            val rewardCoins = if (reward == null && targetPuzzle == null) 50 else 25
            val newUnlocked = if (targetPuzzle != null) current.unlockedLevelIds + targetPuzzle.id else current.unlockedLevelIds
            current.copy(
                isRewardedVideoPlaying = false,
                rewardedVideoSecondsLeft = 0,
                unlockedLevelIds = newUnlocked,
                profile = current.profile.copy(
                    coins = current.profile.coins + rewardCoins,
                    xp = current.profile.xp + 50
                ),
                toastMessage = if (targetPuzzle != null) {
                    "Niveau '${targetPuzzle.title}' débloqué avec succès ! +25 $ !"
                } else {
                    "Vidéo terminée ! +$rewardCoins Pièces d'Or accordées !"
                }
            )
        }

        if (reward != null) {
            applyJoker(reward, coinDeduction = 0)
        }

        closeModal()

        // If unlocking a level, immediately launch the puzzle!
        if (targetPuzzle != null) {
            _uiState.update { it.copy(pendingUnlockPuzzle = null) }
            startPuzzle(targetPuzzle)
        }
    }

    // Mystery Keyword Mini-Game
    fun selectMysteryBankLetter(bankIndex: Int) {
        val currentIndices = _uiState.value.mysterySelectedBankIndices
        val bank = _uiState.value.currentPuzzle.getEffectiveLetterBank()
        val target = _uiState.value.currentPuzzle.mysteryKeyword.trim().uppercase().replace("[^A-Z]".toRegex(), "")

        if (bankIndex in currentIndices) return
        if (currentIndices.size >= target.length) return
        if (bankIndex !in bank.indices) return

        val newIndices = currentIndices + bankIndex
        val newGuessed = newIndices.map { bank[it] }.joinToString("")
        _uiState.update {
            it.copy(
                mysterySelectedBankIndices = newIndices,
                mysteryGuessedLetters = newGuessed
            )
        }
    }

    fun removeMysteryLetterAtSlot(slotIndex: Int) {
        val currentIndices = _uiState.value.mysterySelectedBankIndices.toMutableList()
        val bank = _uiState.value.currentPuzzle.getEffectiveLetterBank()
        if (slotIndex in currentIndices.indices) {
            currentIndices.removeAt(slotIndex)
            val newGuessed = currentIndices.map { bank[it] }.joinToString("")
            _uiState.update {
                it.copy(
                    mysterySelectedBankIndices = currentIndices,
                    mysteryGuessedLetters = newGuessed
                )
            }
        }
    }

    fun removeLastMysteryLetter() {
        val currentIndices = _uiState.value.mysterySelectedBankIndices
        val bank = _uiState.value.currentPuzzle.getEffectiveLetterBank()
        if (currentIndices.isNotEmpty()) {
            val newIndices = currentIndices.dropLast(1)
            val newGuessed = newIndices.map { bank[it] }.joinToString("")
            _uiState.update {
                it.copy(
                    mysterySelectedBankIndices = newIndices,
                    mysteryGuessedLetters = newGuessed
                )
            }
        }
    }

    fun clearMysteryGuess() {
        _uiState.update {
            it.copy(
                mysterySelectedBankIndices = emptyList(),
                mysteryGuessedLetters = ""
            )
        }
    }

    fun validateMysteryWord() {
        val guess = _uiState.value.mysteryGuessedLetters.trim().uppercase().replace("[^A-Z]".toRegex(), "")
        val target = _uiState.value.currentPuzzle.mysteryKeyword.trim().uppercase().replace("[^A-Z]".toRegex(), "")
        val puzzle = _uiState.value.currentPuzzle

        if (guess == target) {
            _uiState.update { current ->
                val newProfile = current.profile.copy(
                    level = current.profile.level + 1,
                    xp = current.profile.xp + 250,
                    coins = current.profile.coins + puzzle.rewardCoins,
                    stars = current.profile.stars + puzzle.rewardStars,
                    puzzlesCompleted = current.profile.puzzlesCompleted + 1,
                    mysterySolvedCount = current.profile.mysterySolvedCount + 1
                )
                current.copy(
                    mysterySolved = true,
                    completedLevelIds = current.completedLevelIds + puzzle.id,
                    profile = newProfile,
                    toastMessage = "Gloire à Dieu ! Mot-Clé Mystère Révélé : $target !"
                )
            }
        } else {
            _uiState.update {
                it.copy(
                    mysterySelectedBankIndices = emptyList(),
                    mysteryGuessedLetters = "",
                    toastMessage = "Mot incorrect. Observez bien l'indice et les lettres d'or restantes sur la grille !"
                )
            }
        }
    }

    fun revealGraceWord() {
        _uiState.update { it.copy(isGraceWordRevealed = true) }
    }

    fun loadNextLevel() {
        val nextPuzzle = levelRepository.getNextLevel(_uiState.value.currentPuzzle)
        startPuzzle(nextPuzzle)
        closeModal()
    }

    fun buyShopPack(coinsAmount: Int, starsAmount: Int) {
        _uiState.update { current ->
            current.copy(
                profile = current.profile.copy(
                    coins = current.profile.coins + coinsAmount,
                    stars = current.profile.stars + starsAmount
                ),
                toastMessage = "Offrande reçue : +$coinsAmount Pièces d'Or !"
            )
        }
        closeModal()
    }

    fun updatePlayerName(newName: String) {
        if (newName.isNotBlank()) {
            _uiState.update {
                it.copy(profile = it.profile.copy(name = newName.trim()))
            }
        }
    }

    fun toggleSound() {
        _uiState.update {
            it.copy(profile = it.profile.copy(soundEnabled = !it.profile.soundEnabled))
        }
    }

    fun toggleHaptic() {
        _uiState.update {
            it.copy(profile = it.profile.copy(hapticEnabled = !it.profile.hapticEnabled))
        }
    }

    fun showToast(message: String) {
        _uiState.update { it.copy(toastMessage = message) }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
