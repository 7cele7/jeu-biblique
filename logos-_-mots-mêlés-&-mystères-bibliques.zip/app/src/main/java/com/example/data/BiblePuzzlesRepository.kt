package com.example.data

import com.example.model.BibleWordSearchPuzzle
import com.example.model.DailyScripture
import com.example.model.DifficultyLevel
import com.example.model.Trophy
import com.example.model.WordPlacement

object BiblePuzzlesRepository {

    val dailyVerses = listOf(
        DailyScripture(
            id = "v1",
            reference = "Jean 1:1-3",
            verseText = "Au commencement était la Parole, et la Parole était avec Dieu, et la Parole était Dieu. Elle était au commencement avec Dieu.",
            theme = "Le Verbe Éternel",
            meditation = "La Parole de Dieu est vivante, créatrice et éclaire chaque recoin de notre âme."
        ),
        DailyScripture(
            id = "v2",
            reference = "Psaume 119:105",
            verseText = "Ta parole est une lampe à mes pieds, et une lumière sur mon sentier.",
            theme = "Lumière et Vérité",
            meditation = "Quand les ténèbres s'épaississent, la sagesse divine guide chacun de nos pas."
        ),
        DailyScripture(
            id = "v3",
            reference = "Jean 14:6",
            verseText = "Jésus lui dit : Je suis le chemin, la vérité, et la vie. Nul ne vient au Père que par moi.",
            theme = "Le Chemin de Vie",
            meditation = "En Christ réside la plénitude de la vérité et l'accès auprès du Père céleste."
        ),
        DailyScripture(
            id = "v4",
            reference = "Philippiens 4:13",
            verseText = "Je puis tout par celui qui me fortifie.",
            theme = "Force Spirituelle",
            meditation = "Aucune épreuve n'est insurmontable lorsque la grâce divine soutient notre cœur."
        ),
        DailyScripture(
            id = "v5",
            reference = "Ésaïe 40:31",
            verseText = "Mais ceux qui se confient en l'Éternel renouvellent leur force. Ils prennent le vol comme les aigles.",
            theme = "Espérance Vivante",
            meditation = "La patience et la prière élèvent l'âme au-dessus des tumultes du monde."
        )
    )

    val defaultTrophies = listOf(
        Trophy(
            id = "t1",
            title = "Premier Mystère Révélé",
            description = "Déchiffrez votre premier mot-clé biblique",
            iconName = "star",
            unlocked = true,
            progress = 1,
            maxProgress = 1,
            rewardCoins = 100
        ),
        Trophy(
            id = "t2",
            title = "Explorateur de la Genèse",
            description = "Complétez 5 grilles bibliques de l'Ancien Testament",
            iconName = "menu_book",
            unlocked = true,
            progress = 5,
            maxProgress = 5,
            rewardCoins = 150
        ),
        Trophy(
            id = "t3",
            title = "Lumière du Monde",
            description = "Trouvez 50 mots bibliques dans les grilles",
            iconName = "wb_sunny",
            unlocked = true,
            progress = 50,
            maxProgress = 50,
            rewardCoins = 200
        ),
        Trophy(
            id = "t4",
            title = "Sagesse de Salomon",
            description = "Terminez une grille Expert sans utiliser d'indice",
            iconName = "psychology",
            unlocked = false,
            progress = 0,
            maxProgress = 1,
            rewardCoins = 300
        ),
        Trophy(
            id = "t5",
            title = "Fidèle Disciple",
            description = "Maintenez une série de 7 jours consécutifs",
            iconName = "military_tech",
            unlocked = false,
            progress = 5,
            maxProgress = 7,
            rewardCoins = 250
        )
    )

    // =========================================================================
    // GRILLES BIBLIQUES AVEC COMPTE STRICT DE MOTS PAR DIFFICULTÉ
    // 1. FACILE : 16 mots (entre 15 et 18) - Grille 12x12
    // 2. INTERMÉDIAIRE : 24 mots (entre 22 et 25) - Grille 14x14
    // 3. EXPERT : 28 mots (entre 25 et 30) - Grille 15x15
    // =========================================================================

    val samplePuzzles: List<BibleWordSearchPuzzle> = listOf(
        // ---------------------------------------------------------------------
        // 1. MODE FACILE (12x12) - 16 MOTS (Thème: La Création & Les Origines)
        // Mot Mystère: ALLIANCE
        // ---------------------------------------------------------------------
        BibleWordSearchPuzzle(
            id = "p_easy_1",
            title = "L'Aube de la Création",
            theme = "Genèse 1-3 • Le commencement du monde",
            difficulty = DifficultyLevel.FACILE,
            gridSize = 12,
            grid = listOf(
                // 0    1    2    3    4    5    6    7    8    9   10   11
                listOf('A', 'D', 'A', 'M', 'E', 'D', 'E', 'N', 'C', 'I', 'E', 'L'), // ADAM (0..3), EDEN (4..7), CIEL (8..11)
                listOf('E', 'V', 'E', 'A', 'R', 'B', 'R', 'E', 'J', 'O', 'U', 'R'), // EVE (0..2), ARBRE (3..7), JOUR (8..11)
                listOf('S', 'O', 'U', 'F', 'F', 'L', 'E', 'N', 'U', 'I', 'T', 'A'), // SOUFFLE (0..6), NUIT (7..10), A (Mystère)
                listOf('L', 'U', 'M', 'I', 'E', 'R', 'E', 'E', 'A', 'U', 'X', 'L'), // LUMIERE (0..6), EAUX (7..10), L (Mystère)
                listOf('S', 'O', 'L', 'E', 'I', 'L', 'L', 'U', 'N', 'E', 'S', 'L'), // SOLEIL (0..5), LUNE (6..9), S, L (Mystère)
                listOf('T', 'E', 'R', 'R', 'E', 'P', 'L', 'A', 'N', 'T', 'E', 'I'), // TERRE (0..4), PLANTE (5..10), I (Mystère)
                listOf('O', 'I', 'S', 'E', 'A', 'U', 'X', 'M', 'E', 'R', 'S', 'A'), // OISEAUX (0..6), MERS (7..10), A (Mystère)
                listOf('A', 'N', 'I', 'M', 'A', 'U', 'X', 'V', 'I', 'E', 'T', 'N'), // ANIMAUX (0..6), VIE (7..9), N (Mystère)
                listOf('B', 'E', 'N', 'I', 'T', 'R', 'E', 'P', 'O', 'S', 'O', 'C'), // BENIT (0..4), REPOS (5..9), C (Mystère)
                listOf('S', 'A', 'I', 'N', 'T', 'G', 'R', 'A', 'C', 'E', 'P', 'E'), // SAINT (0..4), GRACE (5..9), E (Mystère)
                listOf('P', 'A', 'I', 'X', 'A', 'M', 'O', 'U', 'R', 'F', 'O', 'I'), // PAIX (0..3), AMOUR (4..8), FOI (9..11)
                listOf('P', 'A', 'R', 'D', 'O', 'N', 'S', 'A', 'L', 'U', 'T', 'S')  // PARDON (0..5), SALUT (6..10)
            ),
            words = listOf(
                WordPlacement("e1", "ADAM", "ADAM", 0, 0, 0, 3, "Genèse 2:7", "Le premier homme façonné de la poussière", colorIndex = 0),
                WordPlacement("e2", "EDEN", "ÉDEN", 0, 4, 0, 7, "Genèse 2:8", "Le jardin de délices planté par Dieu", colorIndex = 1),
                WordPlacement("e3", "CIEL", "CIEL", 0, 8, 0, 11, "Genèse 1:1", "Créé au commencement avec la terre", colorIndex = 2),
                WordPlacement("e4", "EVE", "ÈVE", 1, 0, 1, 2, "Genèse 3:20", "La mère de tous les vivants", colorIndex = 3),
                WordPlacement("e5", "ARBRE", "ARBRE", 1, 3, 1, 7, "Genèse 2:9", "L'arbre de vie au milieu du jardin", colorIndex = 4),
                WordPlacement("e6", "JOUR", "JOUR", 1, 8, 1, 11, "Genèse 1:5", "Dieu appela la lumière jour", colorIndex = 5),
                WordPlacement("e7", "SOUFFLE", "SOUFFLE", 2, 0, 2, 6, "Genèse 2:7", "Le souffle de vie insufflé dans ses narines", colorIndex = 6),
                WordPlacement("e8", "NUIT", "NUIT", 2, 7, 2, 10, "Genèse 1:5", "Il appela les ténèbres nuit", colorIndex = 7),
                WordPlacement("e9", "LUMIERE", "LUMIÈRE", 3, 0, 3, 6, "Genèse 1:3", "Que la lumière soit ! Et la lumière fut", colorIndex = 0),
                WordPlacement("e10", "EAUX", "EAUX", 3, 7, 3, 10, "Genèse 1:2", "L'Esprit de Dieu se mouvait au-dessus des eaux", colorIndex = 1),
                WordPlacement("e11", "SOLEIL", "SOLEIL", 4, 0, 4, 5, "Genèse 1:16", "Le grand luminaire pour présider au jour", colorIndex = 2),
                WordPlacement("e12", "LUNE", "LUNE", 4, 6, 4, 9, "Genèse 1:16", "Le petit luminaire pour présider à la nuit", colorIndex = 3),
                WordPlacement("e13", "TERRE", "TERRE", 5, 0, 5, 4, "Genèse 1:10", "Dieu appela le sec terre", colorIndex = 4),
                WordPlacement("e14", "PLANTE", "PLANTE", 5, 5, 5, 10, "Genèse 1:11", "Que la terre produise de la verdure", colorIndex = 5),
                WordPlacement("e15", "OISEAUX", "OISEAUX", 6, 0, 6, 6, "Genèse 1:20", "Et que des oiseaux volent sur la terre", colorIndex = 6),
                WordPlacement("e16", "MERS", "MERS", 6, 7, 6, 10, "Genèse 1:10", "Il appela l'amas des eaux mers", colorIndex = 7)
            ),
            mysteryKeyword = "ALLIANCE",
            mysteryHint = "Pacte sacré et éternel scellé entre Dieu et l'humanité avec l'arc-en-ciel.",
            mysteryVerseReference = "Genèse 9:13",
            mysteryVerseText = "J'ai placé mon arc dans la nue, et il servira de signe d'alliance entre moi et la terre.",
            rewardCoins = 60,
            rewardStars = 1,
            unlocked = true
        ),

        // ---------------------------------------------------------------------
        // 2. MODE INTERMÉDIAIRE (14x14) - 24 MOTS (Thème: L'Évangile & Le Messie)
        // Mot Mystère: EMMANUEL
        // ---------------------------------------------------------------------
        BibleWordSearchPuzzle(
            id = "p_med_1",
            title = "Le Messie & La Rédemption",
            theme = "Évangiles de Luc & Jean • La venue du Sauveur",
            difficulty = DifficultyLevel.INTERMEDIAIRE,
            gridSize = 14,
            grid = listOf(
                // 0    1    2    3    4    5    6    7    8    9   10   11   12   13
                listOf('J', 'E', 'S', 'U', 'S', 'M', 'A', 'R', 'I', 'E', 'P', 'A', 'I', 'N'), // JESUS (0..4), MARIE (5..9), PAIN (10..13)
                listOf('B', 'E', 'T', 'H', 'L', 'E', 'E', 'M', 'C', 'R', 'O', 'I', 'X', 'E'), // BETHLEEM (0..7), CROIX (8..12), E (Mystère)
                listOf('N', 'A', 'Z', 'A', 'R', 'E', 'T', 'H', 'A', 'N', 'G', 'E', 'S', 'M'), // NAZARETH (0..7), ANGES (8..12), M (Mystère)
                listOf('A', 'P', 'O', 'T', 'R', 'E', 'S', 'J', 'O', 'R', 'D', 'A', 'I', 'N'), // APOTRES (0..6), JORDAN (7..12), M (Mystère)
                listOf('P', 'A', 'S', 'T', 'E', 'U', 'R', 'B', 'E', 'R', 'G', 'E', 'R', 'A'), // PASTEUR (0..6), BERGER (7..12), A (Mystère)
                listOf('E', 'V', 'A', 'N', 'G', 'I', 'L', 'E', 'R', 'O', 'Y', 'A', 'U', 'N'), // EVANGILE (0..7), ROYAUME.. N (Mystère)
                listOf('M', 'I', 'R', 'A', 'C', 'L', 'E', 'P', 'A', 'R', 'A', 'B', 'O', 'U'), // MIRACLE (0..6), PARABOLE.. U (Mystère)
                listOf('D', 'I', 'S', 'C', 'I', 'P', 'L', 'E', 'S', 'S', 'A', 'L', 'U', 'E'), // DISCIPLES (0..8), SALUT (9..13) (E mystère)
                listOf('P', 'A', 'R', 'D', 'O', 'N', 'G', 'R', 'A', 'C', 'E', 'F', 'O', 'L'), // PARDON (0..5), GRACE (6..10), FOI (11..13)
                listOf('A', 'M', 'O', 'U', 'R', 'V', 'E', 'R', 'I', 'T', 'E', 'V', 'I', 'E'), // AMOUR (0..4), VERITE (5..10), VIE (11..13)
                listOf('P', 'R', 'I', 'E', 'R', 'E', 'J', 'E', 'U', 'N', 'E', 'P', 'A', 'X'), // PRIERE (0..5), JEUNE (6..10), PAIX (10..13)
                listOf('B', 'A', 'P', 'T', 'E', 'M', 'E', 'S', 'E', 'R', 'M', 'O', 'N', 'S'), // BAPTEME (0..6), SERMON (7..12)
                listOf('C', 'E', 'N', 'E', 'V', 'I', 'G', 'N', 'E', 'T', 'E', 'M', 'P', 'L'), // CENE (0..3), VIGNE (4..8), TEMPLE (9..14)
                listOf('R', 'E', 'S', 'U', 'R', 'R', 'E', 'C', 'T', 'I', 'O', 'N', 'O', 'R')  // RESURRECTION (0..11)
            ),
            words = listOf(
                WordPlacement("m1", "JESUS", "JÉSUS", 0, 0, 0, 4, "Matthieu 1:21", "Car c'est lui qui sauvera son peuple", colorIndex = 0),
                WordPlacement("m2", "MARIE", "MARIE", 0, 5, 0, 9, "Luc 1:30", "Tu as trouvé grâce devant Dieu", colorIndex = 1),
                WordPlacement("m3", "PAIN", "PAIN", 0, 10, 0, 13, "Jean 6:35", "Je suis le pain de vie", colorIndex = 2),
                WordPlacement("m4", "BETHLEEM", "BETHLÉEM", 1, 0, 1, 7, "Michée 5:2", "La cité royale où naquit le Messie", colorIndex = 3),
                WordPlacement("m5", "CROIX", "CROIX", 1, 8, 1, 12, "1 Cor 1:18", "L'instrument de la rédemption", colorIndex = 4),
                WordPlacement("m6", "NAZARETH", "NAZARETH", 2, 0, 2, 7, "Matthieu 2:23", "La ville d'enfance du Sauveur", colorIndex = 5),
                WordPlacement("m7", "ANGES", "ANGES", 2, 8, 2, 12, "Luc 2:13", "Une multitude de l'armée céleste", colorIndex = 6),
                WordPlacement("m8", "APOTRES", "APÔTRES", 3, 0, 3, 6, "Luc 6:13", "Les douze envoyés du Royaume", colorIndex = 7),
                WordPlacement("m9", "JORDAN", "JORDAN", 3, 7, 3, 12, "Matthieu 3:13", "Le fleuve du saint baptême", colorIndex = 0),
                WordPlacement("m10", "PASTEUR", "PASTEUR", 4, 0, 4, 6, "Jean 10:11", "Le bon berger donne sa vie pour ses brebis", colorIndex = 1),
                WordPlacement("m11", "BERGER", "BERGER", 4, 7, 4, 12, "Psaume 23:1", "L'Éternel est mon berger, je ne manquerai de rien", colorIndex = 2),
                WordPlacement("m12", "EVANGILE", "ÉVANGILE", 5, 0, 5, 7, "Romains 1:16", "La bonne nouvelle de la puissance de Dieu", colorIndex = 3),
                WordPlacement("m13", "MIRACLE", "MIRACLE", 6, 0, 6, 6, "Jean 2:11", "Le premier des miracles à Cana de Galilée", colorIndex = 4),
                WordPlacement("m14", "DISCIPLES", "DISCIPLES", 7, 0, 7, 8, "Jean 8:31", "Si vous demeurez dans ma parole, vous êtes mes disciples", colorIndex = 5),
                WordPlacement("m15", "PARDON", "PARDON", 8, 0, 8, 5, "Éphésiens 1:7", "La rédemption par son sang, le pardon des péchés", colorIndex = 6),
                WordPlacement("m16", "GRACE", "GRÂCE", 8, 6, 8, 10, "Jean 1:17", "La grâce et la vérité sont venues par Jésus-Christ", colorIndex = 7),
                WordPlacement("m17", "AMOUR", "AMOUR", 9, 0, 9, 4, "1 Jean 4:8", "Celui qui n'aime pas n'a pas connu Dieu, car Dieu est amour", colorIndex = 0),
                WordPlacement("m18", "VERITE", "VÉRITÉ", 9, 5, 9, 10, "Jean 14:6", "Je suis le chemin, la vérité, et la vie", colorIndex = 1),
                WordPlacement("m19", "PRIERE", "PRIÈRE", 10, 0, 10, 5, "Matthieu 6:9", "Voici donc comment vous devez prier : Notre Père", colorIndex = 2),
                WordPlacement("m20", "JEUNE", "JEÛNE", 10, 6, 10, 10, "Matthieu 4:2", "Après avoir jeûné quarante jours et quarante nuits", colorIndex = 3),
                WordPlacement("m21", "BAPTEME", "BAPTÊME", 11, 0, 11, 6, "Matthieu 28:19", "Les baptisant au nom du Père, du Fils et du Saint-Esprit", colorIndex = 4),
                WordPlacement("m22", "SERMON", "SERMON", 11, 7, 11, 12, "Matthieu 5:1", "Le sermon sur la montagne des béatitudes", colorIndex = 5),
                WordPlacement("m23", "CENE", "CÈNE", 12, 0, 12, 3, "Luc 22:19", "Faites ceci en mémoire de moi", colorIndex = 6),
                WordPlacement("m24", "VIGNE", "VIGNE", 12, 4, 12, 8, "Jean 15:5", "Je suis le cep, vous êtes les sarments", colorIndex = 7)
            ),
            mysteryKeyword = "EMMANUEL",
            mysteryHint = "Nom prophétique hébreu signifiant 'Dieu avec nous'.",
            mysteryVerseReference = "Matthieu 1:23",
            mysteryVerseText = "Voici, la vierge sera enceinte, elle enfantera un fils, et on lui donnera le nom d'Emmanuel, ce qui signifie Dieu avec nous.",
            rewardCoins = 100,
            rewardStars = 2,
            unlocked = true
        ),

        // ---------------------------------------------------------------------
        // 3. MODE EXPERT (15x15) - 28 MOTS (Thème: Prophéties & Apocalypse Céleste)
        // Mot Mystère: RESURRECTION
        // ---------------------------------------------------------------------
        BibleWordSearchPuzzle(
            id = "p_exp_1",
            title = "Les Mystères de l'Apocalypse",
            theme = "Apocalypse, Ésaïe & Daniel • La Jérusalem céleste",
            difficulty = DifficultyLevel.EXPERT,
            gridSize = 15,
            grid = listOf(
                // 0    1    2    3    4    5    6    7    8    9   10   11   12   13   14
                listOf('A', 'P', 'O', 'C', 'A', 'L', 'Y', 'P', 'S', 'E', 'T', 'R', 'O', 'N', 'E'), // APOCALYPSE (0..9), TRONE (10..14)
                listOf('J', 'E', 'R', 'U', 'S', 'A', 'L', 'E', 'M', 'A', 'G', 'N', 'E', 'A', 'U'), // JERUSALEM (0..8), AGNEAU (9..14)
                listOf('T', 'E', 'M', 'P', 'L', 'E', 'P', 'R', 'O', 'P', 'H', 'E', 'T', 'E', 'S'), // TEMPLE (0..5), PROPHETES (6..14)
                listOf('L', 'U', 'M', 'I', 'E', 'R', 'E', 'V', 'I', 'C', 'T', 'O', 'I', 'R', 'E'), // LUMIERE (0..6), VICTOIRE (7..14)
                listOf('S', 'E', 'P', 'T', 'S', 'C', 'E', 'A', 'U', 'X', 'E', 'S', 'P', 'R', 'I'), // SEPTSCEAUX (0..9), ESPRIT (10..14)
                listOf('T', 'R', 'O', 'M', 'P', 'E', 'T', 'T', 'E', 'S', 'C', 'O', 'U', 'R', 'O'), // TROMPETTES (0..9), COURONNE..
                listOf('N', 'O', 'U', 'V', 'E', 'A', 'U', 'C', 'I', 'E', 'L', 'T', 'E', 'R', 'R'), // NOUVEAU CIEL..
                listOf('A', 'L', 'P', 'H', 'A', 'O', 'M', 'E', 'G', 'A', 'A', 'R', 'B', 'R', 'E'), // ALPHA (0..4), OMEGA (5..9), ARBRE (10..14)
                listOf('F', 'L', 'E', 'U', 'V', 'E', 'D', 'E', 'V', 'I', 'E', 'P', 'A', 'I', 'X'), // FLEUVE (0..5), DEVIE (6..10), PAIX (11..14)
                listOf('M', 'U', 'R', 'A', 'I', 'L', 'L', 'E', 'P', 'O', 'R', 'T', 'E', 'S', 'S'), // MURAILLE (0..7), PORTES (8..13)
                listOf('P', 'I', 'E', 'R', 'R', 'E', 'S', 'P', 'R', 'E', 'C', 'I', 'E', 'U', 'X'), // PIERRES (0..6), PRECIEUX (7..14)
                listOf('J', 'A', 'S', 'P', 'E', 'S', 'A', 'P', 'H', 'I', 'R', 'E', 'M', 'E', 'R'), // JASPE (0..4), SAPHIRE (5..11), MER (12..14)
                listOf('A', 'L', 'L', 'E', 'L', 'U', 'I', 'A', 'G', 'L', 'O', 'I', 'R', 'E', 'S'), // ALLELUIA (0..7), GLOIRE (8..13)
                listOf('S', 'A', 'I', 'N', 'T', 'E', 'T', 'E', 'C', 'E', 'L', 'E', 'S', 'T', 'E'), // SAINTETE (0..7), CELESTE (8..14)
                listOf('E', 'T', 'E', 'R', 'N', 'I', 'T', 'E', 'A', 'M', 'E', 'N', 'O', 'U', 'I')  // ETERNITE (0..7), AMEN (8..11), OUI (12..14)
            ),
            words = listOf(
                WordPlacement("x1", "APOCALYPSE", "APOCALYPSE", 0, 0, 0, 9, "Apocalypse 1:1", "Révélation de Jésus-Christ sur les choses à venir", colorIndex = 0),
                WordPlacement("x2", "TRONE", "TRÔNE", 0, 10, 0, 14, "Apocalypse 4:2", "Le trône céleste entouré d'éclairs et de voix", colorIndex = 1),
                WordPlacement("x3", "JERUSALEM", "JÉRUSALEM", 1, 0, 1, 8, "Apocalypse 21:2", "La sainte cité descendant du ciel d'auprès de Dieu", colorIndex = 2),
                WordPlacement("x4", "AGNEAU", "AGNEAU", 1, 9, 1, 14, "Apocalypse 5:6", "L'Agneau immolé digne d'ouvrir les sceaux", colorIndex = 3),
                WordPlacement("x5", "TEMPLE", "TEMPLE", 2, 0, 2, 5, "Apocalypse 21:22", "Le Seigneur Dieu Tout-Puissant est son temple", colorIndex = 4),
                WordPlacement("x6", "PROPHETES", "PROPHÈTES", 2, 6, 2, 14, "Hébreux 1:1", "Par qui Dieu a autrefois parlé à nos pères", colorIndex = 5),
                WordPlacement("x7", "LUMIERE", "LUMIÈRE", 3, 0, 3, 6, "Apocalypse 22:5", "La gloire de Dieu les éclairera éternellement", colorIndex = 6),
                WordPlacement("x8", "VICTOIRE", "VICTOIRE", 3, 7, 3, 14, "1 Jean 5:4", "Ce qui triomphe du monde, c'est notre foi", colorIndex = 7),
                WordPlacement("x9", "SEPTSCEAUX", "SEPT SCEAUX", 4, 0, 4, 9, "Apocalypse 5:1", "Le livre scellé de sept sceaux divins", colorIndex = 0),
                WordPlacement("x10", "ESPRIT", "ESPRIT", 4, 10, 4, 14, "Apocalypse 22:17", "L'Esprit et l'épouse disent : Viens !", colorIndex = 1),
                WordPlacement("x11", "TROMPETTES", "TROMPETTES", 5, 0, 5, 9, "Apocalypse 8:2", "Les sept trompettes données aux anges", colorIndex = 2),
                WordPlacement("x12", "NOUVEAU", "NOUVEAU", 6, 0, 6, 6, "Apocalypse 21:1", "Un ciel nouveau et une terre nouvelle", colorIndex = 3),
                WordPlacement("x13", "ALPHA", "ALPHA", 7, 0, 7, 4, "Apocalypse 1:8", "Je suis l'Alpha et l'Oméga", colorIndex = 4),
                WordPlacement("x14", "OMEGA", "OMÉGA", 7, 5, 7, 9, "Apocalypse 22:13", "Le premier et le dernier, le commencement et la fin", colorIndex = 5),
                WordPlacement("x15", "ARBRE", "ARBRE", 7, 10, 7, 14, "Apocalypse 22:2", "L'arbre de vie produisant douze récoltes", colorIndex = 6),
                WordPlacement("x16", "FLEUVE", "FLEUVE", 8, 0, 8, 5, "Apocalypse 22:1", "Un fleuve d'eau de la vie, limpide comme du cristal", colorIndex = 7),
                WordPlacement("x17", "PAIX", "PAIX", 8, 11, 8, 14, "Jean 14:27", "Je vous laisse la paix, je vous donne ma paix", colorIndex = 0),
                WordPlacement("x18", "MURAILLE", "MURAILLE", 9, 0, 9, 7, "Apocalypse 21:12", "Une grande et haute muraille avec douze portes", colorIndex = 1),
                WordPlacement("x19", "PORTES", "PORTES", 9, 8, 9, 13, "Apocalypse 21:21", "Les douze portes étaient douze perles", colorIndex = 2),
                WordPlacement("x20", "PIERRES", "PIERRES", 10, 0, 10, 6, "Apocalypse 21:19", "Les fondements ornés de pierres précieuses", colorIndex = 3),
                WordPlacement("x21", "PRECIEUX", "PRÉCIEUX", 10, 7, 10, 14, "1 Pierre 2:6", "Une pierre angulaire, choisie, précieuse", colorIndex = 4),
                WordPlacement("x22", "JASPE", "JASPE", 11, 0, 11, 4, "Apocalypse 21:11", "Son éclat était semblable à une pierre de jaspe", colorIndex = 5),
                WordPlacement("x23", "SAPHIRE", "SAPHIR", 11, 5, 11, 11, "Apocalypse 21:19", "Le second fondement était de saphir", colorIndex = 6),
                WordPlacement("x24", "ALLELUIA", "ALLÉLUIA", 12, 0, 12, 7, "Apocalypse 19:1", "Alléluia ! Le salut, la gloire et la puissance à notre Dieu", colorIndex = 7),
                WordPlacement("x25", "GLOIRE", "GLOIRE", 12, 8, 12, 13, "Apocalypse 21:23", "Car la gloire de Dieu l'éclaire", colorIndex = 0),
                WordPlacement("x26", "SAINTETE", "SAINTETÉ", 13, 0, 13, 7, "Exode 15:11", "Magnifique en sainteté, digne de louanges", colorIndex = 1),
                WordPlacement("x27", "CELESTE", "CÉLESTE", 13, 8, 13, 14, "Hébreux 12:22", "La cité du Dieu vivant, la Jérusalem céleste", colorIndex = 2),
                WordPlacement("x28", "ETERNITE", "ÉTERNITÉ", 14, 0, 14, 7, "Ésaïe 57:15", "Dont la demeure est éternelle et dont le nom est saint", colorIndex = 3)
            ),
            mysteryKeyword = "RESURRECTION",
            mysteryHint = "Le triomphe suprême sur la mort et la promesse de la vie éternelle.",
            mysteryVerseReference = "Jean 11:25",
            mysteryVerseText = "Jésus lui dit : Je suis la résurrection et la vie. Celui qui croit en moi vivra, quand même il serait mort.",
            rewardCoins = 150,
            rewardStars = 3,
            unlocked = true
        )
    )
}
