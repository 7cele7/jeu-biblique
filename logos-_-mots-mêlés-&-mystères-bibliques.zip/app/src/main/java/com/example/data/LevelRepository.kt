package com.example.data

import android.content.Context
import com.example.model.BibleWordSearchPuzzle
import com.example.model.DifficultyLevel
import com.example.model.LevelCollection
import com.example.model.LevelData
import com.example.model.WordPlacement
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlin.random.Random

class LevelRepository(private val context: Context) {

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val adapter = moshi.adapter(LevelCollection::class.java)

    private val cachedPuzzlesByDifficulty = mutableMapOf<DifficultyLevel, MutableList<BibleWordSearchPuzzle>>()

    fun loadLevelsForDifficulty(difficulty: DifficultyLevel): List<BibleWordSearchPuzzle> {
        cachedPuzzlesByDifficulty[difficulty]?.let { if (it.isNotEmpty()) return it }

        val fileName = when (difficulty) {
            DifficultyLevel.FACILE -> "levels_easy.json"
            DifficultyLevel.INTERMEDIAIRE -> "levels_medium.json"
            DifficultyLevel.EXPERT -> "levels_hard.json"
        }

        val puzzles = try {
            val jsonString = context.assets.open(fileName).bufferedReader().use { it.readText() }
            val levelCollection = adapter.fromJson(jsonString)
            levelCollection?.levels?.map { levelData ->
                generatePuzzleFromLevelData(levelData, difficulty)
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            // Fallback to sample repository if assets cannot be read
            BiblePuzzlesRepository.samplePuzzles.filter { it.difficulty == difficulty }
        }

        val resultList = puzzles.toMutableList()
        cachedPuzzlesByDifficulty[difficulty] = resultList
        return resultList
    }

    fun getPuzzle(difficulty: DifficultyLevel, levelNumber: Int): BibleWordSearchPuzzle? {
        val levels = loadLevelsForDifficulty(difficulty)
        return levels.find { it.levelNumber == levelNumber } ?: levels.firstOrNull()
    }

    fun getNextLevel(currentPuzzle: BibleWordSearchPuzzle): BibleWordSearchPuzzle {
        val levels = loadLevelsForDifficulty(currentPuzzle.difficulty)
        val nextLevelNumber = currentPuzzle.levelNumber + 1
        val nextPuzzle = levels.find { it.levelNumber == nextLevelNumber }
        return nextPuzzle ?: levels.first()
    }

    private fun generatePuzzleFromLevelData(
        levelData: LevelData,
        difficulty: DifficultyLevel
    ): BibleWordSearchPuzzle {
        val gridSize = levelData.gridSize
        val grid = Array(gridSize) { CharArray(gridSize) { ' ' } }
        val placedWords = mutableListOf<WordPlacement>()

        val directions = when (difficulty) {
            DifficultyLevel.FACILE -> listOf(
                Pair(0, 1),   // Horizontal Left->Right
                Pair(1, 0),   // Vertical Top->Down
                Pair(1, 1)    // Diagonal Down-Right
            )
            DifficultyLevel.INTERMEDIAIRE -> listOf(
                Pair(0, 1),   // Horizontal L->R
                Pair(0, -1),  // Horizontal R->L
                Pair(1, 0),   // Vertical T->D
                Pair(-1, 0),  // Vertical D->T
                Pair(1, 1),   // Diagonal Down-Right
                Pair(-1, 1)   // Diagonal Up-Right
            )
            DifficultyLevel.EXPERT -> listOf(
                Pair(0, 1), Pair(0, -1),
                Pair(1, 0), Pair(-1, 0),
                Pair(1, 1), Pair(-1, -1),
                Pair(1, -1), Pair(-1, 1)
            )
        }

        // Sort words by length descending for best placement efficiency
        val sortedWords = levelData.words.sortedByDescending { it.word.length }
        val random = Random(levelData.levelNumber * 31L + difficulty.ordinal)

        sortedWords.forEachIndexed { index, wordData ->
            val normalizedWord = wordData.word.uppercase().replace("[^A-Z]".toRegex(), "")
            if (normalizedWord.length <= gridSize) {
                var placed = false
                var attempts = 0
                val shuffledDirs = directions.shuffled(random)

                while (!placed && attempts < 150) {
                    attempts++
                    val dir = shuffledDirs[attempts % shuffledDirs.size]
                    val dRow = dir.first
                    val dCol = dir.second

                    val maxStartRow = when {
                        dRow > 0 -> gridSize - normalizedWord.length
                        dRow < 0 -> normalizedWord.length - 1
                        else -> gridSize - 1
                    }
                    val minStartRow = when {
                        dRow > 0 -> 0
                        dRow < 0 -> normalizedWord.length - 1
                        else -> 0
                    }

                    val maxStartCol = when {
                        dCol > 0 -> gridSize - normalizedWord.length
                        dCol < 0 -> normalizedWord.length - 1
                        else -> gridSize - 1
                    }
                    val minStartCol = when {
                        dCol > 0 -> 0
                        dCol < 0 -> normalizedWord.length - 1
                        else -> 0
                    }

                    if (maxStartRow >= minStartRow && maxStartCol >= minStartCol) {
                        val startRow = random.nextInt(minStartRow, maxStartRow + 1)
                        val startCol = random.nextInt(minStartCol, maxStartCol + 1)

                        var canPlace = true
                        for (i in normalizedWord.indices) {
                            val r = startRow + i * dRow
                            val c = startCol + i * dCol
                            val currentCell = grid[r][c]
                            if (currentCell != ' ' && currentCell != normalizedWord[i]) {
                                canPlace = false
                                break
                            }
                        }

                        if (canPlace) {
                            for (i in normalizedWord.indices) {
                                val r = startRow + i * dRow
                                val c = startCol + i * dCol
                                grid[r][c] = normalizedWord[i]
                            }

                            val endRow = startRow + (normalizedWord.length - 1) * dRow
                            val endCol = startCol + (normalizedWord.length - 1) * dCol

                            placedWords.add(
                                WordPlacement(
                                    id = "w_${levelData.levelNumber}_${index}_$normalizedWord",
                                    word = normalizedWord,
                                    displayWord = wordData.displayWord ?: wordData.word,
                                    startRow = startRow,
                                    startCol = startCol,
                                    endRow = endRow,
                                    endCol = endCol,
                                    reference = wordData.reference,
                                    definition = wordData.definition ?: "Mot biblique",
                                    colorIndex = index
                                )
                            )
                            placed = true
                        }
                    }
                }
            }
        }

        // Fill remaining empty cells with mystery word letters and biblical alphabet
        val emptyCells = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until gridSize) {
            for (c in 0 until gridSize) {
                if (grid[r][c] == ' ') {
                    emptyCells.add(Pair(r, c))
                }
            }
        }

        val shuffledEmpty = emptyCells.shuffled(random)
        val normalizedMystery = levelData.mysteryWord.uppercase().replace("[^A-Z]".toRegex(), "")
        var mysteryIndex = 0

        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        shuffledEmpty.forEach { (r, c) ->
            if (mysteryIndex < normalizedMystery.length) {
                grid[r][c] = normalizedMystery[mysteryIndex]
                mysteryIndex++
            } else {
                grid[r][c] = alphabet[random.nextInt(alphabet.length)]
            }
        }

        val decoyCount = when (difficulty) {
            DifficultyLevel.FACILE -> 3
            DifficultyLevel.INTERMEDIAIRE -> 4
            DifficultyLevel.EXPERT -> 4
        }
        val distractorLetters = if (shuffledEmpty.size > normalizedMystery.length) {
            shuffledEmpty.drop(normalizedMystery.length)
                .map { (r, c) -> grid[r][c] }
                .take(decoyCount)
        } else {
            listOf('A', 'E', 'S', 'T', 'R', 'N').take(decoyCount)
        }
        val mysteryLetterBank = (normalizedMystery.toList() + distractorLetters).shuffled(random)

        val gridList = grid.map { row -> row.toList() }

        return BibleWordSearchPuzzle(
            id = "puzzle_${difficulty.name.lowercase()}_${levelData.levelNumber}",
            levelNumber = levelData.levelNumber,
            title = levelData.title,
            theme = levelData.theme ?: "${difficulty.displayName} • Niveau ${levelData.levelNumber}",
            difficulty = difficulty,
            gridSize = gridSize,
            grid = gridList,
            words = placedWords,
            mysteryKeyword = levelData.mysteryWord,
            mysteryHint = levelData.mysteryHint ?: "Mot sacré de la Bible",
            mysteryVerseReference = levelData.graceWord.reference,
            mysteryVerseText = levelData.graceWord.verse,
            mysteryLetterBank = mysteryLetterBank,
            graceWord = levelData.graceWord,
            rewardCoins = 50 + (levelData.levelNumber * 10),
            rewardStars = 1
        )
    }
}
