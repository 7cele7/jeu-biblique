package com.example.model

enum class DifficultyLevel(
    val displayName: String,
    val frenchSubtitle: String,
    val minStarsRequired: Int
) {
    FACILE("FACILE", "Débutant • Indice Gratuit", 0),
    INTERMEDIAIRE("INTERMÉDIAIRE", "Disciple • 2 Jokers ($)", 3),
    EXPERT("EXPERT", "Théologien • Jokers Récompensés (Pub / $)", 8)
}

enum class ActiveScreen {
    HOME,
    LEVEL_SELECT,
    GAME
}

enum class ActiveModal {
    NONE,
    PROFILE,
    SHOP,
    STATS,
    TROPHIES,
    SETTINGS,
    REWARDED_VIDEO,
    MYSTERY_REVEAL
}

data class CellCoordinate(
    val row: Int,
    val col: Int
)

data class WordPlacement(
    val id: String,
    val word: String, // Normalized uppercase word (e.g. "ALLIANCE")
    val displayWord: String, // Original display with accents (e.g. "ALLIANCE")
    val startRow: Int,
    val startCol: Int,
    val endRow: Int,
    val endCol: Int,
    val reference: String, // Biblical reference (e.g. "Genèse 9:13")
    val definition: String, // Short biblical meaning
    val found: Boolean = false,
    val hintRevealed: Boolean = false,
    val colorIndex: Int = 0
)

data class BibleWordSearchPuzzle(
    val id: String,
    val levelNumber: Int = 1,
    val title: String,
    val theme: String,
    val difficulty: DifficultyLevel,
    val gridSize: Int,
    val grid: List<List<Char>>,
    val words: List<WordPlacement>,
    val mysteryKeyword: String, // Sacred hidden keyword from unused letters
    val mysteryHint: String,
    val mysteryVerseReference: String,
    val mysteryVerseText: String,
    val mysteryLetterBank: List<Char> = emptyList(), // Letter bank containing mystery keyword + extra decoy letters
    val graceWord: GraceWord? = null,
    val rewardCoins: Int = 50,
    val rewardStars: Int = 1,
    val unlocked: Boolean = true
) {
    fun getEffectiveLetterBank(): List<Char> {
        if (mysteryLetterBank.isNotEmpty()) return mysteryLetterBank
        val normalizedMystery = mysteryKeyword.uppercase().replace("[^A-Z]".toRegex(), "")
        val candidateDecoys = listOf('A', 'E', 'S', 'T', 'R', 'N', 'L', 'O', 'I', 'M', 'P', 'D', 'C', 'U', 'B')
            .filter { !normalizedMystery.contains(it) }
        val decoyCount = when (difficulty) {
            DifficultyLevel.FACILE -> 3
            DifficultyLevel.INTERMEDIAIRE -> 4
            DifficultyLevel.EXPERT -> 4
        }
        val decoys = candidateDecoys.take(decoyCount)
        return (normalizedMystery.toList() + decoys).shuffled(kotlin.random.Random(id.hashCode()))
    }
}

data class DailyScripture(
    val id: String,
    val reference: String,
    val verseText: String,
    val theme: String,
    val meditation: String
)

data class PlayerProfile(
    val name: String = "Disciple",
    val level: Int = 7,
    val xp: Int = 1420,
    val coins: Int = 280,
    val stars: Int = 14,
    val currentStreakDays: Int = 5,
    val puzzlesCompleted: Int = 12,
    val wordsFound: Int = 78,
    val mysterySolvedCount: Int = 11,
    val jokersUsed: Int = 6,
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true
)

data class Trophy(
    val id: String,
    val title: String,
    val description: String,
    val iconName: String,
    val unlocked: Boolean,
    val progress: Int,
    val maxProgress: Int,
    val rewardCoins: Int
)

enum class JokerType {
    FREE_HINT,
    FIFTY_FIFTY,
    FIRST_LETTER,
    REVEAL_WORD
}
