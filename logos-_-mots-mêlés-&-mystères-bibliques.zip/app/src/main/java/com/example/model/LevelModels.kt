package com.example.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GraceWord(
    @Json(name = "reference") val reference: String,
    @Json(name = "verse") val verse: String,
    @Json(name = "message") val message: String
)

@JsonClass(generateAdapter = true)
data class WordData(
    @Json(name = "word") val word: String,
    @Json(name = "displayWord") val displayWord: String? = null,
    @Json(name = "reference") val reference: String,
    @Json(name = "definition") val definition: String? = null
)

@JsonClass(generateAdapter = true)
data class LevelData(
    @Json(name = "levelNumber") val levelNumber: Int,
    @Json(name = "title") val title: String,
    @Json(name = "theme") val theme: String? = null,
    @Json(name = "gridSize") val gridSize: Int,
    @Json(name = "mysteryWord") val mysteryWord: String,
    @Json(name = "mysteryHint") val mysteryHint: String? = null,
    @Json(name = "words") val words: List<WordData>,
    @Json(name = "graceWord") val graceWord: GraceWord
)

@JsonClass(generateAdapter = true)
data class LevelCollection(
    @Json(name = "levels") val levels: List<LevelData>
)
