package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveModal
import com.example.model.ActiveScreen
import com.example.model.BibleWordSearchPuzzle
import com.example.model.DifficultyLevel
import com.example.ui.components.AdMobBannerView
import com.example.ui.components.GoldBorderCard
import com.example.ui.theme.BlackCanvas
import com.example.ui.theme.EasyGreen
import com.example.ui.theme.ExpertRed
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldButtonGradient
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MediumOrange
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.GameUiState
import com.example.viewmodel.GameViewModel

@Composable
fun LevelSelectScreen(
    uiState: GameUiState,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val difficulty = uiState.selectedDifficulty
    val levels = uiState.availableLevels
    val completedIds = uiState.completedLevelIds
    val unlockedIds = uiState.unlockedLevelIds

    val diffColor = when (difficulty) {
        DifficultyLevel.FACILE -> EasyGreen
        DifficultyLevel.INTERMEDIAIRE -> MediumOrange
        DifficultyLevel.EXPERT -> ExpertRed
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BlackCanvas)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            // =========================================================================
            // 1. TOP BAR (Bouton Retour, Titre Difficulté, Étoiles & Pièces)
            // =========================================================================
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("level_select_top_bar"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.openScreen(ActiveScreen.HOME) },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF14120A))
                            .border(1.2.dp, GoldBorder, CircleShape)
                            .testTag("btn_level_select_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Retour",
                            tint = GoldPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "CHOIX DU NIVEAU",
                            color = GoldBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.8.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(diffColor)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "${difficulty.displayName.uppercase()} • GRILLE ${difficultySpec(difficulty)}",
                                color = diffColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Étoiles Badge
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF16140A))
                            .border(1.dp, GoldBorderSubtle, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Étoiles",
                            tint = GoldAmber,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "${uiState.profile.stars} ⭐",
                            color = GoldLight,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Pièces Badge
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF16140A))
                            .border(1.2.dp, GoldBorder, RoundedCornerShape(12.dp))
                            .clickable { viewModel.openModal(ActiveModal.SHOP) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("btn_level_select_shop"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Pièces",
                            tint = GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "${uiState.profile.coins} $",
                            color = GoldBright,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // =========================================================================
            // 2. HERO CARD RECAPITULATIF DE LA DIFFICULTE
            // =========================================================================
            GoldBorderCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("level_select_hero_card"),
                cornerRadius = 14.dp,
                borderWidth = 1.2.dp,
                backgroundColor = Color(0xFF131109)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = GoldAmber,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PARCOURS SPIRITUEL",
                                color = GoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "Résolvez chaque grille pour débloquer le Mot Mystère et recevoir la Parole de Grâce.",
                            color = TextMuted,
                            fontSize = 10.5.sp,
                            lineHeight = 14.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1F1A0C))
                            .border(1.dp, GoldBorder, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${completedIds.size.coerceAtMost(levels.size)} / ${levels.size}",
                                color = GoldBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "RÉUSSIS",
                                color = GoldLight,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // =========================================================================
            // 3. LISTE DÉFILABLE DES NIVEAUX (Boutons JOUER et DÉBLOQUER / VOIR PUB)
            // =========================================================================
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("levels_list"),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 8.dp)
            ) {
                itemsIndexed(levels) { index, puzzle ->
                    val isCompleted = completedIds.contains(puzzle.id)
                    // Unlocked if first level, or explicitly unlocked, or previous level completed
                    val isUnlocked = index == 0 ||
                            unlockedIds.contains(puzzle.id) ||
                            completedIds.contains(puzzle.id) ||
                            completedIds.contains(levels.getOrNull(index - 1)?.id)

                    LevelItemCard(
                        puzzle = puzzle,
                        index = index + 1,
                        isCompleted = isCompleted,
                        isUnlocked = isUnlocked,
                        accentColor = diffColor,
                        onPlayLevel = {
                            viewModel.selectLevel(puzzle)
                        },
                        onUnlockWithAd = {
                            viewModel.unlockLevelWithRewardedAd(puzzle)
                        }
                    )
                }
            }

            // =========================================================================
            // 4. BANNIÈRE ADMOB EN BAS
            // =========================================================================
            AdMobBannerView(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 2.dp)
                    .testTag("admob_banner_level_select")
            )
        }
    }
}

@Composable
private fun LevelItemCard(
    puzzle: BibleWordSearchPuzzle,
    index: Int,
    isCompleted: Boolean,
    isUnlocked: Boolean,
    accentColor: Color,
    onPlayLevel: () -> Unit,
    onUnlockWithAd: () -> Unit
) {
    val cardBg = when {
        isCompleted -> Color(0xFF18150D)
        isUnlocked -> Color(0xFF13110A)
        else -> Color(0xFF0F0E0A)
    }

    val borderBrush = when {
        isCompleted -> GoldButtonGradient
        isUnlocked -> SolidColor(GoldBorder)
        else -> SolidColor(Color(0xFF2A261C))
    }

    GoldBorderCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("level_item_card_$index"),
        cornerRadius = 14.dp,
        borderWidth = if (isUnlocked) 1.3.dp else 0.9.dp,
        borderBrush = borderBrush,
        backgroundColor = cardBg,
        onClick = if (isUnlocked) onPlayLevel else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Numéro du niveau avec badge stylisé
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isUnlocked) Color(0xFF201B0E) else Color(0xFF16140E))
                        .border(1.dp, if (isUnlocked) GoldPrimary else Color(0xFF3B3629), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isUnlocked) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Verrouillé",
                            tint = GoldAmber.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text(
                            text = String.format("%02d", index),
                            color = if (isCompleted) GoldBright else GoldLight,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = puzzle.title,
                        color = if (isUnlocked) TextWhite else TextWhite.copy(alpha = 0.85f),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (isUnlocked) {
                            "${puzzle.words.size} mots • Mot Mystère : ${puzzle.mysteryKeyword.length} lettres"
                        } else {
                            "Niveau verrouillé • Regardez une vidéo pour débloquer"
                        },
                        color = if (isUnlocked) GoldLight else GoldAmber.copy(alpha = 0.8f),
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // =========================================================================
            // BOUTONS CONDITIONNELS : JOUER (ACCESSIBLE/RÉUSSI) vs DÉBLOQUER (PUB VIDÉO)
            // =========================================================================
            if (isUnlocked) {
                // Bouton Doré JOUER
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(GoldButtonGradient)
                        .clickable(onClick = onPlayLevel)
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                        .testTag("btn_play_level_$index"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Jouer",
                            tint = BlackCanvas,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = if (isCompleted) "REJOUER" else "JOUER",
                            color = BlackCanvas,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            } else {
                // Bouton Spécial Vidéo Récompensée AdMob (DÉBLOQUER / VOIR PUB)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(Color(0xFF8A5800), Color(0xFFC98A0C), Color(0xFF8A5800))
                            )
                        )
                        .border(1.dp, GoldBright, RoundedCornerShape(10.dp))
                        .clickable(onClick = onUnlockWithAd)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("btn_unlock_ad_level_$index"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Vidéo Récompensée",
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                        Column(horizontalAlignment = Alignment.Start) {
                            Text(
                                text = "DÉBLOQUER",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "VOIR PUB",
                                color = Color(0xFFFFE599),
                                fontSize = 7.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun difficultySpec(diff: DifficultyLevel): String {
    return when (diff) {
        DifficultyLevel.FACILE -> "12x12 (16 mots)"
        DifficultyLevel.INTERMEDIAIRE -> "14x14 (24 mots)"
        DifficultyLevel.EXPERT -> "15x15 (28 mots)"
    }
}
