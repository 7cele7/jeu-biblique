package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.BiblePuzzlesRepository
import com.example.model.ActiveModal
import com.example.model.DifficultyLevel
import com.example.ui.components.GoldBorderCard
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.GoldIconButton
import com.example.ui.components.GoldOutlinedButton
import com.example.ui.components.GoldPillBadge
import com.example.ui.components.ShimmeringGoldTitle
import com.example.ui.theme.BlackCanvas
import com.example.ui.theme.EasyCardBorderGradient
import com.example.ui.theme.EasyGreen
import com.example.ui.theme.EasyGreenDark
import com.example.ui.theme.ExpertCardBorderGradient
import com.example.ui.theme.ExpertRed
import com.example.ui.theme.ExpertRedDark
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldButtonGradient
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MediumCardBorderGradient
import com.example.ui.theme.MediumOrange
import com.example.ui.theme.MediumOrangeDark
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.GameUiState
import com.example.viewmodel.GameViewModel

@Composable
fun HomeScreen(
    uiState: GameUiState,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val dailyVerse = BiblePuzzlesRepository.dailyVerses[uiState.dailyVerseIndex % BiblePuzzlesRepository.dailyVerses.size]

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BlackCanvas)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        // STRICT SINGLE-PAGE NO-SCROLL LAYOUT with spaceEvenly to distribute vertical space harmoniously
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceEvenly,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // 1. EN-TÊTE : Badge 'Niv. X' à gauche, 3 icônes dorées à droite (Paramètres, Trophée, Boutique)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_header"),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Badge Niv. X
                GoldBorderCard(
                    cornerRadius = 20.dp,
                    borderWidth = 1.4.dp,
                    backgroundColor = Color(0xFF14120A),
                    onClick = { viewModel.openModal(ActiveModal.PROFILE) },
                    testTag = "badge_level"
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Niv. ${uiState.profile.level}",
                            color = GoldBright,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // 3 Icônes dorées : Paramètres, Trophée, Boutique
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GoldIconButton(
                        icon = Icons.Default.Settings,
                        contentDescription = "Paramètres",
                        onClick = { viewModel.openModal(ActiveModal.SETTINGS) },
                        testTag = "header_settings_btn"
                    )
                    GoldIconButton(
                        icon = Icons.Default.EmojiEvents,
                        contentDescription = "Trophées",
                        onClick = { viewModel.openModal(ActiveModal.TROPHIES) },
                        testTag = "header_trophies_btn",
                        badgeCount = uiState.trophies.count { it.unlocked }
                    )
                    GoldIconButton(
                        icon = Icons.Default.ShoppingBag,
                        contentDescription = "Boutique",
                        onClick = { viewModel.openModal(ActiveModal.SHOP) },
                        testTag = "header_shop_btn"
                    )
                }
            }

            // 2. BLOC LOGO : Icône de jeu dorée et bleue imposante et centrée
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_logo_block"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(118.dp)
                        .shadow(16.dp, RoundedCornerShape(24.dp), spotColor = GoldPrimary)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0xFF141108))
                        .border(2.dp, GoldBorder, RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.logos_hero_logo),
                        contentDescription = "LOGOS : Mots Mêlés et Mystères Bibliques",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            // 3. CARTE PROFIL : Nom du joueur, points, pièces ($) et étoiles en jaune or
            GoldBorderCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_profile_card"),
                cornerRadius = 16.dp,
                borderWidth = 1.2.dp,
                backgroundColor = Color(0xFF100F0A),
                onClick = { viewModel.openModal(ActiveModal.PROFILE) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Player Name with small avatar icon
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF221D0E))
                                .border(1.dp, GoldPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = uiState.profile.name,
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${uiState.profile.xp} PTS",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Coins ($) & Stars (⭐) in Yellow Gold
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Coins ($)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = "Pièces",
                                tint = GoldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${uiState.profile.coins} $",
                                color = GoldBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        // Stars (⭐)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Étoiles",
                                tint = GoldAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${uiState.profile.stars} ⭐",
                                color = GoldBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            // 4. CARTE 'REPRENDRE' : Bouton 'REPRENDRE' en jaune/or éclatant avec texte noir en gras
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(10.dp, RoundedCornerShape(16.dp), spotColor = GoldPrimary)
                    .clip(RoundedCornerShape(16.dp))
                    .background(GoldButtonGradient)
                    .border(1.5.dp, GoldBright, RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("home_resume_card")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "GRILLE EN COURS",
                            color = Color(0xFF422E00),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = uiState.currentPuzzle.title,
                            color = BlackCanvas,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Vibrant yellow/gold button with bold black text
                    GoldGradientButton(
                        text = "REPRENDRE",
                        onClick = { viewModel.resumeLastGame() },
                        icon = Icons.Default.PlayArrow,
                        fontSize = 13.sp,
                        height = 38.dp,
                        testTag = "btn_resume"
                    )
                }
            }

            // 5. CARTE 'PAROLE DU JOUR' : Citation biblique agrandie avec référence dorée et bordure fine
            GoldBorderCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_daily_verse_card"),
                cornerRadius = 14.dp,
                borderWidth = 1.dp,
                backgroundColor = Color(0xFF0D0C08),
                onClick = { viewModel.nextDailyVerse() }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "PAROLE DU JOUR",
                                color = GoldLight,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = dailyVerse.reference,
                                color = GoldBright,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Changer verset",
                                tint = GoldLight,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "« ${dailyVerse.verseText} »",
                        color = TextGold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        lineHeight = 16.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // 6. SÉLECTION DE NIVEAU : Cartes 'FACILE' (Vert), 'INTERMÉDIAIRE' (Orange/Or) et 'EXPERT' (Rouge/Or)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_difficulty_section"),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // FACILE (Vert & Or)
                DifficultyCard(
                    modifier = Modifier.weight(1f),
                    title = "FACILE",
                    badgeText = "12x12 • 16 Mots",
                    borderColor = EasyGreen,
                    glowColor = EasyGreenDark,
                    isLocked = false,
                    onPlay = { viewModel.selectDifficulty(DifficultyLevel.FACILE) },
                    testTag = "difficulty_facile"
                )

                // INTERMÉDIAIRE (Orange/Or)
                DifficultyCard(
                    modifier = Modifier.weight(1f),
                    title = "INTERMÉD.",
                    badgeText = "14x14 • 24 Mots",
                    borderColor = MediumOrange,
                    glowColor = MediumOrangeDark,
                    isLocked = false,
                    onPlay = { viewModel.selectDifficulty(DifficultyLevel.INTERMEDIAIRE) },
                    testTag = "difficulty_intermediaire"
                )

                // EXPERT (Rouge/Or)
                val expertLocked = uiState.profile.stars < 4
                DifficultyCard(
                    modifier = Modifier.weight(1f),
                    title = "EXPERT",
                    badgeText = "15x15 • 28 Mots",
                    borderColor = ExpertRed,
                    glowColor = ExpertRedDark,
                    isLocked = expertLocked,
                    onPlay = {
                        if (!expertLocked) viewModel.selectDifficulty(DifficultyLevel.EXPERT)
                        else viewModel.selectDifficulty(DifficultyLevel.EXPERT) // Allow testing directly
                    },
                    testTag = "difficulty_expert"
                )
            }

            // 7. NAVIGATION INFÉRIEURE : 3 boutons avec bordures dorées ('Profil', 'Boutique', 'Stats')
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_bottom_navigation"),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                NavBottomButton(
                    modifier = Modifier.weight(1f),
                    label = "Profil",
                    icon = Icons.Default.Person,
                    onClick = { viewModel.openModal(ActiveModal.PROFILE) },
                    testTag = "nav_profile_btn"
                )

                NavBottomButton(
                    modifier = Modifier.weight(1f),
                    label = "Boutique",
                    icon = Icons.Default.ShoppingBag,
                    onClick = { viewModel.openModal(ActiveModal.SHOP) },
                    testTag = "nav_shop_btn"
                )

                NavBottomButton(
                    modifier = Modifier.weight(1f),
                    label = "Stats",
                    icon = Icons.Default.BarChart,
                    onClick = { viewModel.openModal(ActiveModal.STATS) },
                    testTag = "nav_stats_btn"
                )
            }
        }
    }
}

@Composable
private fun DifficultyCard(
    modifier: Modifier = Modifier,
    title: String,
    badgeText: String,
    borderColor: Color,
    glowColor: Color,
    isLocked: Boolean,
    onPlay: () -> Unit,
    testTag: String
) {
    GoldBorderCard(
        modifier = modifier.testTag(testTag),
        cornerRadius = 14.dp,
        borderWidth = 1.2.dp,
        borderBrush = androidx.compose.ui.graphics.SolidColor(borderColor),
        backgroundColor = Color(0xFF0E0D09),
        onClick = onPlay
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = borderColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = badgeText,
                color = TextMuted,
                fontSize = 9.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (isLocked) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF201D14))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Bloqué",
                        tint = TextMuted,
                        modifier = Modifier.size(11.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "BLOQUÉ",
                        color = TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(borderColor.copy(alpha = 0.25f))
                        .border(0.8.dp, borderColor, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "JOUER",
                        color = GoldBright,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.8.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun NavBottomButton(
    modifier: Modifier = Modifier,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    GoldBorderCard(
        modifier = modifier.testTag(testTag),
        cornerRadius = 14.dp,
        borderWidth = 1.2.dp,
        backgroundColor = Color(0xFF12100A),
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = GoldPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                color = GoldLight,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}
