package com.example.ui.components

import android.widget.FrameLayout
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.TextMuted

@Composable
fun AdMobBannerView(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0F0E0B))
            .border(0.8.dp, GoldBorderSubtle, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Embed real AndroidView container for AdMob Banner (AdView)
        AndroidView(
            modifier = Modifier.fillMaxWidth().height(50.dp),
            factory = { context ->
                FrameLayout(context).apply {
                    // FrameLayout configured ready to attach com.google.android.gms.ads.AdView
                    val placeholderText = TextView(context).apply {
                        text = "PUBLICITÉ ADMOB • BANNIÈRE SPONSORISÉE"
                        textSize = 10f
                        setTextColor(android.graphics.Color.parseColor("#B39855"))
                        gravity = android.view.Gravity.CENTER
                    }
                    addView(
                        placeholderText,
                        FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT
                        )
                    )
                }
            }
        )
    }
}
