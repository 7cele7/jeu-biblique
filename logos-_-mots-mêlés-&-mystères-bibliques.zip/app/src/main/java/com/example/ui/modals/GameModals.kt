package com.example.ui.modals

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.ActiveModal
import com.example.model.Trophy
import com.example.ui.components.GoldBorderCard
import com.example.ui.components.GoldGradientButton
import com.example.ui.components.GoldOutlinedButton
import com.example.ui.components.ShimmeringGoldTitle
import com.example.ui.theme.BlackCanvas
import com.example.ui.theme.CardDarkBg
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldButtonGradient
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldHorizontalGradient
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.GameUiState
import com.example.viewmodel.GameViewModel

@Composable
fun GameModalsHost(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    when (uiState.activeModal) {
        ActiveModal.PROFILE -> ProfileDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.SHOP -> ShopDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.STATS -> StatsDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.TROPHIES -> TrophiesDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.SETTINGS -> SettingsDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.REWARDED_VIDEO -> RewardedVideoDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.MYSTERY_REVEAL -> MysteryKeywordDialog(uiState = uiState, viewModel = viewModel)
        ActiveModal.NONE -> Unit
    }
}

// 1. Profile Modal
@Composable
fun ProfileDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    var isEditingName by remember { mutableStateOf(false) }
    var editedName by remember { mutableStateOf(uiState.profile.name) }

    Dialog(onDismissRequest = { viewModel.closeModal() }) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PROFIL DU DISCIPLE",
                        color = GoldBright,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = { viewModel.closeModal() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Avatar with glowing gold ring
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1E1A0E))
                        .border(2.dp, GoldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(42.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (isEditingName) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = editedName,
                            onValueChange = { editedName = it },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = GoldBorderSubtle,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = {
                            viewModel.updatePlayerName(editedName)
                            isEditingName = false
                        }) {
                            Icon(Icons.Default.Check, contentDescription = "Valider", tint = GoldPrimary)
                        }
                    }
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { isEditingName = true }
                    ) {
                        Text(
                            text = uiState.profile.name,
                            color = TextWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Modifier",
                            tint = GoldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Text(
                    text = "Rang : Scribe des Saintes Écritures",
                    color = GoldLight,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Serif
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Stats Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    ProfileStatItem(label = "Niveau", value = "${uiState.profile.level}", icon = Icons.Default.Star)
                    ProfileStatItem(label = "Pièces", value = "${uiState.profile.coins} $", icon = Icons.Default.MonetizationOn)
                    ProfileStatItem(label = "Étoiles", value = "${uiState.profile.stars} ⭐", icon = Icons.Default.EmojiEvents)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // XP Progress bar
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Expérience (XP)", color = TextMuted, fontSize = 12.sp)
                        Text("${uiState.profile.xp} / 2000 XP", color = GoldBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (uiState.profile.xp % 1000) / 1000f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = GoldPrimary,
                        trackColor = Color(0xFF24221A)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                GoldGradientButton(
                    text = "FERMER",
                    onClick = { viewModel.closeModal() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun ProfileStatItem(
    label: String,
    value: String,
    icon: ImageVector
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = GoldBright, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text = label, color = TextMuted, fontSize = 11.sp)
    }
}

// 2. Shop Modal ($ Coins, Jokers, Rewarded Video Ad)
@Composable
fun ShopDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    Dialog(onDismissRequest = { viewModel.closeModal() }) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = GoldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BOUTIQUE SACRÉE",
                            color = GoldBright,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    IconButton(onClick = { viewModel.closeModal() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // AdMob Rewarded Video Banner for free coins
                GoldBorderCard(
                    modifier = Modifier.fillMaxWidth(),
                    cornerRadius = 14.dp,
                    backgroundColor = Color(0xFF19170F),
                    onClick = { viewModel.startRewardedVideo(null) },
                    testTag = "shop_watch_ad_btn"
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Videocam, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Pièces Gratuites (Pub AdMob)", color = GoldBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("+50 Pièces d'Or immédiates", color = TextMuted, fontSize = 11.sp)
                            }
                        }
                        GoldOutlinedButton(
                            text = "VOIR",
                            onClick = { viewModel.startRewardedVideo(null) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("PACKS D'OFFRANDES", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))

                ShopPackItem(
                    title = "Bourse de David",
                    coins = "+200 $",
                    stars = "+2 ⭐",
                    price = "Gratuit (Découverte)",
                    onBuy = { viewModel.buyShopPack(200, 2) }
                )

                Spacer(modifier = Modifier.height(8.dp))

                ShopPackItem(
                    title = "Trésor du Temple",
                    coins = "+600 $",
                    stars = "+5 ⭐",
                    price = "Pack Bénédiction",
                    onBuy = { viewModel.buyShopPack(600, 5) }
                )

                Spacer(modifier = Modifier.height(8.dp))

                ShopPackItem(
                    title = "Coffre de Salomon",
                    coins = "+1500 $",
                    stars = "+12 ⭐",
                    price = "Pack Roi",
                    onBuy = { viewModel.buyShopPack(1500, 12) }
                )
            }
        }
    }
}

@Composable
private fun ShopPackItem(
    title: String,
    coins: String,
    stars: String,
    price: String,
    onBuy: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF14120D))
            .border(1.dp, GoldBorderSubtle, RoundedCornerShape(12.dp))
            .clickable { onBuy() }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(title, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(coins, color = GoldBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("•  $stars", color = GoldLight, fontSize = 12.sp)
                }
            }
            GoldGradientButton(
                text = price,
                onClick = onBuy,
                fontSize = 11.sp,
                height = 36.dp
            )
        }
    }
}

// 3. Stats & Trophies Modal
@Composable
fun StatsDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    Dialog(onDismissRequest = { viewModel.closeModal() }) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STATISTIQUES SACRÉES",
                        color = GoldBright,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = { viewModel.closeModal() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                StatRow("Grilles Complétées", "${uiState.profile.puzzlesCompleted}")
                StatRow("Mots Bibliques Découverts", "${uiState.profile.wordsFound}")
                StatRow("Mots-Clés Mystères Déchiffrés", "${uiState.profile.mysterySolvedCount}")
                StatRow("Jokers & Révélations Utilisés", "${uiState.profile.jokersUsed}")
                StatRow("Série de Méditation Quotidienne", "${uiState.profile.currentStreakDays} jours")
                StatRow("Étoiles Célestes Cumulées", "${uiState.profile.stars} ⭐")

                Spacer(modifier = Modifier.height(20.dp))

                GoldGradientButton(
                    text = "RETOUR",
                    onClick = { viewModel.closeModal() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .border(
                width = 0.5.dp,
                color = Color(0xFF221F16),
                shape = RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextMuted, fontSize = 13.sp)
        Text(value, color = GoldBright, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

// 4. Trophies Modal
@Composable
fun TrophiesDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    Dialog(onDismissRequest = { viewModel.closeModal() }) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TROPHÉES & RÉALISATIONS",
                        color = GoldBright,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = { viewModel.closeModal() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyColumn(modifier = Modifier.height(300.dp)) {
                    items(uiState.trophies) { trophy ->
                        TrophyItemRow(trophy = trophy)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                GoldGradientButton(
                    text = "FERMER",
                    onClick = { viewModel.closeModal() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun TrophyItemRow(trophy: Trophy) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (trophy.unlocked) Color(0xFF1E1A0E) else Color(0xFF121212))
            .border(
                1.dp,
                if (trophy.unlocked) GoldBorder else GoldBorderSubtle.copy(alpha = 0.4f),
                RoundedCornerShape(12.dp)
            )
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (trophy.unlocked) Icons.Default.EmojiEvents else Icons.Default.Lock,
                contentDescription = null,
                tint = if (trophy.unlocked) GoldPrimary else TextMuted,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = trophy.title,
                    color = if (trophy.unlocked) GoldBright else TextMuted,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = trophy.description,
                    color = if (trophy.unlocked) TextWhite else TextMuted,
                    fontSize = 11.sp
                )
            }
            if (trophy.unlocked) {
                Text(
                    text = "+${trophy.rewardCoins} $",
                    color = GoldAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// 5. Settings Modal
@Composable
fun SettingsDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    Dialog(onDismissRequest = { viewModel.closeModal() }) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PARAMÈTRES",
                        color = GoldBright,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    IconButton(onClick = { viewModel.closeModal() }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Effets Sonores & Musique", color = TextWhite, fontSize = 14.sp)
                    Switch(
                        checked = uiState.profile.soundEnabled,
                        onCheckedChange = { viewModel.toggleSound() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BlackCanvas,
                            checkedTrackColor = GoldPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Vibrations Haptiques", color = TextWhite, fontSize = 14.sp)
                    Switch(
                        checked = uiState.profile.hapticEnabled,
                        onCheckedChange = { viewModel.toggleHaptic() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BlackCanvas,
                            checkedTrackColor = GoldPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Version Biblique : Louis Segond (LSG 1910)", color = TextMuted, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(20.dp))

                GoldGradientButton(
                    text = "VALIDER",
                    onClick = { viewModel.closeModal() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

// 6. Rewarded Video Modal (AdMob Rewarded Video Simulation)
@Composable
fun RewardedVideoDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    Dialog(onDismissRequest = { /* Cannot dismiss during rewarded video */ }) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            cornerRadius = 20.dp,
            backgroundColor = Color(0xFF0B0B0B)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Ad Badge Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(GoldAmber)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("ANNONCE ADMOB", color = BlackCanvas, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                    Text(
                        text = "Récompense dans ${uiState.rewardedVideoSecondsLeft}s",
                        color = GoldBright,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Animated Video Screen
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1F1A0D))
                        .border(2.dp, GoldPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { (5 - uiState.rewardedVideoSecondsLeft) / 5f },
                        modifier = Modifier.fillMaxSize(),
                        color = GoldPrimary,
                        strokeWidth = 4.dp
                    )
                    Icon(
                        imageVector = Icons.Default.PlayCircleFilled,
                        contentDescription = null,
                        tint = GoldBright,
                        modifier = Modifier.size(60.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Visionnage de la vidéo sponsor...",
                    color = TextWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Votre joker ou vos +50 pièces d'or seront crédités automatiquement à la fin du décompte.",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                LinearProgressIndicator(
                    progress = { (5 - uiState.rewardedVideoSecondsLeft) / 5f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = GoldPrimary,
                    trackColor = Color(0xFF24221A)
                )
            }
        }
    }
}

// 7. Mystery Keyword Modal (Revelation of unused letters forming the sacred keyword)
@Composable
fun MysteryKeywordDialog(
    uiState: GameUiState,
    viewModel: GameViewModel
) {
    val puzzle = uiState.currentPuzzle
    val mysteryWord = puzzle.mysteryKeyword

    Dialog(
        onDismissRequest = { if (uiState.mysterySolved) viewModel.closeModal() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        GoldBorderCard(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 10.dp),
            cornerRadius = 24.dp,
            backgroundColor = Color(0xFF0A0905)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (uiState.mysterySolved) {
                    // VICTORY SCREEN
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(56.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ShimmeringGoldTitle(text = "RÉVÉLATION DIVINE !", fontSize = 24.sp)

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Mot-Clé Mystère déchiffré :",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF231E0D))
                            .border(1.5.dp, GoldPrimary, RoundedCornerShape(12.dp))
                            .padding(horizontal = 20.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = mysteryWord,
                            color = GoldBright,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 4.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val graceWord = puzzle.graceWord
                    if (graceWord != null && !uiState.isGraceWordRevealed) {
                        // Action to reveal Parole de Grâce
                        GoldBorderCard(
                            modifier = Modifier.fillMaxWidth(),
                            cornerRadius = 14.dp,
                            backgroundColor = Color(0xFF19160D),
                            borderWidth = 1.2.dp
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = GoldAmber,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Une bénédiction est rattachée à ce niveau",
                                    color = TextWhite,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                GoldGradientButton(
                                    text = "RECEVOIR MA PAROLE DE GRÂCE",
                                    onClick = { viewModel.revealGraceWord() },
                                    modifier = Modifier.fillMaxWidth().testTag("btn_receive_grace_word")
                                )
                            }
                        }
                    } else {
                        // Display Grace Word Card
                        val displayedVerse = graceWord?.verse ?: puzzle.mysteryVerseText
                        val displayedRef = graceWord?.reference ?: puzzle.mysteryVerseReference
                        val displayedMessage = graceWord?.message ?: "Que la paix et la grâce de notre Seigneur t'accompagnent."

                        GoldBorderCard(
                            modifier = Modifier.fillMaxWidth().testTag("grace_word_card"),
                            cornerRadius = 14.dp,
                            backgroundColor = Color(0xFF14130F),
                            borderWidth = 1.4.dp
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = GoldBright,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "PAROLE DE GRÂCE",
                                        color = GoldBright,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = "« $displayedVerse »",
                                    color = TextGold,
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Serif,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                    lineHeight = 18.sp
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = "— $displayedRef",
                                    color = GoldLight,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.End)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF221C0E))
                                        .padding(8.dp)
                                    ) {
                                    Text(
                                        text = displayedMessage,
                                        color = TextWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        lineHeight = 15.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Text("+${puzzle.rewardCoins} $ Pièces", color = GoldBright, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("+${puzzle.rewardStars} ⭐ Étoile", color = GoldAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("+250 XP", color = GoldLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GoldOutlinedButton(
                            text = "MENU ACCUEIL",
                            onClick = {
                                viewModel.closeModal()
                                viewModel.openScreen(com.example.model.ActiveScreen.HOME)
                            },
                            modifier = Modifier.weight(1f).testTag("btn_victory_home")
                        )
                        GoldGradientButton(
                            text = "NIVEAU SUIVANT",
                            onClick = {
                                viewModel.loadNextLevel()
                            },
                            modifier = Modifier.weight(1.2f).testTag("btn_next_level")
                        )
                    }
                } else {
                    // DECRYPTION INTERACTIVE PHASE
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MOT-CLÉ MYSTÈRE",
                            color = GoldBright,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        IconButton(onClick = { viewModel.closeModal() }, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Fermer", tint = GoldLight)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val letterBank = remember(puzzle.id) { puzzle.getEffectiveLetterBank() }
                    val selectedBankIndices = uiState.mysterySelectedBankIndices

                    Text(
                        text = "Trouvez le mot biblique de ${mysteryWord.length} lettres parmi les ${letterBank.size} lettres d'or restantes :",
                        color = TextWhite,
                        fontSize = 11.5.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Indice
                    Text(
                        text = "Indice : ${puzzle.mysteryHint}",
                        color = GoldLight,
                        fontSize = 11.5.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Guess Slot Boxes - Calcul précis et responsive pour ne jamais déborder
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val availableWidth = maxWidth
                        val letterCount = mysteryWord.length.coerceAtLeast(1)
                        // Calcul dynamique de la largeur de chaque case
                        val slotWidth = ((availableWidth - ((letterCount + 1) * 4).dp) / letterCount).coerceIn(20.dp, 34.dp)
                        val slotHeight = slotWidth * 1.2f

                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            for (i in 0 until mysteryWord.length) {
                                val isFilled = i < selectedBankIndices.size
                                val char = if (isFilled) letterBank.getOrNull(selectedBankIndices[i]) else null
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 1.5.dp)
                                        .size(slotWidth, slotHeight)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (char != null) Color(0xFF2E2713) else Color(0xFF171510))
                                        .border(1.2.dp, if (char != null) GoldPrimary else GoldBorderSubtle, RoundedCornerShape(6.dp))
                                        .clickable(enabled = isFilled) {
                                            viewModel.removeMysteryLetterAtSlot(i)
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = char?.toString() ?: "_",
                                        color = if (char != null) GoldBright else TextMuted,
                                        fontSize = if (letterCount > 8) 12.sp else 15.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Touchez une case pour retirer une lettre",
                        color = TextMuted,
                        fontSize = 9.5.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Banque de lettres (avec lettres distractrices) en 2 rangées équilibrées
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val rowCount = if (letterBank.size > 5) 2 else 1
                        val itemsPerRow = (letterBank.size + rowCount - 1) / rowCount
                        letterBank.chunked(itemsPerRow).forEachIndexed { rowIndex, rowChars ->
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                rowChars.forEachIndexed { colIndex, char ->
                                    val bankIndex = rowIndex * itemsPerRow + colIndex
                                    val isUsed = selectedBankIndices.contains(bankIndex)
                                    Box(
                                        modifier = Modifier
                                            .padding(horizontal = 3.dp)
                                            .size(38.dp, 38.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isUsed) Color(0xFF13110C) else Color(0xFF262012))
                                            .border(
                                                1.2.dp,
                                                if (isUsed) Color(0xFF2A2415) else GoldBorder,
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable(enabled = !isUsed && selectedBankIndices.size < mysteryWord.length) {
                                                viewModel.selectMysteryBankLetter(bankIndex)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "$char",
                                            color = if (isUsed) Color(0xFF554D38) else GoldBright,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GoldOutlinedButton(
                            text = "EFFACER",
                            onClick = { viewModel.clearMysteryGuess() },
                            modifier = Modifier.weight(1f)
                        )
                        GoldGradientButton(
                            text = "DÉVOILER",
                            onClick = { viewModel.validateMysteryWord() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
