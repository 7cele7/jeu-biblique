package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Pure Pitch Black Theme Canvas
val BlackCanvas = Color(0xFF000000)
val DarkSurface = Color(0xFF0A0A0A)
val CardDarkBg = Color(0xFF121212)
val CardElevatedBg = Color(0xFF1A1813)
val CardSubtleBg = Color(0xFF14130F)

// Rich Metallic Golds & Yellows
val GoldBright = Color(0xFFFFF176)
val GoldLight = Color(0xFFFFE082)
val GoldPrimary = Color(0xFFFFD700)
val GoldAmber = Color(0xFFFFA000)
val GoldDark = Color(0xFFB8860B)
val GoldBronze = Color(0xFF855800)
val GoldMuted = Color(0xFF5C430B)
val GoldBorder = Color(0xFFD4AF37)
val GoldBorderSubtle = Color(0xFF4A3E1E)
val GoldShimmerStart = Color(0xFFFFEDB3)
val GoldShimmerEnd = Color(0xFFC59B27)

// Difficulty Theme Accents
val EasyGreen = Color(0xFF10B981)
val EasyGreenDark = Color(0xFF064E3B)
val MediumOrange = Color(0xFFF59E0B)
val MediumOrangeDark = Color(0xFF78350F)
val ExpertRed = Color(0xFFEF4444)
val ExpertRedDark = Color(0xFF7F1D1D)

// UI Utility Colors
val TextWhite = Color(0xFFFBFBFB)
val TextGold = Color(0xFFFFE885)
val TextMuted = Color(0xFF9E9E9E)
val OverlayBlack = Color(0xCC000000)

// Word highlight colors on game grid
val WordColor1 = Color(0xFFFFD700) // Gold
val WordColor2 = Color(0xFF38BDF8) // Sky Blue
val WordColor3 = Color(0xFF34D399) // Emerald
val WordColor4 = Color(0xFFF472B6) // Rose
val WordColor5 = Color(0xFFA78BFA) // Violet
val WordColor6 = Color(0xFFFB923C) // Orange
val WordColor7 = Color(0xFF4ADE80) // Light Green
val WordColor8 = Color(0xFFE879F9) // Fuchsia

// Reusable Rich Brushes
val GoldHorizontalGradient = Brush.horizontalGradient(
    colors = listOf(GoldLight, GoldPrimary, GoldAmber, GoldDark)
)

val GoldVerticalGradient = Brush.verticalGradient(
    colors = listOf(GoldBright, GoldPrimary, GoldAmber)
)

val GoldButtonGradient = Brush.verticalGradient(
    colors = listOf(Color(0xFFFFF59D), Color(0xFFFFD54F), Color(0xFFFFB300))
)

val GoldCardBorderGradient = Brush.linearGradient(
    colors = listOf(GoldLight, GoldDark, GoldPrimary, GoldBorderSubtle)
)

val EasyCardBorderGradient = Brush.linearGradient(
    colors = listOf(EasyGreen, GoldPrimary, EasyGreenDark)
)

val MediumCardBorderGradient = Brush.linearGradient(
    colors = listOf(MediumOrange, GoldPrimary, MediumOrangeDark)
)

val ExpertCardBorderGradient = Brush.linearGradient(
    colors = listOf(ExpertRed, GoldPrimary, ExpertRedDark)
)
