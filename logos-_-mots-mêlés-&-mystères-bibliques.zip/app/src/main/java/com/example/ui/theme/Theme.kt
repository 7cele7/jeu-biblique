package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val LogosColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = BlackCanvas,
    primaryContainer = GoldMuted,
    onPrimaryContainer = GoldBright,
    secondary = GoldAmber,
    onSecondary = BlackCanvas,
    secondaryContainer = GoldBronze,
    onSecondaryContainer = GoldLight,
    tertiary = GoldLight,
    onTertiary = BlackCanvas,
    background = BlackCanvas,
    onBackground = TextWhite,
    surface = DarkSurface,
    onSurface = TextWhite,
    surfaceVariant = CardDarkBg,
    onSurfaceVariant = TextGold,
    outline = GoldBorder,
    outlineVariant = GoldBorderSubtle
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LogosColorScheme,
        typography = Typography,
        content = content
    )
}
