package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveModal
import com.example.model.ActiveScreen
import com.example.model.BibleWordSearchPuzzle
import com.example.model.CellCoordinate
import com.example.model.DifficultyLevel
import com.example.model.WordPlacement
import com.example.ui.components.AdMobBannerView
import com.example.ui.components.GoldBorderCard
import com.example.ui.theme.BlackCanvas
import com.example.ui.theme.EasyGreen
import com.example.ui.theme.ExpertRed
import com.example.ui.theme.GoldAmber
import com.example.ui.theme.GoldBorder
import com.example.ui.theme.GoldBorderSubtle
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldButtonGradient
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.MediumOrange
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WordColor1
import com.example.ui.theme.WordColor2
import com.example.ui.theme.WordColor3
import com.example.ui.theme.WordColor4
import com.example.ui.theme.WordColor5
import com.example.ui.theme.WordColor6
import com.example.ui.theme.WordColor7
import com.example.ui.theme.WordColor8
import com.example.viewmodel.GameUiState
import com.example.viewmodel.GameViewModel

private val wordColors = listOf(
    WordColor1, WordColor2, WordColor3, WordColor4,
    WordColor5, WordColor6, WordColor7, WordColor8
)

@Composable
fun GameScreen(
    uiState: GameUiState,
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val puzzle = uiState.currentPuzzle
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BlackCanvas)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            // =========================================================================
            // 1. EN-TÊTE FIXE (Bouton Retour, Titre & Niveau, Chronomètre, Pièces $)
            // =========================================================================
            GameHeaderTopBar(
                puzzleTitle = puzzle.title,
                levelNumber = puzzle.levelNumber,
                difficulty = puzzle.difficulty,
                elapsedSeconds = uiState.elapsedSeconds,
                coins = uiState.profile.coins,
                onBack = { viewModel.openScreen(ActiveScreen.LEVEL_SELECT) },
                onOpenShop = { viewModel.openModal(ActiveModal.SHOP) }
            )

            Spacer(modifier = Modifier.height(4.dp))

            // =========================================================================
            // 2. GRILLE DE LETTRES STRICTEMENT FIXE (Centre supérieur, Anti-Scroll)
            // =========================================================================
            FixedLetterSearchGrid(
                puzzle = puzzle,
                foundWordIds = uiState.foundWordIds,
                currentSelection = uiState.currentSelection,
                highlightedHintCells = uiState.highlightedHintCells,
                eliminatedDistractorCells = uiState.eliminatedDistractorCells,
                mysteryPhaseUnlocked = uiState.mysteryPhaseUnlocked,
                onDragStart = { r, c -> viewModel.onCellDragStart(r, c) },
                onDragMove = { r, c -> viewModel.onCellDragMove(r, c) },
                onDragEnd = { viewModel.onCellDragEnd() }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // =========================================================================
            // 3. BARRE D'ACTIONS COMPACTE (Jokers + Indicateur Mot-Clé Mystère)
            // =========================================================================
            GameActionBar(
                difficulty = puzzle.difficulty,
                mysteryPhaseUnlocked = uiState.mysteryPhaseUnlocked,
                foundCount = uiState.foundWordIds.size,
                totalCount = puzzle.words.size,
                onRevealFirstLetter = { viewModel.useJokerRevealFirstLetter() },
                onEliminateFalseLetters = { viewModel.useJokerEliminateFalseLetters() },
                onOpenMysteryModal = {
                    if (uiState.mysteryPhaseUnlocked) {
                        viewModel.openModal(ActiveModal.MYSTERY_REVEAL)
                    } else {
                        viewModel.showToast("Trouvez tous les mots (${uiState.foundWordIds.size}/${puzzle.words.size}) pour débloquer le Mot Mystère !")
                    }
                }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // =========================================================================
            // 4. SECTION DES MOTS À TROUVER (Priorité d'affichage, direct et bien visible)
            // =========================================================================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                WordsToFindSection(
                    words = puzzle.words,
                    foundWordIds = uiState.foundWordIds,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // =========================================================================
            // 5. BANNIÈRE ADMOB ANCRÉE EN BAS (Emplacement AndroidView AdMob)
            // =========================================================================
            AdMobBannerView(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 2.dp)
                    .testTag("admob_banner_bottom")
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

// =========================================================================
// 1. EN-TÊTE FIXE DU JEU
// =========================================================================
@Composable
private fun GameHeaderTopBar(
    puzzleTitle: String,
    levelNumber: Int,
    difficulty: DifficultyLevel,
    elapsedSeconds: Int,
    coins: Int,
    onBack: () -> Unit,
    onOpenShop: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("game_top_bar"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF14120A))
                    .border(1.2.dp, GoldBorder, CircleShape)
                    .testTag("btn_game_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Retour",
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column {
                Text(
                    text = puzzleTitle,
                    color = GoldBright,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
                val diffColor = when (difficulty) {
                    DifficultyLevel.FACILE -> EasyGreen
                    DifficultyLevel.INTERMEDIAIRE -> MediumOrange
                    DifficultyLevel.EXPERT -> ExpertRed
                }
                Text(
                    text = "NIVEAU $levelNumber • ${difficulty.displayName.uppercase()}",
                    color = diffColor,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val minutes = elapsedSeconds / 60
            val seconds = elapsedSeconds % 60
            val timeText = String.format("%02d:%02d", minutes, seconds)

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF121008))
                    .border(1.dp, GoldBorderSubtle, RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("game_timer"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = "Chronomètre",
                    tint = GoldPrimary,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = timeText,
                    color = TextGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF16140A))
                    .border(1.2.dp, GoldBorder, RoundedCornerShape(12.dp))
                    .clickable { onOpenShop() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("game_coins_badge"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MonetizationOn,
                    contentDescription = "Pièces",
                    tint = GoldPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "$coins $",
                    color = GoldBright,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

// =========================================================================
// 2. GRILLE DE LETTRES FIXE & SÉLECTION TACTILE
// =========================================================================
@Composable
private fun FixedLetterSearchGrid(
    puzzle: BibleWordSearchPuzzle,
    foundWordIds: Set<String>,
    currentSelection: List<CellCoordinate>,
    highlightedHintCells: Set<CellCoordinate>,
    eliminatedDistractorCells: Set<CellCoordinate>,
    mysteryPhaseUnlocked: Boolean,
    onDragStart: (Int, Int) -> Unit,
    onDragMove: (Int, Int) -> Unit,
    onDragEnd: () -> Unit
) {
    val gridSize = puzzle.gridSize
    val foundWordPlacementMap = remember(foundWordIds, puzzle) {
        val map = mutableMapOf<CellCoordinate, Int>()
        puzzle.words.forEachIndexed { _, wordPlacement ->
            if (foundWordIds.contains(wordPlacement.id)) {
                val line = computeLineCoordinates(
                    wordPlacement.startRow,
                    wordPlacement.startCol,
                    wordPlacement.endRow,
                    wordPlacement.endCol
                )
                line.forEach { coord -> map[coord] = wordPlacement.colorIndex }
            }
        }
        map
    }

    GoldBorderCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("fixed_word_grid"),
        cornerRadius = 16.dp,
        borderWidth = 1.4.dp,
        backgroundColor = Color(0xFF0A0906)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(gridSize) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                val col = (offset.x / (size.width / gridSize)).toInt().coerceIn(0, gridSize - 1)
                                val row = (offset.y / (size.height / gridSize)).toInt().coerceIn(0, gridSize - 1)
                                onDragStart(row, col)
                            },
                            onDrag = { change, _ ->
                                val offset = change.position
                                val col = (offset.x / (size.width / gridSize)).toInt().coerceIn(0, gridSize - 1)
                                val row = (offset.y / (size.height / gridSize)).toInt().coerceIn(0, gridSize - 1)
                                onDragMove(row, col)
                            },
                            onDragEnd = { onDragEnd() },
                            onDragCancel = { onDragEnd() }
                        )
                    }
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    for (r in 0 until gridSize) {
                        Row(modifier = Modifier.fillMaxWidth().weight(1f)) {
                            for (c in 0 until gridSize) {
                                val coord = CellCoordinate(r, c)
                                val isSelected = currentSelection.contains(coord)
                                val foundColorIndex = foundWordPlacementMap[coord]
                                val isHinted = highlightedHintCells.contains(coord)
                                val isEliminated = eliminatedDistractorCells.contains(coord)
                                val isUnusedMysteryLetter = mysteryPhaseUnlocked && foundColorIndex == null

                                GridLetterCell(
                                    char = if (r < puzzle.grid.size && c < puzzle.grid[r].size) puzzle.grid[r][c] else ' ',
                                    isSelected = isSelected,
                                    foundColor = foundColorIndex?.let { wordColors[it % wordColors.size] },
                                    isHinted = isHinted,
                                    isEliminated = isEliminated,
                                    isUnusedMysteryLetter = isUnusedMysteryLetter,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GridLetterCell(
    char: Char,
    isSelected: Boolean,
    foundColor: Color?,
    isHinted: Boolean,
    isEliminated: Boolean,
    isUnusedMysteryLetter: Boolean,
    modifier: Modifier = Modifier
) {
    val backgroundColor = when {
        isSelected -> GoldPrimary.copy(alpha = 0.60f)
        foundColor != null -> foundColor.copy(alpha = 0.45f)
        isHinted -> GoldBright.copy(alpha = 0.50f)
        isUnusedMysteryLetter -> GoldAmber.copy(alpha = 0.40f)
        isEliminated -> Color(0xFF0E0D0B).copy(alpha = 0.3f)
        else -> Color.Transparent
    }

    val textColor = when {
        isSelected -> BlackCanvas
        foundColor != null -> GoldBright
        isHinted -> GoldBright
        isUnusedMysteryLetter -> GoldBright
        isEliminated -> Color(0xFF333026)
        else -> TextGold
    }

    val borderModifier = when {
        isSelected -> Modifier.border(1.2.dp, GoldBright, RoundedCornerShape(6.dp))
        isHinted -> Modifier.border(1.2.dp, GoldPrimary, RoundedCornerShape(6.dp))
        isUnusedMysteryLetter -> Modifier.border(1.2.dp, GoldAmber, RoundedCornerShape(6.dp))
        !isEliminated -> Modifier.border(0.5.dp, Color(0xFF26200F), RoundedCornerShape(6.dp))
        else -> Modifier
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(0.8.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(backgroundColor)
            .then(borderModifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (isEliminated) "•" else "$char",
            color = textColor,
            fontSize = if (isEliminated) 9.sp else 12.sp,
            fontWeight = if (isSelected || foundColor != null || isHinted || isUnusedMysteryLetter) FontWeight.Black else FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center
        )
    }
}

// =========================================================================
// 3. BARRE D'ACTIONS COMPACTE DU JEU (Jokers + Statut Mot Mystère)
// =========================================================================
@Composable
private fun GameActionBar(
    difficulty: DifficultyLevel,
    mysteryPhaseUnlocked: Boolean,
    foundCount: Int,
    totalCount: Int,
    onRevealFirstLetter: () -> Unit,
    onEliminateFalseLetters: () -> Unit,
    onOpenMysteryModal: () -> Unit
) {
    val (costLabel1, costLabel2, accentColor) = when (difficulty) {
        DifficultyLevel.FACILE -> Triple("Gratuit", "Gratuit", EasyGreen)
        DifficultyLevel.INTERMEDIAIRE -> Triple("25 $", "25 $", MediumOrange)
        DifficultyLevel.EXPERT -> Triple("50 $ / Pub", "50 $ / Pub", ExpertRed)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("game_action_bar"),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Joker 1: 1ère Lettre
        ActionJokerButton(
            title = "1ÈRE LETTRE",
            badgeText = costLabel1,
            icon = Icons.Default.Lightbulb,
            accentColor = accentColor,
            modifier = Modifier.weight(1f),
            onClick = onRevealFirstLetter,
            testTag = "btn_joker_first_letter"
        )

        // Joker 2: Éliminer Parasites
        ActionJokerButton(
            title = "ÉLIMINER",
            badgeText = costLabel2,
            icon = Icons.Default.CheckCircle,
            accentColor = accentColor,
            modifier = Modifier.weight(1f),
            onClick = onEliminateFalseLetters,
            testTag = "btn_joker_eliminate_letters"
        )

        // Badge Mot Mystère (Indicateur + Déclencheur)
        Box(
            modifier = Modifier
                .weight(1.3f)
                .clip(RoundedCornerShape(10.dp))
                .background(if (mysteryPhaseUnlocked) GoldButtonGradient else SolidColor(Color(0xFF16140D)))
                .border(
                    1.2.dp,
                    if (mysteryPhaseUnlocked) GoldBright else GoldBorderSubtle,
                    RoundedCornerShape(10.dp)
                )
                .clickable(onClick = onOpenMysteryModal)
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .testTag("btn_mystery_keyword_action"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = if (mysteryPhaseUnlocked) Icons.Default.AutoAwesome else Icons.Default.Lock,
                    contentDescription = null,
                    tint = if (mysteryPhaseUnlocked) BlackCanvas else GoldPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (mysteryPhaseUnlocked) "MOT MYSTÈRE" else "MOT MYSTÈRE",
                        color = if (mysteryPhaseUnlocked) BlackCanvas else GoldLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.4.sp
                    )
                    Text(
                        text = if (mysteryPhaseUnlocked) "✨ DÉBLOQUÉ !" else "$foundCount / $totalCount trouvés",
                        color = if (mysteryPhaseUnlocked) Color(0xFF332000) else TextMuted,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionJokerButton(
    title: String,
    badgeText: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF14120A))
            .border(1.dp, GoldBorderSubtle, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = title,
                    color = GoldBright,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.2.sp,
                    maxLines = 1
                )
                Text(
                    text = badgeText,
                    color = accentColor,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )
            }
        }
    }
}

// =========================================================================
// 4. SECTION MOTS À TROUVER COMPACTE (SUR 2 COLONNES AVEC DÉFILEMENT FLUIDE)
// =========================================================================
@Composable
private fun WordsToFindSection(
    words: List<WordPlacement>,
    foundWordIds: Set<String>,
    modifier: Modifier = Modifier
) {
    GoldBorderCard(
        modifier = modifier.testTag("words_to_find_container"),
        cornerRadius = 14.dp,
        borderWidth = 1.dp,
        borderBrush = SolidColor(GoldBorderSubtle),
        backgroundColor = Color(0xFF100E08)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = GoldAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "MOTS À TROUVER",
                        color = GoldBright,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.8.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF221C0E))
                        .border(0.8.dp, GoldBorderSubtle, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${foundWordIds.size} / ${words.size} trouvés",
                        color = if (foundWordIds.size == words.size) EasyGreen else GoldLight,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Grille défilable de tous les mots sur 2 colonnes
            androidx.compose.foundation.lazy.grid.LazyVerticalGrid(
                columns = androidx.compose.foundation.lazy.grid.GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("words_to_find_grid"),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 4.dp)
            ) {
                items(words.size) { index ->
                    val wordPlacement = words[index]
                    val isFound = foundWordIds.contains(wordPlacement.id)
                    val vibrantColor = wordColors[wordPlacement.colorIndex % wordColors.size]

                    WordChip(
                        wordPlacement = wordPlacement,
                        isFound = isFound,
                        color = vibrantColor,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun WordChip(
    wordPlacement: WordPlacement,
    isFound: Boolean,
    color: Color,
    modifier: Modifier = Modifier
) {
    val animatedBg by animateColorAsState(
        targetValue = if (isFound) color.copy(alpha = 0.25f) else Color(0xFF13110B),
        animationSpec = tween(300),
        label = "word_bg"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(animatedBg)
            .border(
                1.dp,
                if (isFound) color else GoldBorderSubtle,
                RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = wordPlacement.displayWord,
                    color = if (isFound) color else TextWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textDecoration = if (isFound) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    text = wordPlacement.reference,
                    color = if (isFound) color.copy(alpha = 0.85f) else TextMuted,
                    fontSize = 8.5.sp
                )
            }

            if (isFound) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Trouvé",
                    tint = color,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

private fun computeLineCoordinates(r1: Int, c1: Int, r2: Int, c2: Int): List<CellCoordinate> {
    val dr = r2 - r1
    val dc = c2 - c1
    val stepR = if (dr == 0) 0 else dr / kotlin.math.abs(dr)
    val stepC = if (dc == 0) 0 else dc / kotlin.math.abs(dc)
    val count = kotlin.math.max(kotlin.math.abs(dr), kotlin.math.abs(dc))
    val result = mutableListOf<CellCoordinate>()
    for (i in 0..count) {
        result.add(CellCoordinate(r1 + i * stepR, c1 + i * stepC))
    }
    return result
}
