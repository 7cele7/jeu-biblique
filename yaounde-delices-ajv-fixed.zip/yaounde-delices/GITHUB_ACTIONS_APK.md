# 🤖 GitHub Actions - Génération APK Automatique

Guide rapide pour générer automatiquement des APK sur GitHub.

## 🎯 L'idée

Chaque fois que vous `git push`, GitHub génère automatiquement un APK que vous pouvez télécharger!

## ⚡ Démarrage rapide (2 minutes)

### 1️⃣ Uploader le code

```bash
git add .
git commit -m "Add Capacitor & GitHub Actions"
git push origin main
```

### 2️⃣ Attendre que GitHub Actions compile

- Allez sur: https://github.com/votre-username/yaounde-delices
- Cliquez "Actions"
- Regardez le workflow "Build Android APK" s'exécuter
- Attendez ~10-15 minutes

### 3️⃣ Télécharger l'APK

Une fois le build terminé (✅ vert):
1. Cliquez sur le run "Build Android APK"
2. Scrollez vers le bas: "Artifacts"
3. Téléchargez `yaounde-delices-debug`
4. Extrayez le fichier `app-debug.apk`

### 4️⃣ Installer sur Android

**Méthode 1: Envoyer par email/WhatsApp**
- Attacher le `.apk`
- Envoyer à votre téléphone
- Ouvrir le fichier et installer

**Méthode 2: Utiliser ADB (USB)**
```bash
adb install app-debug.apk
```

---

## 📁 Workflows disponibles

Vous avez **2 workflows** au choix:

### `build-android.yml` (Recommandé - Complet)
- ✅ Build complet avec tous les logs
- ✅ Génère APK Debug ET Release
- ✅ Upload automatique des artifacts
- ✅ Crée une GitHub Release avec l'APK

### `build-apk-simple.yml` (Simplifié)
- ✅ Plus rapide à configurer
- ✅ Génère seulement l'APK Debug
- ✅ Moins de dépendances

**Quelle choisir?** 
- **Débutant**: `build-apk-simple.yml`
- **Production**: `build-android.yml`

---

## 🎛️ Forcer un rebuild

Pour reconstruire manuellement sans faire de `git push`:

1. GitHub > Actions
2. Sélectionner le workflow
3. Bouton "Run workflow"
4. Cliquer "Run workflow"

---

## 🔔 Notifications d'échec

Si le build échoue:
1. Vous recevrez un email de GitHub
2. Allez voir les logs: Actions > Cliquer le run échoué
3. Voir l'erreur dans "Build APK" step

**Erreurs courantes:**
- "JAVA_HOME not set" → Java pas installé
- "Cannot find gradle" → C'est normal, GitHub l'installe
- "Build failed" → Vérifier le code React

---

## 📊 Monitorer les builds

Allez sur: https://github.com/votre-username/yaounde-delices/actions

Vous verrez:
- ✅ Builds réussis (vert)
- ❌ Builds échoués (rouge)
- ⏳ Builds en cours (orange)
- Durée de chaque build
- Logs détaillés

---

## 🔐 Sécurité & Secrets

⚠️ **IMPORTANT**: Ne commitez jamais:
- Fichiers `.jks` (clé de signature)
- Mots de passe
- Fichiers `.env`

**Stockez en tant que GitHub Secrets:**

1. Repository Settings > Secrets > New secret
2. Name: `KEYSTORE_PASSWORD`
3. Value: Votre mot de passe

Puis utilisez dans workflow:
```yaml
env:
  KEYSTORE_PASSWORD: ${{ secrets.KEYSTORE_PASSWORD }}
```

---

## 📱 Tester automatiquement sur Firebase Test Lab

(Avancé) Vous pouvez ajouter des tests automatiques:

```yaml
- name: Test on Firebase
  run: |
    gcloud firebase test android run \
      --app=app-debug.apk \
      --test=... \
      --device-ids=...
```

---

## 💾 Archivage des APKs

Les APKs sont conservés pendant **30 jours** par défaut.

Pour les garder plus longtemps:
```yaml
retention-days: 90  # Dans upload-artifact
```

---

## 🚀 Déploiement continu sur Google Play

(Avancé) Automatiser la publication sur Google Play Store:

```yaml
- name: Upload to Google Play
  uses: r0adkll/upload-google-play@v1
  with:
    serviceAccountJson: ${{ secrets.PLAY_STORE_KEY }}
    packageName: com.yaounde.delices
    releaseFiles: app-release.apk
```

---

## 📈 Améliorer les builds

### Réduire la durée (10-15 min → 5-7 min):
```yaml
- name: Cache gradle
  uses: actions/cache@v3
  with:
    path: |
      ~/.gradle/caches
      ~/.gradle/wrapper
    key: gradle-${{ runner.os }}
```

### Réduire la taille APK:
```yaml
# Dans android/app/build.gradle
android {
  packagingOptions {
    exclude 'META-INF/proguard/androidx-*.pro'
  }
}
```

---

## 📚 Fichiers de configuration

- `.github/workflows/build-android.yml` - Workflow complet
- `.github/workflows/build-apk-simple.yml` - Workflow simple
- `capacitor.config.json` - Config Capacitor
- `android.config.json` - Config Android
- `gradle.properties` - Propriétés Gradle

---

## ✅ Checklist

- [ ] Code poussé sur GitHub
- [ ] `.github/workflows/` uploadé
- [ ] Workflow visible dans Actions
- [ ] Premiers builds lancés avec succès
- [ ] APK téléchargé et testé
- [ ] Secrets configurés (si besoin)
- [ ] Notifications d'échec vérifiées

---

## 🆘 Besoin d'aide?

- GitHub Actions Docs: https://docs.github.com/actions
- Capacitor Docs: https://capacitorjs.com
- Android Build Docs: https://developer.android.com/build

---

**Bonne construction! 🏗️**

Chaque `git push` = nouvel APK automatiquement généré! 🚀
