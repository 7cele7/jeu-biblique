# 🎁 Features Bonus & Code Examples

## 1. Intégration WhatsApp Direct

Remplacer le bouton de confirmation par un lien WhatsApp direct:

```javascript
const handleWhatsAppOrder = () => {
  const total = calculateTotal();
  const fraisLivraison = total >= 5000 ? 0 : 1000;
  const totalFinal = total + fraisLivraison;

  const message = `Bonjour! Je voudrais commander:

${cart.map(item => `• ${item.nom} x${item.quantite} = ${item.prix * item.quantite} FCFA`).join('\n')}

Sous-total: ${total} FCFA
Frais de livraison: ${fraisLivraison} FCFA
TOTAL: ${totalFinal} FCFA

Nom: ${formData.nom}
Téléphone: ${formData.telephone}
Quartier: ${formData.quartier}`;

  const encodedMessage = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/237${phoneNumber}?text=${encodedMessage}`;
  window.open(whatsappUrl, '_blank');
};
```

**Usage:**
```javascript
<button onClick={handleWhatsAppOrder} className="...">
  💬 Commander via WhatsApp
</button>
```

---

## 2. Ajouter des Images Réelles

Remplacer les emojis par des URLs d'images:

```javascript
const plats = [
  {
    id: 1,
    nom: 'Poulet DG',
    prix: 3500,
    image: 'https://example.com/poulet-dg.jpg'
  },
];

// Dans le JSX
<img 
  src={plat.image} 
  alt={plat.nom} 
  className="w-full h-24 object-cover"
  onError={(e) => e.target.src = '🍗'}
/>
```

---

## 3. Système de Catégories avec Filtres

```javascript
const [selectedCategory, setSelectedCategory] = useState('Tous');

const categories = ['Tous', 'Plat principal', 'Grillade', 'Poisson', 'Plat traditionnel', 'Snack'];

const filteredPlats = selectedCategory === 'Tous' 
  ? plats 
  : plats.filter(p => p.categorie === selectedCategory);

// Rendu
<div className="flex gap-2 mb-8 overflow-x-auto">
  {categories.map(cat => (
    <button
      key={cat}
      onClick={() => setSelectedCategory(cat)}
      className={`px-4 py-2 rounded-lg whitespace-nowrap ${
        selectedCategory === cat 
          ? 'bg-red-600 text-white' 
          : 'bg-gray-200 text-gray-800'
      }`}
    >
      {cat}
    </button>
  ))}
</div>

<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {filteredPlats.map(plat => (...))}
</div>
```

---

## 4. Système de Notation des Plats

```javascript
const [ratings, setRatings] = useState(() => {
  const saved = localStorage.getItem('yaoundeRatings');
  return saved ? JSON.parse(saved) : {};
});

const rateItem = (id, rating) => {
  const newRatings = { ...ratings, [id]: rating };
  setRatings(newRatings);
  localStorage.setItem('yaoundeRatings', JSON.stringify(newRatings));
};

// Dans la carte du plat
<div className="flex gap-1">
  {[1, 2, 3, 4, 5].map(star => (
    <button
      key={star}
      onClick={() => rateItem(plat.id, star)}
      className={`text-2xl ${ratings[plat.id] >= star ? '⭐' : '☆'}`}
    >
      {ratings[plat.id] >= star ? '⭐' : '☆'}
    </button>
  ))}
</div>
```

---

## 5. Affichage du Temps de Livraison

```javascript
const calculateDeliveryTime = (quartier) => {
  const times = {
    'Mvog-Mbi': 30,
    'Bastos': 40,
    'Mokolo': 35
  };
  return times[quartier] || 45;
};

// Dans le résumé
<div className="bg-blue-50 p-4 rounded-lg">
  <p className="text-sm text-gray-600">Temps de livraison estimé</p>
  <p className="text-2xl font-bold text-blue-600">
    ~{calculateDeliveryTime(formData.quartier)} minutes
  </p>
</div>
```

---

## 6. Historique des Commandes

```javascript
const [orderHistory, setOrderHistory] = useState(() => {
  const saved = localStorage.getItem('yaoundeHistory');
  return saved ? JSON.parse(saved) : [];
});

const saveOrder = (order) => {
  const newHistory = [{...order, date: new Date().toISOString()}, ...orderHistory];
  setOrderHistory(newHistory);
  localStorage.setItem('yaoundeHistory', JSON.stringify(newHistory));
};

// Dans le résumé
<div className="mt-8">
  <h3 className="font-bold mb-4">Mes commandes récentes</h3>
  {orderHistory.slice(0, 5).map((order, i) => (
    <div key={i} className="border-b py-2">
      <p className="text-sm text-gray-600">{new Date(order.date).toLocaleDateString('fr-CM')}</p>
      <p className="font-bold">{order.total} FCFA</p>
    </div>
  ))}
</div>
```

---

## 7. Promo & Codes de Réduction

```javascript
const [promoCode, setPromoCode] = useState('');
const [discount, setDiscount] = useState(0);

const applyPromo = (code) => {
  const promos = {
    'BIENVENUE': 0.10,  // 10% off
    'VENDREDI50': 0.50, // 50% off
    'FIDELITE100': 100   // 100 FCFA off
  };
  
  if (promos[code]) {
    const discountAmount = typeof promos[code] === 'number' && promos[code] < 1
      ? calculateTotal() * promos[code]
      : promos[code];
    setDiscount(discountAmount);
    setPromoCode(code);
  }
};

// Formulaire
<div className="flex gap-2">
  <input
    type="text"
    placeholder="Code promo"
    value={promoCode}
    onChange={(e) => setPromoCode(e.target.value)}
    className="flex-1 border rounded px-3 py-2"
  />
  <button
    onClick={() => applyPromo(promoCode)}
    className="bg-green-600 text-white px-4 py-2 rounded"
  >
    Appliquer
  </button>
</div>

{discount > 0 && (
  <div className="text-green-600 font-bold">
    Réduction: -{discount} FCFA
  </div>
)}
```

---

## 8. Mode Sombre (Dark Mode)

```javascript
const [darkMode, setDarkMode] = useState(() => {
  return localStorage.getItem('yaoundeDarkMode') === 'true';
});

useEffect(() => {
  localStorage.setItem('yaoundeDarkMode', darkMode);
  if (darkMode) {
    document.documentElement.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
  }
}, [darkMode]);

// Bouton
<button
  onClick={() => setDarkMode(!darkMode)}
  className="p-2"
>
  {darkMode ? '☀️' : '🌙'}
</button>
```

---

## 9. Partage sur Réseaux Sociaux

```javascript
const shareOrder = () => {
  const text = `Je viens de commander ${cart.length} plats sur Yaoundé Délices! Rejoins-moi 🍽️`;
  
  // Facebook
  window.open(`https://www.facebook.com/sharer/sharer.php?quote=${encodeURIComponent(text)}&href=https://yaounde-delices.vercel.app`);
  
  // WhatsApp
  window.open(`https://wa.me/?text=${encodeURIComponent(text)} https://yaounde-delices.vercel.app`);
  
  // Twitter
  window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}`);
};

<button onClick={shareOrder} className="flex gap-2">
  Partager ➜ 📱
</button>
```

---

## 10. Notifications Toast

```javascript
const [toast, setToast] = useState(null);

const showToast = (message, type = 'success') => {
  setToast({ message, type });
  setTimeout(() => setToast(null), 3000);
};

// Component
{toast && (
  <div className={`fixed top-4 right-4 p-4 rounded-lg text-white ${
    toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'
  }`}>
    {toast.message}
  </div>
)}

// Usage
addToCart = (plat) => {
  // ...
  showToast(`${plat.nom} ajouté au panier ✓`);
};
```

---

## 11. Analytics Personnalisé

```javascript
const trackEvent = (eventName, data) => {
  const events = JSON.parse(localStorage.getItem('yaoundeEvents') || '[]');
  events.push({
    event: eventName,
    timestamp: new Date().toISOString(),
    data
  });
  localStorage.setItem('yaoundeEvents', JSON.stringify(events));
};

// Usage
addToCart = (plat) => {
  trackEvent('item_added', { item_id: plat.id, price: plat.prix });
  // ...
};

handleSubmitOrder = () => {
  trackEvent('order_completed', { total: calculateTotal(), items: cart.length });
  // ...
};
```

---

## 12. Localisation (i18n)

```javascript
const [language, setLanguage] = useState('fr');

const translations = {
  fr: {
    cart: 'Panier',
    total: 'Total',
    order: 'Passer la commande'
  },
  en: {
    cart: 'Cart',
    total: 'Total',
    order: 'Place Order'
  }
};

const t = (key) => translations[language][key];

// Usage
<button>{t('order')}</button>
```

---

## 📝 Comment Ajouter Ces Features?

1. Copier le code
2. Ajouter dans `src/App.js`
3. Importer les dépendances nécessaires si besoin
4. Tester localement: `npm start`
5. Déployer: `npm run build` puis push sur GitHub

---

## 🚀 Roadmap Recommandé

1. **Phase 1** (Semaine 1): Mettre en ligne + Tester
2. **Phase 2** (Semaine 2): Ajouter images réales + Filtres
3. **Phase 3** (Semaine 3): WhatsApp direct + Analytics
4. **Phase 4** (Mois 2): Admin panel + Historique
5. **Phase 5** (Mois 3): App mobile avec React Native

---

**Bonne implémentation! 🎉**
