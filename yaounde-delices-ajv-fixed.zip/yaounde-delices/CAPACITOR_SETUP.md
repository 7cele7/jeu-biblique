# 📱 Setup Capacitor - Guide Complet

Guide pour convertir votre app React web en app mobile Android avec Capacitor.

## 🎯 Qu'est-ce que Capacitor?

Capacitor permet de:
- ✅ Convertir une app web en app mobile native
- ✅ Accéder aux API natives Android (caméra, GPS, etc.)
- ✅ Générer un APK installable sur Android
- ✅ Déployer automatiquement via GitHub Actions

---

## 📋 Prérequis

### Localement (si développement local):
- **Node.js** 16+ (https://nodejs.org)
- **Java JDK 17+** (https://adoptium.net)
- **Android Studio** (https://developer.android.com/studio)
- **Android SDK API 34** (installé via Android Studio)

### Via GitHub Actions:
- ✅ Automatique! Aucun setup requis

---

## 🚀 Option 1: Génération APK via GitHub Actions (RECOMMANDÉE)

La façon la plus simple sans rien installer localement!

### Étape 1: Uploader sur GitHub

1. Créer un repository GitHub: `yaounde-delices`
2. Uploader tous les fichiers (incluant `.github/workflows/`)

### Étape 2: Déclencher le build

1. GitHub > Actions
2. Sélectionner "Build Android APK"
3. Cliquer "Run workflow"
4. Attendre ~10-15 minutes

### Étape 3: Télécharger l'APK

1. Actions > Dernier run > "Summary"
2. Artifacts: `yaounde-delices-debug`
3. Télécharger le fichier `app-debug.apk`

### Étape 4: Installer sur Android

**Via USB:**
```bash
adb install app-debug.apk
```

**Via Email/Cloud:**
- Envoyer le `.apk` à votre téléphone
- Ouvrir le fichier
- Accepter l'installation

---

## 🔧 Option 2: Build Local (Développement)

Pour développer localement et tester en temps réel.

### Étape 1: Installer les prérequis

```bash
# Installer Java JDK 17
# https://adoptium.net

# Installer Android Studio
# https://developer.android.com/studio
```

### Étape 2: Setup Capacitor

```bash
# Cloner votre repository
git clone https://github.com/votre-username/yaounde-delices.git
cd yaounde-delices

# Installer npm
npm install

# Construire React
npm run build

# Ajouter Capacitor pour Android
npm run cap:add:android

# Synchroniser les fichiers
npm run cap:sync
```

### Étape 3: Ouvrir Android Studio

```bash
# Ouvrir le projet Android dans Android Studio
npm run cap:open
```

Android Studio va s'ouvrir automatiquement.

### Étape 4: Builder l'APK

**Depuis Android Studio:**
1. Build > Build Bundle(s) / APK(s) > Build APK(s)
2. Attendre la compilation

Ou via CLI:
```bash
cd android
./gradlew assembleDebug
```

### Étape 5: Installer sur Android

**Emulateur:**
```bash
# Lancer l'emulateur Android Studio d'abord
./gradlew installDebug
```

**Téléphone réel (USB):**
```bash
# Activer le mode développeur sur le téléphone
# Connecter via USB et autoriser
adb install app/build/outputs/apk/debug/app-debug.apk
```

---

## 📁 Structure des fichiers Capacitor

Après `npm run cap:add:android`, vous aurez:

```
yaounde-delices/
├── android/              # Projet Android complet
│   ├── app/
│   │   └── src/
│   │       └── main/
│   │           ├── AndroidManifest.xml
│   │           └── res/
│   ├── settings.gradle
│   └── build.gradle
├── capacitor.config.json # Config principale
├── android.config.json   # Config Android
└── src/
    └── App.js           # App React (compatible Capacitor)
```

---

## 🔐 Créer une clé de signature APK (Release)

Pour distribuer sur Google Play Store, vous avez besoin d'une clé de signature.

### Créer la clé:

```bash
keytool -genkey -v -keystore yaounde-delices-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias yaounde-delices
```

**Questions à répondre:**
- First and last name: Yaoundé Délices
- Organization: Your Company
- Password: Créez un mot de passe fort

### Signer l'APK:

```bash
jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 \
  -keystore yaounde-delices-key.jks \
  app-release-unsigned.apk yaounde-delices

# Optimiser (optionnel)
zipalign -v 4 app-release-unsigned.apk app-release-signed.apk
```

⚠️ **Sécurité**: Ne partagez JAMAIS votre fichier `.jks`!

---

## 🎨 Personnaliser l'App

### Icon & Splash Screen

1. Ajouter des images dans `android/app/src/main/res/`
2. Mettre à jour les références dans `AndroidManifest.xml`

### Permissions Android

Éditer `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
```

### App Name & ID

Éditer `capacitor.config.json`:
```json
{
  "appId": "com.yaounde.delices",
  "appName": "Yaoundé Délices"
}
```

---

## 🐛 Dépannage

### "JAVA_HOME not set"
```bash
# Linux/Mac:
export JAVA_HOME=/usr/libexec/java_home -v 17

# Windows:
# Définir JAVA_HOME via Paramètres systèmes
```

### "Android SDK not found"
```bash
# Installer via Android Studio
# Tools > SDK Manager > Install "API 34"
```

### "Build failed: gradle"
```bash
# Nettoyer et reconstruire
cd android
./gradlew clean
./gradlew assembleDebug
```

### "App blank/white screen"
1. Vérifier les logs: `adb logcat`
2. S'assurer que le build React est à jour: `npm run build`
3. Sync Capacitor: `npm run cap:sync`

---

## 📊 Distribuer sur Google Play Store

### Prérequis:
1. Créer un compte Google Play Developer ($25 une fois)
2. Signer l'APK avec votre clé
3. Créer un APK en mode Release

### Étapes:

1. **Google Play Console**: https://play.google.com/console
2. Créer une nouvelle app
3. Uploader l'APK signé
4. Remplir les détails (description, images, etc.)
5. Soumettre pour review (~2-4 heures)

---

## ✅ Checklist de déploiement

- [ ] Code React complet et testé
- [ ] `npm run build` sans erreurs
- [ ] Capacitor configuré
- [ ] `capacitor.config.json` correctement rempli
- [ ] AndroidManifest.xml actualisé
- [ ] Icon et splash screen personnalisés
- [ ] APK généré avec succès
- [ ] APK testé sur un vrai téléphone Android
- [ ] Clé de signature créée (pour release)
- [ ] App sur Google Play Store (optionnel)

---

## 🚀 Commandes utiles

```bash
# Installation & Setup
npm install                           # Installer npm
npm run build                         # Construire React
npm run cap:add:android              # Ajouter Capacitor Android
npm run cap:sync                     # Synchroniser les changements

# Développement
npm run cap:open                     # Ouvrir Android Studio
npm start                            # Démarrer le serveur de développement

# Build APK
cd android && ./gradlew assembleDebug   # APK Debug
cd android && ./gradlew assembleRelease # APK Release

# Installation
adb install app-debug.apk            # Installer sur téléphone
adb logcat                           # Voir les logs
```

---

## 📚 Ressources

- **Capacitor Docs**: https://capacitorjs.com/docs
- **Android Docs**: https://developer.android.com/docs
- **Gradle Docs**: https://gradle.org/releases
- **React Native**: Si vous voulez alternative

---

## 💡 Améliorations futures

- [ ] Intégration WhatsApp Web (ouvrir chats directement)
- [ ] Notifications push (Firebase Cloud Messaging)
- [ ] Géolocalisation (Google Maps)
- [ ] Caméra (scanner QR codes de paiement)
- [ ] Offline mode (PWA + Capacitor)

---

**Bonne luck avec votre app mobile! 📱🚀**

Pour toute question: Consultez les documentations officielles ou ouvrez une issue sur GitHub.
