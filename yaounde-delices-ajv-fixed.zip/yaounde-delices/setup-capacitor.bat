@echo off

REM Script de setup automatique pour Capacitor (Windows)
REM Usage: Double-cliquer sur ce fichier

echo.
echo 🚀 Setup Capacitor pour Yaoundé Délices
echo ========================================
echo.

REM Vérifier Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ Node.js n'est pas installé
    echo Installer depuis: https://nodejs.org
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node --version') do set NODE_VERSION=%%i
echo ✅ Node.js installé: %NODE_VERSION%

REM Étape 1: Installer npm
echo.
echo 📦 Étape 1: Installer les dépendances npm...
call npm install
if %errorlevel% neq 0 (
    echo ❌ Erreur lors de l'installation npm
    pause
    exit /b 1
)
echo ✅ npm installé

REM Étape 2: Build React
echo.
echo 🔨 Étape 2: Compiler React...
call npm run build
if %errorlevel% neq 0 (
    echo ❌ Erreur lors du build React
    pause
    exit /b 1
)
echo ✅ React compilé

REM Étape 3: Ajouter Capacitor Android
echo.
echo 📱 Étape 3: Ajouter Capacitor Android...
call npx capacitor add android 2>nul
echo ✅ Capacitor Android configuré

REM Étape 4: Synchroniser
echo.
echo 🔄 Étape 4: Synchroniser les fichiers...
call npx capacitor sync android
if %errorlevel% neq 0 (
    echo ❌ Erreur lors de la synchronisation
    pause
    exit /b 1
)
echo ✅ Synchronisation complète

REM Étape 5: Résumé
echo.
echo ========================================
echo ✅ Setup Capacitor terminé!
echo ========================================
echo.
echo 📋 Prochaines étapes:
echo 1. Installer Android Studio:
echo    https://developer.android.com/studio
echo.
echo 2. Ouvrir le projet Android:
echo    npm run cap:open
echo.
echo 3. Builder l'APK via Android Studio:
echo    Build > Build APK(s)
echo.
echo Ou via CLI:
echo    cd android && gradlew.bat assembleDebug
echo.
echo 📚 Documentation complète:
echo    Voir CAPACITOR_SETUP.md
echo.
echo 🎉 Bonne chance!
echo.

pause
