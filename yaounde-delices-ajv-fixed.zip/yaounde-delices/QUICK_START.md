# ⚡ Démarrage Rapide - 5 minutes

## 🚀 Mettre en ligne en 5 minutes (sans installer quoi que ce soit)

### Méthode Ultra-Simple (Recommandée)

1. **Créer un compte GitHub** (2 min)
   - Aller sur https://github.com/signup
   - Utiliser votre email

2. **Télécharger les fichiers**
   - Télécharger ce dossier complet

3. **Uploader sur GitHub** (2 min)
   - Créer un nouveau repository "yaounde-delices"
   - Uploader tous les fichiers via "Upload files"

4. **Déployer automatiquement** (1 min)
   - Aller sur https://vercel.com
   - Cliquer "Import Project"
   - Connecter avec GitHub
   - Sélectionner votre repository
   - Cliquer "Deploy"

**Voilà! Votre app est en ligne:** `yaounde-delices.vercel.app`

---

## 📱 Si vous avez déjà Node.js installé

```bash
# 1. Entrer dans le dossier
cd yaounde-delices

# 2. Installer
npm install

# 3. Tester localement
npm start

# 4. Afficher dans votre navigateur
# http://localhost:3000
```

---

## ✏️ Personnaliser en 2 minutes

1. Ouvrir `src/App.js`
2. Chercher (Ctrl+F) "6X XX XX XX"
3. Remplacer par vos vrais numéros:
   - WhatsApp
   - Mobile Money

**Fait!** 🎉

---

## 📞 Questions Fréquentes

**Q: Ça coûte quoi?**
A: Gratuit! Netlify et Vercel offrent gratuitement.

**Q: Besoin d'une base de données?**
A: Non! Les commandes sont sauvegardées localement.

**Q: Peut recevoir les commandes comment?**
A: WhatsApp, email, ou SMS. À vous de choisir!

**Q: Comment ajouter/modifier les plats?**
A: Éditer le tableau `plats` dans `src/App.js`

**Q: Peut mettre un domaine perso?**
A: Oui! Aller dans les paramètres Vercel/Netlify

---

## 🎯 Prochaines Étapes

1. ✅ Mettre en ligne (vous êtes ici)
2. ⏭️ Ajouter vos vrais numéros
3. ⏭️ Tester sur mobile
4. ⏭️ Partager le lien sur WhatsApp/Facebook
5. ⏭️ Ajouter des photos réelles des plats

---

## 💡 Besoin d'aide?

- Logs Vercel: Dashboard > Deployments > View Logs
- Erreurs: Ouvrir la console (F12) dans le navigateur
- GitHub: Aide disponible sur YouTube "GitHub beginner tutorial"

**Bonne chance! 🍽️**
