# ⚡ Capacitor Quick Start - 5 minutes!

Le chemin le plus rapide pour générer un APK sans rien installer!

---

## 🎯 Vous allez faire:

1. Push le code sur GitHub
2. GitHub compile et génère l'APK automatiquement
3. Télécharger et installer sur votre téléphone

**Durée totale: ~15 minutes** ⏱️

---

## 📋 Prérequis

- GitHub account (créer sur https://github.com/signup)
- C'est tout! ✅

---

## 🚀 Les 4 étapes

### Étape 1: Uploader sur GitHub (2 min)

```bash
# Dans le dossier yaounde-delices
git add .
git commit -m "Add Capacitor & GitHub Actions"
git push origin main
```

Ou via GitHub web:
1. Nouveau repository `yaounde-delices`
2. Upload des fichiers via "Upload files"

### Étape 2: Vérifier les workflows (1 min)

1. Aller sur https://github.com/votre-username/yaounde-delices
2. Cliquer "Actions"
3. Vous verrez "Build Android APK" en cours ⏳

### Étape 3: Attendre la compilation (10-15 min)

Le workflow va:
- ✅ Installer Node.js
- ✅ Compiler React (`npm run build`)
- ✅ Ajouter Capacitor
- ✅ Builder l'APK Android
- ✅ Uploader les artifacts

### Étape 4: Télécharger l'APK (1 min)

Une fois terminé (✅ vert):
1. Actions > Dernière exécution
2. Descendre à "Artifacts"
3. Télécharger `yaounde-delices-debug.zip`
4. Extraire: `app-debug.apk`

### Étape 5: Installer sur Android (1 min)

**Option A: Email/WhatsApp**
- Envoyer le `.apk` à votre téléphone
- Ouvrir le fichier
- Accepter l'installation

**Option B: ADB (si USB disponible)**
```bash
adb install app-debug.apk
```

---

## ✅ C'est fait!

Votre app est maintenant sur votre téléphone! 📱

---

## 🔄 Mettre à jour l'app

Chaque fois que vous modifiez le code:

```bash
git add .
git commit -m "Update menu items"
git push origin main
```

GitHub génère automatiquement un nouvel APK! 🚀

---

## 📚 Guides complets

Pour plus de détails:
- **CAPACITOR_SETUP.md** - Guide complet (installation locale, etc.)
- **GITHUB_ACTIONS_APK.md** - Détails des workflows GitHub Actions
- **CAPACITOR_SETUP.md** - Configuration avancée

---

## 🐛 Troubleshooting rapide

**L'app ne se compile pas?**
→ Voir les logs: Actions > Cliquer le run > "Build APK" step

**L'APK n'installe pas?**
→ Aller dans Paramètres > Sécurité > Activer "Installation d'apps inconnues"

**Besoin de modifier le code local?**
→ Voir `setup-capacitor.sh` (Mac/Linux) ou `setup-capacitor.bat` (Windows)

---

## 🎁 Bonus: Build Release pour Google Play

Pour distribuer sur Play Store:
1. Créer une clé de signature
2. Voir `CAPACITOR_SETUP.md` pour les détails
3. Upload l'APK signé à Google Play

---

**Voilà! Votre app mobile est prête! 🎉**

Questions? Consultez les guides complets ou ouvrez une issue sur GitHub.
