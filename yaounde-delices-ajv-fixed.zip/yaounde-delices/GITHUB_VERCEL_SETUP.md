# 🚀 Setup Complet: GitHub + Vercel

Guide étape par étape pour mettre votre application en ligne avec GitHub et Vercel.

## 📋 Prérequis

- Aucun! (Un navigateur suffit)

## ✅ Étape 1: Créer un compte GitHub (2 minutes)

1. Aller sur **https://github.com/signup**
2. Entrer votre email
3. Créer un mot de passe sécurisé
4. Choisir un username
5. Cliquer "Create account"
6. Vérifier votre email et confirmer

## 📂 Étape 2: Créer un repository GitHub (3 minutes)

1. Une fois connecté, cliquer le "+" en haut à droite
2. Sélectionner "New repository"
3. **Nom du repository**: `yaounde-delices`
4. **Description** (optionnel): "Application de livraison de repas camerounais"
5. Cocher "Add a README file"
6. Sélectionner licença: "MIT License" (recommandé)
7. Cliquer "Create repository"

## 📤 Étape 3: Uploader vos fichiers sur GitHub

### Méthode A: Via navigateur (Plus simple - Recommandée)

1. Allez dans votre nouveau repository
2. Cliquez "Add file" → "Upload files"
3. Drag & drop votre dossier `yaounde-delices` complet OU sélectionnez les fichiers:
   - `package.json`
   - `vercel.json`
   - `netlify.toml`
   - `.gitignore`
   - `.env.example`
   - Dossier `public/` (avec `index.html`)
   - Dossier `src/` (avec `App.js` et `index.js`)
   - Fichiers `README.md`, `QUICK_START.md`, `DEPLOYMENT_GUIDE.md`, `BONUS_FEATURES.md`

4. Ajouter un message de commit: "Initial commit - Yaoundé Délices"
5. Cliquer "Commit changes"

### Méthode B: Via Git (Pour développeurs)

```bash
# Sur votre ordinateur
cd yaounde-delices
git init
git add .
git commit -m "Initial commit - Yaoundé Délices"
git branch -M main
git remote add origin https://github.com/VOTRE_USERNAME/yaounde-delices.git
git push -u origin main
```

## 🚀 Étape 4: Déployer sur Vercel (2 minutes)

1. Aller sur **https://vercel.com/signup**
2. Cliquer "Continue with GitHub"
3. Autoriser Vercel à accéder à vos repositories
4. Cliquer "New Project"
5. Chercher et sélectionner `yaounde-delices`
6. **Paramètres de build** (laisser par défaut):
   - Framework: "Create React App" (auto-détecté)
   - Build Command: `npm run build`
   - Output Directory: `build`
7. Cliquer "Deploy"

### ⏳ Attendez... (~2-3 minutes)

Vercel va:
- Télécharger vos fichiers
- Installer les dépendances
- Compiler votre app
- Mettre en ligne

### ✅ Voilà!

Votre app est en ligne à: **`https://yaounde-delices.vercel.app`**

(Vercel vous donnera l'URL exact après le déploiement)

## 🎨 Personnaliser le domaine Vercel

1. Dashboard Vercel > Votre projet > Settings
2. Allez à "Domains"
3. Actuellement: `yaounde-delices.vercel.app`
4. Vous pouvez changer le sous-domaine

## 🔄 Mettre à jour votre app

### Après chaque modification:

1. **Modifiez un fichier** sur GitHub:
   - Naviguez dans le fichier
   - Cliquez l'icône ✏️ "Edit this file"
   - Modifiez
   - Cliquez "Commit changes"

2. **Vercel se met à jour automatiquement!**
   - Vercel détecte les changements
   - Redéploie automatiquement
   - Votre app sera à jour en ~2-3 minutes

3. **Vérifiez les logs**:
   - Vercel Dashboard > Deployments
   - Cliquez sur le dernier déploiement pour voir les logs

## ⚙️ Ajouter un domaine personnalisé

### Option 1: Domaine gratuit `.vercel.app`

Déjà inclus! Utilisez: `yaounde-delices.vercel.app`

### Option 2: Domaine personnalisé `.cm` ou `.com`

1. Acheter un domaine sur:
   - **Namecheap** (https://namecheap.com)
   - **GoDaddy** (https://godaddy.com)
   - **Domain.cm** (local camerounais)

2. Vercel Settings > Domains
3. Ajouter votre domaine (ex: `yaounde-delices.cm`)
4. Suivre les instructions DNS de Vercel

## 🔐 Ajouter vos vraies coordonnées

1. GitHub > Votre repository > `src/App.js`
2. Chercher "6X XX XX XX" (Ctrl+F)
3. Remplacer par vos vrais numéros:
   - WhatsApp: `697XXX XXX` (par exemple)
   - Mobile Money: `697XXX XXX`
4. Cliquer "Commit changes"
5. Vercel redéploiera automatiquement!

## 📱 Tester sur mobile

1. Ouvrir: `https://yaounde-delices.vercel.app` sur votre téléphone
2. Tester l'ajout de plats
3. Tester le formulaire de commande
4. Vous verrez "Share" sur mobile pour partager

## 🐛 Dépannage

### "Deployment failed"
- Vérifier que `package.json` est à la racine
- Vérifier que `vercel.json` est correct
- Logs Vercel > voir le message d'erreur

### "Cannot find module"
- Assurez-vous que `node_modules` n'est pas en `.gitignore` (ou normal de l'être)
- Vercel installe automatiquement avec `npm install`

### App ne se met pas à jour
- Vérifier les "Deployments" dans Vercel
- Le dernier est-il "Ready"?
- Vider le cache du navigateur (Ctrl+Shift+Delete)

## 📊 Analytics & Monitoring

### Vercel Analytics (Gratuit)
- Dashboard > Analytics
- Voir les visites en temps réel
- Performance de votre app

### Google Analytics (Optionnel)
- Ajouter le code GA dans `public/index.html`
- Voir les statistiques détaillées

## 🎯 Prochaines étapes recommandées

1. ✅ Mettre en ligne (vous êtes ici!)
2. ⏭️ Ajouter vos vrais numéros
3. ⏭️ Tester sur mobile
4. ⏭️ Partager le lien WhatsApp/Facebook
5. ⏭️ Ajouter un domaine personnalisé
6. ⏭️ Améliorer avec des images réelles

## 💬 Questions?

- **GitHub Help**: https://docs.github.com
- **Vercel Docs**: https://vercel.com/docs
- **React Docs**: https://react.dev

---

**Succès! Votre app est maintenant en ligne! 🎉**

Pour toute question, consultez les liens ci-dessus ou ouvrez une "Issue" sur GitHub.
